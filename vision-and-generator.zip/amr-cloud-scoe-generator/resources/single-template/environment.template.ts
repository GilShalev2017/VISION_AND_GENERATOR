export const environment = {
  production: true,
  serverUrl: '<<server_url>>/'
};
