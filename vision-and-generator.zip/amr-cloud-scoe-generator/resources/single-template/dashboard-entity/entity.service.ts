import { Injectable } from '@angular/core';
import {AuthLevel, Entity, EntityService} from '../../models/interfaces';
import {environment} from '../../../environments/environment';
import {HttpClient} from '@angular/common/http';
import {Observable, of} from 'rxjs';
import {FormControl, FormGroup} from "@angular/forms";
import {EntityTableService} from "../entity-table/entity-table.service";

export interface User extends Entity {
  name: string;
} // entity

@Injectable({
  providedIn: 'root'
})
export class UsersService implements EntityService {

  displayName = 'user';
  fields = {
    name: {displayName: 'Name', type: 'string'},
  }; // fields

  constructor(private httpClient: HttpClient, private entityTableService: EntityTableService) {}


  getSingleForm(user: User): FormGroup {
    const controls = Object.keys(this.fields).reduce((controlMap, field) => {
      controlMap[field] = new FormControl(user ? user[field] : '');
      return controlMap;
    }, {});
    return new FormGroup(controls);
  }

  get(page: number, pageSize: number): Observable<Entity[]> {
    const filter = {
      offset: 0,
      limit: pageSize,
      skip: page * pageSize,
      order: [
        'name ASC'
      ]
    };
    return this.httpClient.get<User[]>(environment.serverUrl + 'users/?filter=' + encodeURI(JSON.stringify(filter)));
  }

  getUserById(id: string) {
    return this.httpClient.get<User>(environment.serverUrl + 'users/' + id);
  }

  delete(userId: string): Observable<void> {
    return this.httpClient.delete<void>(environment.serverUrl + `users/${userId}`, {});
  }

  save(id: string, entity: User): Observable<User> {
    this.entityTableService.formatEntity(this.fields, entity);
    if (id) {
      return this.httpClient.put<User>(environment.serverUrl + 'users/' + id, entity);
    } else {
      return this.httpClient.post<User>(environment.serverUrl + 'users', entity);
    }
  }
}
