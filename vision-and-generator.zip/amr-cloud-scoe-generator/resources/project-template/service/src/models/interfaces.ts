import {QMessegeType} from "./enums.model";
import {User} from "../micro-services/users/user.model";

export interface QMessage {
    type: QMessegeType;
}

export interface QMessageJobStart extends QMessage {
    jobId: string;
}


export interface GetUsersResponse {
    users: User[];
    count: number;
}

export interface ArgoCronWorkflow {

    type: object
    properties: {
        "apiVersion": string,
        "kind": string,
        "metadata": {
            name: string
        },
        "spec": {
            "schedule": string,
            "concurrencyPolicy": string,
            "startingDeadlineSeconds": number,
            "workflowSpec": {
                properties: {
                    entrypoint: string,
                    templates: {

                        items: {

                            name: string,
                            container: {

                                image: string,
                                command: string[],
                                args: string[]

                            }

                        }
                    }
                }
            }
        }
    }

}

export interface ArgoWorkflow {
    metadata?: {
        "name": string,
        "generateName": string,
        "namespace": string,
        "uid": string,
        "resourceVersion": string,
        "generation": number,
        "creationTimestamp": string,
        "labels": {
            "workflows.argoproj.io/completed": string,
            "workflows.argoproj.io/creator": string,
            "workflows.argoproj.io/phase": string
        },
        "managedFields": [
            {
                "manager": string,
                "operation": string,
                "apiVersion": string,
                "time": string,
                "fieldsType": string,
                "fieldsV1": {
                    "f:metadata": {
                        "f:generateName": object,
                        "f:labels": {
                            ".": object,
                            "f:workflows.argoproj.io/creator": object
                        }
                    },
                    "f:spec": {
                        ".": object,
                        "f:arguments": object,
                        "f:entrypoint": object,
                        "f:templates": object
                    },
                    "f:status": object
                }
            },
            {
                "manager": string,
                "operation": string,
                "apiVersion": string,
                "time": string,
                "fieldsType": string,
                "fieldsV1": {
                    "f:metadata": {
                        "f:labels": {
                            "f:workflows.argoproj.io/completed": object,
                            "f:workflows.argoproj.io/phase": object
                        }
                    },
                    "f:status": {
                        "f:artifactRepositoryRef": object,
                        "f:conditions": object,
                        "f:finishedAt": object,
                        "f:nodes": object,
                        "f:phase": object,
                        "f:progress": object,
                        "f:resourcesDuration": object,
                        "f:startedAt": object
                    }
                }
            }
        ]
    },
    spec?: {
        "templates": [
            {
                "name": string,
                "inputs": object,
                "outputs": object,
                "metadata": object,
                "container": {
                    "name": string,
                    "image": string,
                    "command": string[]
                    "args": string[]
                    "resources": object
                }
            }
        ],
        "entrypoint": string,
        "arguments": object
    },
    status?: {
        "phase": string,
        "startedAt": string,
        "finishedAt": string,
        "progress": string,
        "nodes": {
            "hello-world-m4x8f": {
                "id": string,
                "name": string,
                "displayName": string,
                "type": string,
                "templateName": string,
                "templateScope": string,
                "phase": string,
                "startedAt": string,
                "finishedAt": string,
                "progress": string,
                "resourcesDuration": {
                    "cpu": number,
                    "memory": number
                },
                "outputs": {
                    "exitCode": string
                }
            }
        },
        "conditions": [
            {
                "type": string,
                "status": string
            },
            {
                "type": string,
                "status": string
            }
        ],
        "resourcesDuration": {
            "cpu": number,
            "memory": number
        },
        "artifactRepositoryRef": {
            "default": boolean
        }
    }
}

export interface QMessagePushNotification extends QMessage {
    title?: string;
    body?: string;
    tokens: string | string[]
    icon?: string;
    clickAction?: string;


}

export interface TopicQMessagePushNotification extends QMessage {

    topic: string;
    title: string;
    body: string
    icon?: string;
    clickAction?: string;

}

export interface QMessageTopicSubscription {
    topic: string;
    tokens: string[];
}
