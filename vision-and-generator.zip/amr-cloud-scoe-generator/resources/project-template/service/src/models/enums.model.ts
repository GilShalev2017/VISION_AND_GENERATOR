
export enum JobState {
    INITIAL = "INITIAL",
    IN_PROGRESS = "IN_PROGRESS",
    COMPLETED = "COMPLETED",
    ERROR = "ERROR",
    CANCELED = "CANCELED",
    QUEUED = 'QUEUED'
}
export enum QMessegeType {
    START_JOB_PROCESSING,
    CANCEL_JOB_PROCESSING,
    JOB_PROCESSING_STATUS,
    SEND_PUSH_NOTIFICATION_TO_DEVICE,
    SEND_PUSH_NOTIFICATION_TO_TOPIC,
    SUBSCRIBE_TO_TOPIC,
    UNSUBSCRIBE_FROM_TOPIC
}
export enum Gender {
    MALE = 'MALE',
    FEMALE = 'FEMALE'
}
export enum AuthLevel {
    USER = 'USER',
    ADMIN = 'ADMIN',
    SUPER = 'SUPER'
}
