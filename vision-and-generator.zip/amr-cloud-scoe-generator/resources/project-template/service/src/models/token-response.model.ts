import {Model, model, property} from '@loopback/repository';

@model()
export class TokenResponse extends Model {
  @property({
    type: 'string',
    required: true,
  })
  access_token: string;

  @property({
    type: 'date',
    required: true,
  })
  expired: string;


  constructor(data?: Partial<TokenResponse>) {
    super(data);
  }
}

export interface TokenResponseRelations {
  // describe navigational properties here
}

export type TokenResponseWithRelations = TokenResponse & TokenResponseRelations;
