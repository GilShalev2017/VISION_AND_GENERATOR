import {authenticate} from "@loopback/authentication";
import {

    MyUserService,
    UserServiceBindings,
} from '@loopback/authentication-jwt';
import {inject} from '@loopback/core';
import {repository} from '@loopback/repository';
import axios, {AxiosResponse} from 'axios'
import {
    del,
    get,
    oas, HttpErrors,
    param,
    post,
    put, Request,
    requestBody,
    Response,
    RestBindings,
    SchemaObject,
} from '@loopback/rest';
import {SecurityBindings, UserProfile} from '@loopback/security';
import {ArgoCronWorkflow, ArgoWorkflow} from "../../models";

interface ArgoResponse {
    message?: string;
    code?: string;
}

const argoActionsSchema: SchemaObject = {
    type: 'string',
    example: 'resubmit / resume / retry / set / stop / suspend / terminate'

}
const argoCronActionsSchema: SchemaObject = {
    type: 'string',
    example: 'resume /suspend'
}
const argoCronSchema: SchemaObject = {
    type: 'object',
    example: {
        type: 'object',
        properties: {
            "apiVersion": {type: 'string'},
            "kind": {type: 'string'},
            "metadata": {
                type: 'object',
                properties: {name: {type: 'string'}}
            },
            "spec": {
                type: 'object',
                properties: {
                    "schedule": {type: 'string'},
                    "concurrencyPolicy": {type: 'string'},
                    "startingDeadlineSeconds": {type: 'number'},
                    "workflowSpec": {
                        type: 'object',
                        properties: {
                            entrypoint: {type: 'string'},
                            templates: {
                                type: 'array',
                                items: {
                                    type: 'object',
                                    properties: {
                                        name: {type: 'string'},
                                        container: {
                                            type: 'object', properties: {

                                                image: {type: 'string'},
                                                command: {type: 'array', items: {type: 'string'}},
                                                args: {type: 'array', items: {type: 'string'}},
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
const argoWorkflowSchema: SchemaObject = {
    type: 'object',
    properties: {
        namespace: {
            type: 'string',
        },
        serverDryRun: {
            type: 'boolean',
        },
        workflow: {
            type: 'object',
            properties: {
                metadata: {
                    type: 'object', properties: {
                        generateName: {type: 'string'},
                        namespace: {type: 'string'},
                        labels: {type: 'object', properties: {'workflows.argoproj.io/completed': {type: 'string'}}}
                    }
                },
                specs: {
                    type: 'object', properties: {
                        templates: {
                            type: 'array',
                            items: {
                                type: 'object', properties: {
                                    name: {type: 'string'},
                                    image: {type: 'string'},
                                    command: {type: 'array', items: {type: 'string'}},
                                    args: {type: 'array', items: {type: 'string'}},
                                    resources: {type: 'object'}
                                }
                            }
                        },
                        entrypoint: {type: 'string'},
                        arguments: {type: 'object'}
                    }
                }
            }
        }
    }
}

@authenticate('jwt')
//@oas.visibility('undocumented')
export class ArgoController {

    private workflowsUrl = (process.env.LOCAL ? 'https://localhost' : 'https://argo-server.argo.svc.cluster.local').concat(`:2746/api/v1/workflows/argo`);
    private cronWorkflowsUrl = (process.env.LOCAL ? 'https://localhost' : 'https://argo-server.argo.svc.cluster.local').concat(`:2746/api/v1/cron-workflows/argo`);

    constructor(
        @inject(UserServiceBindings.USER_SERVICE)
        public userService: MyUserService,
        @inject(SecurityBindings.USER, {optional: true})
        public user: UserProfile,
        @inject(RestBindings.Http.RESPONSE) private response: Response,
        @inject(RestBindings.Http.REQUEST) private request: Request,
    ) {
        // proxy should be removed from Dockerfile
        // ignore sll errors and enable https access
        process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

    }

    @post('/argo/workflows', {
        summary: 'Execute argo workflow',
        description: 'Please enter a json format workflow',
        responses: {
            '200': {
                content: {
                    'application/json': {
                        schema: {properties: {message: {type: 'string'}, code: {type: 'string'}}},
                    },
                },
            },
        },
    })
    async executeWorkflow(
        @requestBody({
            summary: 'Execute new workflow',
            description: 'Please enter a json format workflow',
            required: true,
            content: {
                'application/json': {
                    schema: argoWorkflowSchema,
                    example: {

                        "metadata": {
                            "name": "sparkly-whale",
                            "namespace": "argo",
                            "labels": {
                                "example": "true"
                            }
                        },
                        "spec": {
                            "arguments": {
                                "parameters": [
                                    {
                                        "name": "message",
                                        "value": "hello argo"
                                    }
                                ]
                            },
                            "entrypoint": "argosay",
                            "templates": [
                                {
                                    "name": "argosay",
                                    "inputs": {
                                        "parameters": [
                                            {
                                                "name": "message",
                                                "value": "{{workflow.parameters.message}}"
                                            }
                                        ]
                                    },
                                    "container": {
                                        "name": "main",
                                        "image": "argoproj/argosay:v2",
                                        "command": [
                                            "/argosay"
                                        ],
                                        "args": [
                                            "echo",
                                            "{{inputs.parameters.message}}"
                                        ]
                                    }
                                }
                            ],
                            "ttlStrategy": {
                                "secondsAfterCompletion": 300
                            },
                            "podGC": {
                                "strategy": "OnPodCompletion"
                            }
                        }
                    }
                },

            },
        }) workflowYaml: ArgoWorkflow,
        @inject(SecurityBindings.USER) currentUserProfile: UserProfile,
    ): Promise<ArgoResponse> {
        try {
            const res = await axios.post<ArgoResponse>(this.workflowsUrl, {"workflow": workflowYaml});
            return res.data;
        } catch (e) {
            if (e.response.data) {
                throw new HttpErrors.Conflict(e.response.data.message)
            } else if (e.status === 500) {
                throw new HttpErrors.BadRequest("Argo is not running")

            }
            return {}
        }
    }


    @get('/argo/workflow/{name}', {
        summary: 'Get workflow by name ',
        description: 'Please enter a json format workflow',
        responses: {
            '200': {

                content: {'application/json': {schema: {type: 'string'}}},
            },
        },
    })
    async getWorkflow(
        @param.path.string('name') name: string,
        @inject(SecurityBindings.USER) currentUserProfile: UserProfile,
    ): Promise<ArgoWorkflow> {
        try {
            const res = await axios.get(this.workflowsUrl, {})

            if (res?.data?.items) {
                const {items} = res.data;
                return items.find((cI: { metadata: { name: string }; }) => cI.metadata.name.toString().trim() === name.toString().trim()) || {}

            }
            return {}
        } catch (e) {
            if (e.status === 500) {
                throw new HttpErrors.BadRequest("Argo is not running")
            } else {
                throw new HttpErrors.Conflict(e.response.data.message)
            }
        }
    }


    @authenticate('jwt')
    @get('/argo/workflow', {
        summary: 'Get all running workflows list',

        responses: {
            '200': {
                content: {'application/json': {schema: {type: 'string'}}},
            },
        },
    })
    async getWorkflowsList(
        @inject(SecurityBindings.USER) currentUserProfile: UserProfile,
    ): Promise<ArgoWorkflow[]> {

        try {
            const res = await axios.get(this.workflowsUrl);
            return res?.data || []
        } catch (e) {
            if (e.status === 500) {
                throw new HttpErrors.BadRequest("Argo is not running")
            } else {
                throw new HttpErrors.Conflict(e.response.data.message)
            }
        }
    }

    @del('/argo/{name}', {
        summary: 'Delete workflow by workflow  name',
        description: 'Execute argo Workflow',
        responses: {
            '200': {

                content: {
                    'application/json': {
                        schema: {properties: {success: {type: 'boolean'}}},
                    },
                },
            },
        }
    })
    async deleteByName(
        @inject(SecurityBindings.USER) currentUserProfile: UserProfile,
        @param.path.string('name') name: string
    ): Promise<object> {
        try {

            const res = await axios.delete(`${this.workflowsUrl}/${name}`)
            return res?.data === {} ? {success: true} : res.data;
        } catch (e) {
            if (e.status === 500) {
                throw new HttpErrors.BadRequest("Argo is not running")
            } else {
                throw new HttpErrors.Conflict(e.response.data.message)
            }
        }

    }


    @put('/argo/workflow/{name}', {
        summary: 'Set workflow action',
        description: 'Choose workflow action from examples list',
        responses: {
            '200': {

                content: {
                    'application/json': {
                        schema: {properties: {success: {type: 'boolean'}}}
                    }
                }
            }
        }
    })
    async setAction(
        @requestBody({
            description: 'Argo Workflow set Action',
            required: true,
            content: {
                'application/json': {schema: argoActionsSchema}
            },
        })
            action: string,
        @param.path.string('name') name: string,
        @inject(SecurityBindings.USER) currentUserProfile: UserProfile
    ): Promise<object> {

        try {

            const res = await axios.put(`${this.workflowsUrl}/${name.toString().trim()}/${action.toString().trim()}`)
            return res?.data === {} ? {success: true} : res.data;

        } catch (e) {
            if (e.status === 500) {
                throw new HttpErrors.BadRequest("Argo is not running")
            } else {
                throw new HttpErrors.Conflict(e.response.data.message)
            }
        }
    }


    @get('/argo/cron-workflows/', {
        summary: 'Get active cron workflows list',

        responses: {
            '200': {
                content: {'application/json': {schema: {type: 'string'}}},
            },
        },
    })
    async getCronWorkflowsList(
        @inject(SecurityBindings.USER) currentUserProfile: UserProfile,
    ): Promise<ArgoWorkflow[]> {
        try {

            const res = await axios.get(this.cronWorkflowsUrl)
            return res?.data || []

        } catch (e) {
            if (e.status === 500) {
                throw new HttpErrors.BadRequest("Argo is not running")
            } else {
                throw new HttpErrors.Conflict(e.response.data.message)
            }
        }
    }


    @put('/argo/cron-workflow/{name}', {
        summary: 'Set cron-workflow action',
        responses: {
            '200': {

                content: {
                    'application/json': {
                        schema: {properties: {success: {type: 'boolean'}}}
                    }
                }
            }
        }
    })
    async setCronAction(
        @requestBody({
            description: 'Argo cron-workflow set Action',
            required: true,
            content: {
                'application/json': {schema: argoCronActionsSchema}
            },
        })
            action: { action: string },
        @param.path.string('name') name: string,
        @inject(SecurityBindings.USER) currentUserProfile: UserProfile
    ): Promise<object> {

        try {
            const res = await axios.put(`${this.cronWorkflowsUrl}/${name}/${action.toString().trim()}`)
            return res?.data === {} ? {success: true} : res.data;
        } catch (e) {
            if (e.status === 500) {
                throw new HttpErrors.BadRequest("Argo is not running")
            } else {
                throw new HttpErrors.Conflict(e.response.data.message)
            }
        }
    }

    @del('/argo/cron-workflow/{name}', {
        summary: 'Delete cron-workflow by name ',

        responses: {
            '200': {
                content: {
                    'application/json': {
                        schema: {properties: {success: {type: 'boolean'}}},
                    },
                },
            },
        }
    })
    async deleteCronWorkflowByName(
        @inject(SecurityBindings.USER) currentUserProfile: UserProfile,
        @param.path.string('name') name: string
    ): Promise<object> {

        try {

            const res = await axios.delete(`${this.cronWorkflowsUrl}/${name}`)
            return res.data || {success: true};

        } catch (e) {
            if (e?.response?.data) {
                throw new Error(e.response.data);
            } else if (e?.response?.status) {
                const {status, statusText} = e.response;
                throw new HttpErrors[status](statusText)
            }
            throw new Error(e)

        }

    }

    @get('/argo/cron-workflow/{name}', {
        summary: 'Get cron-workflow by name  ',
        responses: {
            '200': {
                content: {'application/json': {schema: {type: 'object'}}},
            },
        },
    })
    async getCronWorkflowByName(
        @param.path.string('name') name: string,
        @inject(SecurityBindings.USER) currentUserProfile: UserProfile,
    ): Promise<ArgoWorkflow> {

        try {

            const res = await axios.get(this.cronWorkflowsUrl)
            if (res?.data?.items) {

                const {items} = res.data;
                return items.find((cI: { metadata: { name: string }; }) => cI.metadata.name.toString() === name.toString()) || {}

            }
            return res.data;
        } catch (e) {
            if (e.status === 500) {
                throw new HttpErrors.BadRequest("Argo is not running")
            } else {
                throw new HttpErrors.Conflict(e.response.data.message)
            }
        }
    }

    @post('/argo/cron-workflow', {
        summary: 'Execute cron-workflow as json',
        responses: {
            '200': {

                content: {
                    'application/json': {
                        schema: {properties: {message: {type: 'string'}, code: {type: 'string'}}},
                    },
                },
            },
        },
    })
    async executeCronWorkflow(
        @requestBody({
            description: 'Execute new cron workflow',
            required: true,
            content: {
                'application/json': {
                    schema: argoCronSchema,
                    example: {
                        "apiVersion": "argoproj.io/v1alpha1",
                        "kind": "CronWorkflow",
                        "metadata": {
                            "name": "test-cron-wf"
                        },
                        "spec": {
                            "schedule": "* * * * *",
                            "concurrencyPolicy": "Replace",
                            "startingDeadlineSeconds": 0,
                            "workflowSpec": {
                                "entrypoint": "whalesay",
                                "templates": [
                                    {
                                        "name": "whalesay",
                                        "container": {
                                            "image": "alpine:3.6",
                                            "command": [
                                                "sh",
                                                "-c"
                                            ],
                                            "args": [
                                                "date; sleep 90"
                                            ]
                                        }
                                    }
                                ]
                            }
                        }
                    }
                }
            },
        }) workflowYaml: ArgoCronWorkflow,
        @inject(SecurityBindings.USER) currentUserProfile: UserProfile,
    ): Promise<ArgoResponse> {

        try {

            const res = await axios.post<ArgoResponse>(this.cronWorkflowsUrl, {cronWorkflow: workflowYaml})
            return res.data;
        } catch (e) {
            if (e.status === 500) {
                throw new HttpErrors.BadRequest("Argo is not running")
            } else {
                throw new HttpErrors.Conflict(e.response.data.message)
            }
        }
    }
}
