import {Entity, Model, model, property} from '@loopback/repository';

@model()
export class RequestsRate extends Entity {

  @property({
    type: 'string',
    id: true,
    generated: false,
    defaultFn: 'uuidv4',
  })
  id: string;
  @property({
    type: 'string',
    required: true,
  })
  host: string;

  @property({
    type: 'string',
    required: true,
  })
  email: string;

  @property({
    type: 'number',
    required: true,
    postgresql: {
      dataType: 'bigint',
    }
  })
  lastRequest: number;



  @property({
    type: 'number',
    required: true,
    default:0
  })
  retries: number;

  // Define well-known properties here

  // Indexer property to allow additional data
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [prop: string]: any;

  constructor(data?: Partial<RequestsRate>) {
    super(data);
  }
}

export interface RequestsRateRelations {
  // describe navigational properties here
}

export type RequestsRateWithRelations = RequestsRate & RequestsRateRelations;
