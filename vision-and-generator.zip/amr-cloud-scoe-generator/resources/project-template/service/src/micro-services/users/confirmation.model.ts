import {Entity, model, property} from '@loopback/repository';

@model()
export class Confirmation extends Entity {
    @property({
        type: 'string',
        id: true,
        generated: false,
        defaultFn: 'uuidv4',
    })
    id: string;

    @property({
        type: 'string',
    })
    userId?: string;

    @property({
        type: 'string',
        required: true,
    })
    token: string;
    @property({
        type: 'string',
        required: true,
    })
    confirmationCode: string;

    @property({
        type: 'number',
        required: true,
        postgresql: {
            dataType: 'bigint',
        }
    })
    expiration: number;


    constructor(data?: Partial<Confirmation>) {
        super(data);
    }
}

export interface ConfirmationRelations {
    // describe navigational properties here
}

export type ConfirmationWithRelations = Confirmation & ConfirmationRelations;
