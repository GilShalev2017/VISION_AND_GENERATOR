import {Entity, hasOne, model, property, hasMany} from '@loopback/repository';
import {AuthLevel, Gender} from "../../models/enums.model";
import {UserCredentials} from "./user-credentials.model";

@model({
    settings: {
        strict: false,
    },
})
export class User extends Entity {
    @property({
        type: 'string',
        id: true,
        generated: false,
        defaultFn: 'uuidv4',
    })
    id: string;

    @property({
        type: 'string',
    })
    email: string;

    @hasOne(() => UserCredentials)
    userCredentials: UserCredentials;

    @property({
        type: 'string',
        mysql: {columnName: 'verificationToken', dataType: 'varchar', dataLength: 256, nullable: 'N'},
    })
    verificationToken?: string;

    @property({
        type: 'string',
    })
    firstName?: string;

    @property({
        type: 'string',
    })
    lastName?: string;

    @property({
        type: 'string',
        jsonSchema: {
            enum: Object.values(AuthLevel),
        },
    })
    authLevel?: AuthLevel;

    constructor(data?: Partial<User>) {
        super(data);
    }
}

export interface MevolveUserRelations {
    // describe navigational properties here
}

export type UserWithRelations = User & MevolveUserRelations;


export class NewMevolveUserModel extends User {
    @property({
        type: 'string',
        required: true,
    })
    password: string;
}
