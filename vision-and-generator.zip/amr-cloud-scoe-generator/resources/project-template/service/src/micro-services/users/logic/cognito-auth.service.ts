import {NewMevolveUserModel} from "../../../models";
import {bind, BindingScope} from "@loopback/core";
import {Credentials, TokenObject} from "@loopback/authentication-jwt";
import {
    AbstractAuthService,
    ILoginResponseBase,
    LoginResponse,
    LoginResponseBase,
    PasswordResetRequest,
    ChangePasswordRequest,
    ChangePasswordResponse,
    DeleteResponse,
} from "./abstract-auth.service";
import AWS, {CognitoIdentityServiceProvider} from "aws-sdk";
import proxy from "proxy-agent";
import * as crypto from "crypto";
import {HttpErrors} from "@loopback/rest";
import _ from "lodash";
import {repository} from "@loopback/repository";
import {UserRepository} from "../user.repository";
import {securityId, UserProfile} from "@loopback/security";
import {PasswordType} from 'aws-sdk/clients/cognitoidentityserviceprovider';

@bind({scope: BindingScope.TRANSIENT})
export class CognitoAuthService implements AbstractAuthService {
    cognito: CognitoIdentityServiceProvider;

    constructor(
        @repository(UserRepository) protected userRepository: UserRepository,
    ) {
        if (process.env.IS_LOCALHOST_ENV?.toString() === "true"  || process.env.USE_PROXY) {
            const httpOptions = {agent: proxy("http://proxy-us.intel.com:911")}
            AWS.config.update({httpOptions});
        }

        this.cognito = new AWS.CognitoIdentityServiceProvider();
    }

    async createConfirmedUser(newUserRequest: NewMevolveUserModel): Promise<LoginResponse> {
        await this.signUp(newUserRequest);
        try {
            await this.cognito.adminConfirmSignUp({
                UserPoolId: process.env.AWS_COGNITO_USER_POOL,
                Username: newUserRequest.email
            }).promise();
        } catch (e) {
            console.log("Error confirming user", e);
            throw new Error("Unknown error in resetPassword");
        }
        return this.login({
            email: newUserRequest.email,
            password: newUserRequest.password
        })
    }

    async refresh(refreshToken: string, userProfile: UserProfile): Promise<TokenObject> {
        try {
            console.log(refreshToken);
            const hash = this.getHash(userProfile[securityId]);

            const loginResponse = await this.cognito.adminInitiateAuth({
                UserPoolId: process.env.AWS_COGNITO_USER_POOL,
                ClientId: process.env.AWS_COGNITO_CLIENT_ID,
                AuthFlow: "REFRESH_TOKEN_AUTH",
                AuthParameters: {
                    REFRESH_TOKEN: refreshToken,
                    SECRET_HASH: hash
                }
            }).promise();

            console.log("loginResponse", loginResponse);
            return {
                    accessToken: loginResponse.AuthenticationResult?.IdToken ?? '',
                    expiresIn: '' + loginResponse.AuthenticationResult?.ExpiresIn,
                    refreshToken: loginResponse.AuthenticationResult?.RefreshToken
            }
        } catch (e) {
            console.log("Error refresh", e);
            // if (e?.code === 'CodeMismatchException') {
            //     throw new HttpErrors.BadRequest("INVALID_VERIFICATION_CODE");
            // }
            throw new Error("Unknown error in resetPassword");
        }
    }

    getHash(username: string) {
        return crypto.createHmac('SHA256', process.env.AWS_COGNITO_CLIENT_SECRET)
            .update(username + process.env.AWS_COGNITO_CLIENT_ID)
            .digest('base64');
    }

    async signUp(newUserRequest: NewMevolveUserModel): Promise<LoginResponse> {
        try {
            const hash = this.getHash(newUserRequest.email);

            if (newUserRequest.verificationToken) {
                console.log("verifying", newUserRequest.email);
                await this.cognito.confirmSignUp({
                    ClientId: process.env.AWS_COGNITO_CLIENT_ID,
                    Username: newUserRequest.email,
                    ConfirmationCode: newUserRequest.verificationToken,
                    SecretHash: hash
                }).promise();
                return await this.login({
                    email: newUserRequest.email,
                    password: newUserRequest.password
                });
            } else {
                const response = await this.cognito.signUp({
                    ClientId: process.env.AWS_COGNITO_CLIENT_ID,
                    SecretHash: hash,
                    Username: newUserRequest.email,
                    Password: newUserRequest.password
                }).promise();
                console.log("Signed up successfully", response);

                await this.userRepository.create({
                    ..._.omit(newUserRequest, 'password', 'password2'),
                    id: response.UserSub
                });
                return {
                    identifier: "confirmationCodeRequired",
                    token: {
                        accessToken: ''
                    }
                }
            }
        } catch (e) {
            console.log("Error signing up", e);
            if (e?.code === 'UsernameExistsException') {
                throw new HttpErrors.BadRequest("EMAIL_ALREADY_EXISTS");
            }
            throw new HttpErrors.BadRequest(e?.code);
        }
    }

    async login(credentials: Credentials): Promise<LoginResponse> {
        try {
            const hash = this.getHash(credentials.email);

            const loginResponse = await this.cognito.adminInitiateAuth({
                UserPoolId: process.env.AWS_COGNITO_USER_POOL,
                ClientId: process.env.AWS_COGNITO_CLIENT_ID,
                AuthFlow: "ADMIN_USER_PASSWORD_AUTH",
                AuthParameters: {
                    USERNAME: credentials.email,
                    PASSWORD: credentials.password,
                    SECRET_HASH: hash
                }
            }).promise();

            return {
                token: {
                    accessToken: loginResponse.AuthenticationResult?.IdToken ?? '',
                    expiresIn: '' + loginResponse.AuthenticationResult?.ExpiresIn,
                    refreshToken: loginResponse.AuthenticationResult?.RefreshToken,
                    authToken: loginResponse.AuthenticationResult?.AccessToken ?? '',
                },
                identifier: 'login',
                apeiron: false
            }
        } catch (e) {
            console.log("Error signing up", e);
            if (e?.code === 'NotAuthorizedException') {
                throw new HttpErrors.BadRequest("WRONG_USERNAME_PASSWORD");
            }
            throw new Error("Unknown error in signup");
        }
    }

    async forgotPassword(email: string): Promise<ILoginResponseBase> {
        try {
            const hash = this.getHash(email);

            const response = await this.cognito.forgotPassword({
                ClientId: process.env.AWS_COGNITO_CLIENT_ID,
                Username: email,
                SecretHash: hash
            }).promise();

            console.log("response", response);
            return {identifier: "passwordReset"};
        } catch (e) {
            console.log("Error forgot password", e);
            throw new Error("Unknown error in forgot password");
        }
    }

    async resetPassword(request: PasswordResetRequest): Promise<ILoginResponseBase> {
        if (!request.email) {
            throw new HttpErrors.BadRequest("USERNAME_NOT_SUPPLIED");
        }
        try {
            const hash = this.getHash(request.email);

            const response = await this.cognito.confirmForgotPassword({
                ClientId: process.env.AWS_COGNITO_CLIENT_ID,
                Username: request.email,
                ConfirmationCode: request.confirmationCode,
                Password: request.password,
                SecretHash: hash
            }).promise();

            console.log("response", response);
            return {identifier: "passwordUpdate"};
        } catch (e) {
            console.log("Error resetPassword", e);
            if (e?.code === 'CodeMismatchException') {
                throw new HttpErrors.BadRequest("INVALID_VERIFICATION_CODE");
            } else if (e?.code === 'InvalidPasswordException') {
                throw new HttpErrors.BadRequest("INVALID_PASSWORD");
            } else if (e?.code === 'ExpiredCodeException') {
                throw new HttpErrors.BadRequest("VERIFICATION_CODE_EXPIRED");
            }
            throw new Error("Unknown error in resetPassword");
        }
    }

    async changePassword(request: ChangePasswordRequest): Promise<ChangePasswordResponse> {
        try {
            const response = await this.cognito.changePassword({
                AccessToken: request.authToken,
                PreviousPassword: request.previousPassword,
                ProposedPassword: request.proposedPassword
            }).promise();
            console.log(response);
            return {
                status: 'success'
            };
        } catch (e) {
            console.log("Error resetPassword", e);
            if (e?.code === 'InvalidPasswordException') {
                throw new HttpErrors.BadRequest("INVALID_PASSWORD");
            }
            throw new Error("Unknown error in password change");
        }
    }

    async deleteUser(accessToken: string): Promise<DeleteResponse> {
        try {
            console.log(accessToken)
            const response = await this.cognito.deleteUser({
                AccessToken: accessToken
            }).promise();
            console.log(response);
            return {
                status: 'success'
            };
        } catch(e) {
            console.log(e)
            return e;
        }
    }
}
