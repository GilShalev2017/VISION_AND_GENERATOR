import {DefaultCrudRepository} from '@loopback/repository';
import {DbDataSource} from '../../datasources';
import {inject} from '@loopback/core';
import {UserCredentials} from "./user-credentials.model";

export class UserCredentialsRepository extends DefaultCrudRepository<
  UserCredentials,
  typeof UserCredentials.prototype.id,
    UserCredentials
> {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(UserCredentials, dataSource);
  }
}
