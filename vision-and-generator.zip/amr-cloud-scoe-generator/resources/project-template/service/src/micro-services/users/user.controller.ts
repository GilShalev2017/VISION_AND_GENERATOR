import {Count, CountSchema, Filter, FilterExcludingWhere, repository, Where,} from '@loopback/repository';
import {
    del,
    get,
    getModelSchemaRef,
    HttpErrors,
    param,
    patch,
    post,
    put,
    requestBody,
    SchemaObject,
} from '@loopback/rest';
import {
    GetUsersResponse,
    NewMevolveUserModel,
    QMessagePushNotification,
    QMessageTopicSubscription,
    QMessegeType,
    TopicQMessagePushNotification,
    User,
} from '../../models';
import {
    UserRepository
} from '../../repositories';
import {authenticate} from "@loopback/authentication";
import {inject, service} from "@loopback/core";
import {SecurityBindings, securityId, UserProfile} from "@loopback/security";
import {AuthorizationService, RabbitMqService} from "../../services";
import {genSalt, hash} from "bcryptjs";
import {PushNotificationService} from "../../services/push-notification.service";
import {
    ChangePassBody,
    ChangePasswordRequest,
    AbstractAuthService,
    DeleteResponse,
    // DeleteSelfBody,
    DeleteUserRequest
} from "./logic/abstract-auth.service";

const topicSchema: SchemaObject = {
    type: 'object',
    required: ['topic', 'tokens'],
    properties: {
        topic: {
            type: 'string',
        },
        tokens: {
            type: 'array',
            items: {
                token: 'string',
                minItems: 1
            }
        },
    },
};
const notificationSchema: SchemaObject = {
    type: 'object',
    required: ['title', 'body', 'tokens'],
    properties: {
        title: {
            type: 'string'
        },
        body: {
            type: 'string'
        },
        userId: {type: 'string'},
        tokens: {
            type: 'array',
            items: {
                token: 'string',
                minItems: 1
            }
        }
    }

}

const topicNotificationSchema: SchemaObject = {
    type: 'object',
    required: ['title', 'body', 'topic'],
    properties: {
        title: {
            type: 'string'
        },
        body: {
            type: 'string'
        },
        userId: {type: 'string'},
        topic: {
            type: 'string',

        }
    }

}

export interface DeleteUserRequest {
    accessToken: string;
}

const DeleteSchema: SchemaObject = {
    type: 'object',
    required: ['accessToken'],
    properties: {
        accessToken: {
            type: 'string',
        },
    },
};
export const DeleteSelfBody = {
    description: 'The input of login function',
    required: true,
    content: {
        'application/json': {schema: DeleteSchema},
    },
};

@authenticate('jwt')
export class UserController {
    constructor(
        @repository(UserRepository) public userRepository: UserRepository,
        @service(AuthorizationService) public authorizationService: AuthorizationService,
        @service(RabbitMqService) public rabbitMqService: RabbitMqService,
        @service(PushNotificationService) public notificationsService: PushNotificationService,
        @inject('services.AuthService') private authService: AbstractAuthService,
    ) {

    }

    @post('/users', {
        responses: {
            '200': {
                description: 'User model instance',
                content: {'application/json': {schema: getModelSchemaRef(User)}},
            },
        },
    })
    async create(
        @requestBody({
            content: {
                'application/json': {
                    schema: getModelSchemaRef(User, {
                        title: 'NewUser',
                        exclude: ['id'],
                    }),
                },
            },
        })
            user: Omit<User, 'id'>,
        @inject(SecurityBindings.USER) currentUserProfile: UserProfile,
    ): Promise<User> {
        await this.authorizationService.guardAdmin(currentUserProfile[securityId]);
        return this.userRepository.create(user);
    }


    @get('/users/count', {
        responses: {
            '200': {
                description: 'User model count',
                content: {'application/json': {schema: CountSchema}},
            },
        },
    })
    async count(
        @param.where(User) where?: Where<User>,
    ): Promise<Count> {

        return this.userRepository.count(where);
    }

    @get('/users', {
        responses: {
            '200': {
                description: 'Array of User model instances',
                content: {
                    'application/json': {
                        schema: {
                            type: 'array',
                            items: getModelSchemaRef(User, {includeRelations: true}),
                        },
                    },
                },
            },
        },
    })
    async find(
        @inject(SecurityBindings.USER) currentUserProfile: UserProfile,
        @param.filter(User) filter?: Filter<User>,
    ): Promise<User[]> {
        await this.authorizationService.guardAdmin(currentUserProfile[securityId]);
        return this.userRepository.find(filter);
    }

    @patch('/users', {
        responses: {
            '200': {
                description: 'User PATCH success count',
                content: {'application/json': {schema: CountSchema}},
            },
        },
    })
    async updateAll(
        @requestBody({
            content: {
                'application/json': {
                    schema: getModelSchemaRef(User, {partial: true}),
                },
            },
        })
            user: User,
        @inject(SecurityBindings.USER) currentUserProfile: UserProfile,
        @param.where(User) where?: Where<User>,
    ): Promise<Count> {
        await this.authorizationService.guardAdmin(currentUserProfile[securityId]);
        return this.userRepository.updateAll(user, where);
    }

    @get('/users/{id}', {
        responses: {
            '200': {
                description: 'User model instance',
                content: {
                    'application/json': {
                        schema: getModelSchemaRef(User, {includeRelations: true}),
                    },
                },
            },
        },
    })
    async findById(
        @param.path.string('id') id: string,
        @inject(SecurityBindings.USER) currentUserProfile: UserProfile,
        @param.filter(User, {exclude: 'where'}) filter?: FilterExcludingWhere<User>
    ): Promise<User> {
        await this.authorizationService.guardAdmin(currentUserProfile[securityId]);
        return this.userRepository.findById(id, filter);
    }

    @patch('/users/{id}', {
        responses: {
            '204': {
                description: 'User PATCH success',
            },
        },
    })
    async updateById(
        @param.path.string('id') id: string,
        @requestBody({
            content: {
                'application/json': {
                    schema: getModelSchemaRef(User, {partial: true}),
                },
            },
        })
            user: NewMevolveUserModel,
        @inject(SecurityBindings.USER) currentUserProfile: UserProfile,
    ): Promise<number> {

        await this.authorizationService.guardAdmin(currentUserProfile[securityId]);
        const {email, password} = user;
        if (password) {
            if (!this.authorizationService.passwordValidation(password)) {
                throw new HttpErrors.Unauthorized("Password requires at least one upper case letter and min of 8 digits");

            }

        }
        if (email) {

            const doesEmailExists = await this.userRepository.find({where: {email: email}});
            if (!doesEmailExists || doesEmailExists.length > 0) {
                throw new HttpErrors.Conflict('Email entered already exists')

            }
        }
        try {
            await this.userRepository.updateById(id, user);

            if (user.password) {
                const saltedPassword = await hash(user.password, await genSalt());
                await this.userRepository.userCredentials(id).patch({password: saltedPassword});
            }
            return 1;
        } catch (e) {
            console.error(e)
            return -1;
        }
    }

    @put('/users/{id}', {
        responses: {
            '204': {
                description: 'User PUT success',
            },
        },
    })
    async replaceById(
        @param.path.string('id') id: string,
        @requestBody() user: User,
        @inject(SecurityBindings.USER) currentUserProfile: UserProfile,
    ): Promise<void> {
        await this.authorizationService.guardAdmin(currentUserProfile[securityId]);
        await this.userRepository.replaceById(id, user);
    }

    @del('/users/{id}', {
        responses: {
            '204': {
                description: 'User DELETE success',
            },
        },
    })
    async deleteById(
        @inject(SecurityBindings.USER) currentUserProfile: UserProfile,
        @param.path.string('id') id: string
    ): Promise<void> {
        await this.authorizationService.guardAdmin(currentUserProfile[securityId]);
        await this.userRepository.deleteById(id);
    }

    @del('/users', {
        responses: {
            '204': {
                description: 'User DELETE success',
            },
        },
    })
    async delete(
        @inject(SecurityBindings.USER) currentUserProfile: UserProfile,
        @param.where(User) where?: Where<User>,
    ): Promise<void> {
        await this.authorizationService.guardAdmin(currentUserProfile[securityId]);
        await this.userRepository.deleteAll(where);
    }

    @post('/users/send-topic-push-notification', {
        responses: {
            '200': {
                description: 'Success / Failure topic notification send',
                content: {'application/json': {schema: {title: 'string', subtitle: 'string', body: 'string'}}},
            },
        },
    })
    async sendPushNotificationToTopic(
        @requestBody({
            description: 'Send push notification to topic',
            required: true,
            content: {
                'application/json': {schema: topicNotificationSchema},
            },
        }) data: TopicQMessagePushNotification,
        @inject(SecurityBindings.USER) currentUserProfile: UserProfile,
    ): Promise<string> {

        const message = {
            ...data,
            type: QMessegeType.SEND_PUSH_NOTIFICATION_TO_TOPIC,

        }
        this.rabbitMqService.send(message);
        // const sendRes = await this.notificationsService.sendPushNotificationToTopic(message)
        return 'success'
    }

    @post('/users/send-push-notification', {
        responses: {
            '200': {
                description: 'push notification Success / Failure  ',
                content: {'application/json': {schema: {title: 'string', subtitle: 'string', body: 'string'}}},
            },
        },
    })

    async sendPushNotificationToDevice(
        @requestBody({
            description: 'Send push notification to multiple devices',
            required: true,
            content: {
                'application/json': {schema: notificationSchema},
            },
        }) data: QMessagePushNotification,
        @inject(SecurityBindings.USER) currentUserProfile: UserProfile,
    ): Promise<string> {
        const message = {
            ...data,
            type: QMessegeType.SEND_PUSH_NOTIFICATION_TO_DEVICE

        }

        this.rabbitMqService.send(message);

        // const sendRes = await this.notificationsService.sendPushNotification(message)
        return 'success'


    }

    @post('/users/subscribeToTopic', {
        responses: {
            '200': {
                description: 'topic subscription Success / Failure ',
                content: {'application/json': {schema: {type: 'string'}}},
            },
        },
    })

    async subscribeToTopic(
        @requestBody({
            description: 'Topic name and to be registered tokens',
            required: true,
            content: {
                'application/json': {schema: topicSchema},
            },
        }) data: QMessageTopicSubscription,
        @inject(SecurityBindings.USER) currentUserProfile: UserProfile,
    ): Promise<string> {

        const message = {
            ...data,
            type: QMessegeType.SUBSCRIBE_TO_TOPIC
        }
        this.rabbitMqService.send(message);

        // const sendRes = await this.notificationsService.subscribeToTopic(message);
        return 'success'
    }

    @post('/users/unSubscribeFromTopic', {
        responses: {
            '200': {
                description: 'topic unsubscribing Success / Failure',
                'application/json': {
                    schema: {
                        type: 'string'
                    },
                },

            },
        },
    })
    async unSubscribeFromTopic(
        @requestBody({
            description: 'The input of login function',
            required: true,
            content: {
                'application/json': {schema: topicSchema},
            },
        }) data: QMessageTopicSubscription,
        @inject(SecurityBindings.USER) currentUserProfile: UserProfile,
    ): Promise<string> {
        const message = {
            ...data,
            type: QMessegeType.UNSUBSCRIBE_FROM_TOPIC
        }
        this.rabbitMqService.send(message);

        // const sendRes = await this.notificationsService.unSubscribeFromTopic(message);
        // return sendRes;
        return 'success'
    }


    @post('/users/delete', {
        responses: {
            '200': {
                description: 'Token',
                content: {
                    'application/json': {
                        schema: {
                            type: 'object',
                            properties: {
                                status: 'string'
                            },
                        },
                    },
                },
            },
        },
    })
    async deleteSelf(
        @requestBody(DeleteSelfBody) deleteUserRequest: DeleteUserRequest,
        @inject(SecurityBindings.USER) currentUserProfile: UserProfile,
    ): Promise<DeleteResponse> {
        try {
            const res = await this.authService.deleteUser(deleteUserRequest.authToken);
            await this.userRepository.deleteById(currentUserProfile[securityId]);
            return res;
        } catch (e) {
            console.log(e);
            return {
                status: 'Error: User deletion failed'
            };
        }
    }

    @post('/users/change-password', {
        responses: {
            '200': {
                description: 'Token',
                content: {
                    'application/json': {
                        schema: {
                            type: 'object',
                            properties: {
                                status: 'string'
                            },
                        },
                    },
                },
            },
        },
    })
    async changePassword(
        @requestBody(ChangePassBody) changePassRequest: ChangePasswordRequest,
        @inject(SecurityBindings.USER) currentUserProfile: UserProfile,
    ): Promise<DeleteResponse> {
        try {
            return await this.authService.changePassword(changePassRequest);
        } catch (e) {
            console.log(e);
            throw new HttpErrors.NotAcceptable('One or more fields of the password change request is incorrect')
        }
    }
}

