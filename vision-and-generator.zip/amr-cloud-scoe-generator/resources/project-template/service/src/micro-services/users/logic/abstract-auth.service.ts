import {NewMevolveUserModel} from '../../../models';
import {Credentials, TokenObject} from '@loopback/authentication-jwt';
import {getModelSchemaRef, SchemaObject} from '@loopback/rest';
import {Model, model, property} from '@loopback/repository';
import {UserProfile} from '@loopback/security';

const ChangePassSchema: SchemaObject = {
    type: 'object',
    required: ['authToken', 'previousPassword', 'proposedPassword'],
    properties: {
        authToken: {
            type: 'string',
        },
        previousPassword: {
            type: 'string',
        },
        proposedPassword: {
            type: 'string',
        },
    },
};
export const ChangePassBody = {
    description: 'The input of change password function',
    required: true,
    content: {
        'application/json': {schema: ChangePassSchema},
    },
};

export interface DeleteUserRequest {
    authToken: string;
}

const DeleteSchema: SchemaObject = {
    type: 'object',
    required: ['authToken'],
    properties: {
        authToken: {
            type: 'string',
        },
    },
};
export const DeleteSelfBody = {
    description: 'The input of delete self function',
    required: true,
    content: {
        'application/json': {schema: DeleteSchema},
    },
};

export interface ILoginResponseBase {
    identifier: string;
}

export interface DevExTokenObject extends TokenObject {
    deviceToken?: string;
    authToken?: string;
}

export interface LoginResponse {
    identifier: string;
    token: DevExTokenObject;
    // Deprecated
    deviceToken?: string;
    apeiron?: boolean;
    id?: string
}

export interface DeleteResponse {
    status?: string;
}

@model()
export class PasswordResetRequest extends Model {
    @property()
    email: string;
    @property()
    confirmationCode: string;
    @property()
    password: string;
    @property()
    password2: string;
}
@model()
export class EmailRequest extends Model {
    @property()
    email: string;
}
@model()
export class LoginResponseBase extends Model {
    @property()
    identifier: string;
}
export const getRequestSchema = <T extends object>(modelObj: Function & {prototype: T}) => {
    return {
        required: true,
        content: {
            'application/json': {schema: getModelSchemaRef(modelObj)},
        }
    }
}
export const getResponseSchema = <T extends object>(modelObj: Function & {prototype: T}) => {
    return {
        responses: {
            '200': {
                description: 'User',
                content: {
                    'application/json': {
                        schema: getModelSchemaRef(modelObj),
                    },
                },
            },
        },
    }}

export interface ChangePasswordResponse {
    status?: string;
}

@model()
export class ChangePasswordRequest extends Model {
    @property()
    authToken: string;
    @property()
    previousPassword: string;
    @property()
    proposedPassword: string;
}


export abstract class AbstractAuthService {

    abstract signUp(newUserRequest: NewMevolveUserModel): Promise<LoginResponse>;

    abstract login(credentials: Credentials): Promise<LoginResponse>;

    abstract refresh(refreshToken: string, userProfile: UserProfile): Promise<TokenObject>;

    abstract forgotPassword(email: string): Promise<ILoginResponseBase>;

    abstract resetPassword(request: PasswordResetRequest): Promise<ILoginResponseBase>;

    abstract createConfirmedUser(newUserRequest: NewMevolveUserModel): Promise<LoginResponse>;

    abstract changePassword(request: ChangePasswordRequest): Promise<ChangePasswordResponse>;

    abstract deleteUser(request: string): Promise<DeleteResponse>;
}


