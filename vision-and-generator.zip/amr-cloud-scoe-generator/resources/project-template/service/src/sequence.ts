import {MiddlewareSequence, RequestContext} from '@loopback/rest';

export class MySequence extends MiddlewareSequence {
    handle(context: RequestContext): Promise<void> {
        console.log("in sequence");
        return super.handle(context);
    }
}
