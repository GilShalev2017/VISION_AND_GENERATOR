import AWS from "aws-sdk";
import proxy from "proxy-agent";

export class AwsUtilsService {

    static async downloadS3(bucket: string, key: string) {
        console.log("using access key", process.env.AWS_ACCESS_KEY_ID);
        const s3 = new AWS.S3();
        const url = s3.getSignedUrl('getObject', {
            Bucket: bucket,
            Key: key,
            Expires: 60 * 60
        })
        return url;
    }

    static async sendEmail(to: string, subject: string, message: string) {


        const config = {region: 'us-east-1', httpOptions: {}};

        if (process?.env?.IS_LOCALHOST_ENV?.toString() === "true"  || process.env.USE_PROXY) {

            const httpOptions = {agent: proxy("http://proxy-us.intel.com:911")}
            config.httpOptions = httpOptions;
        }

        AWS.config.update({...config});

        const params = {
            Destination: { /* required */
                // CcAddresses: [],
                ToAddresses: [to]
            },
            Message: { /* required */
                Body: { /* required */
                    // Html: {
                    //   Charset: "UTF-8",
                    //   Data: "HTML_FORMAT_BODY"
                    // },
                    Text: {
                        Charset: "UTF-8",
                        Data: message
                    }
                },
                Subject: {
                    Charset: 'UTF-8',
                    Data: subject
                }
            },
            Source: 'info@mevolve-cloud.com',
        };

        const sendPromise = new AWS.SES({apiVersion: '2010-12-01'}).sendEmail(params).promise();
        sendPromise.then(
            (data) => {
                console.log("email id", data.MessageId);
            }).catch(
            (err) => {
                console.error(err, err.stack);
            });
    }
}
