import {bind, BindingScope, inject, Interceptor} from '@loopback/core';
import {ConfirmationRepository, RequestsRateRepository, UserRepository} from "../repositories";
import {repository} from "@loopback/repository";
import {AuthLevel, Confirmation} from "../models";
import crypto from 'crypto';
import {HttpErrors, Request, RestBindings} from "@loopback/rest";


@bind({scope: BindingScope.TRANSIENT})
export class AuthorizationService {
    constructor(
        @repository(UserRepository) public userRepository: UserRepository,
        @repository(RequestsRateRepository) public requestRateRepository: RequestsRateRepository,
        @inject(RestBindings.Http.REQUEST) private request: Request,
        @repository(ConfirmationRepository) public confirmationRepository: ConfirmationRepository,
    ) {
    }

    async validateRequestContent(request: Request, email: string): Promise<boolean> {


        const clientIP = this.getClientIp(request);

        const now = new Date().valueOf();
        const query = {
            where: {
                retries: {gte: 5},
                or: [
                    {email: email, lastRequest: {gte: (now - 360000)}},
                    {host: clientIP, lastRequest: {gte: (now - 360000)}},
                ]
            }
        };
        const doesExist = await this.requestRateRepository.find({...query});
        if (doesExist?.length > 0) {
            throw new HttpErrors.Forbidden("User has been blocked. please try again later.");
            return false;
        } else {


            const currReqArr = await this.requestRateRepository.find({
                where: {
                    or: [
                        {email: email},
                        {host: clientIP}]
                }
            });
            if (currReqArr?.length > 0) {
                for (const item of currReqArr) {
                    const isValidTimeGap = (now - item.lastRequest) > 60000;
                    if (!isValidTimeGap) {
                        await this.requestRateRepository.updateById(item.id, {
                            retries: item.retries + 1
                        });

                    } else {
                        await this.requestRateRepository.updateById(item.id, {
                            retries: 1,
                            lastRequest: now
                        });

                    }

                }

            } else {

                await this.requestRateRepository.create({
                    host: clientIP,
                    email: email,
                    lastRequest: now,
                    retries: 1
                });

            }


        }


        return true;
    }

    async guardAdmin(userId: string) {
        const user = await this.userRepository.findById(userId);
        if (!user.authLevel || user.authLevel === AuthLevel.USER) {
            throw new Error("Invalid permission");
        }
        return user;
    }

    async generateCryptoToken(stringBase: string, byteLength: number): Promise<string> {

        return new Promise((resolve, reject) => {
            crypto.randomBytes(byteLength, (err, buffer) => {
                if (err) {
                    reject(err);
                } else {
                    const token = buffer.toString(stringBase);
                    resolve(token.toString().replace(/[^a-zA-Z0-9 ]/g, '1'))

                }
            });
        });
    }

    passwordValidation(password: string): boolean {
        const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)[a-zA-Z\d]{8,}$/;
        return passwordRegex.test(password.toString());


    }

    emailValidation(email: string): boolean {
        const emailRegex = /^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/;
        return emailRegex.test(email);

    }

    getClientIp(req: Request) {
        try {
            if (req.connection?.remoteAddress) {
                return req.connection.remoteAddress.toString();
            } else if (req.headers?.["X-Forwarded-For"]) {
                req.headers?.["X-Forwarded-For"].toString();
            }
            return "unknown"

        } catch (e) {
            console.log(e);
            return "unknown";
        }

    };


    async confirmationCodeValidator(confirmationCode: string): Promise<Confirmation[]> {
        const isConfirmedRes = await this.confirmationRepository.find({
            where: {
                confirmationCode: confirmationCode

            }
        })
        //check for confirmation code existence
        if (!isConfirmedRes || isConfirmedRes?.length === 0) {
            throw new HttpErrors.NotAcceptable('Confirmation code is invalid')
        }
        //check for valid userId
        const userId = isConfirmedRes?.length > 0 && isConfirmedRes[0]?.userId;
        if (!userId) {
            throw new HttpErrors.Forbidden("Confirmation code is invalid.");


        }
        //check for valid confirmation code retries in last housrs -> limited for 5 for now.
        const lastHourConfirmationCodes = await this.confirmationRepository.find({
            where: {
                userId: userId,
                expiration: {gte: new Date().valueOf() - 360000}
            }
        })
        //if retries amount in last hour greater than 5 retries the user is banned
        if (lastHourConfirmationCodes?.length > 5) {
            throw new HttpErrors.Forbidden("Confirmation code limit has reached. please try again in the next hour.");

        }


        const {expiration} = isConfirmedRes [0];
        const now = new Date().valueOf();
        if (!expiration || now > expiration) {
            throw new HttpErrors.NotAcceptable('Confirmation lifetime expired.please reconfirm.')

        }
        return isConfirmedRes;
    }


}
