import {bind, BindingScope, service} from '@loopback/core';
import * as admin from 'firebase-admin';
import {HttpsProxyAgent} from 'https-proxy-agent';
import {RabbitMqService} from "./rabbit-mq.service";
import {
    QMessagePushNotification,
    QMessageTopicSubscription,
    QMessegeType,
    TopicQMessagePushNotification
} from "../models";
import {AppOptions} from "firebase-admin/lib/firebase-namespace-api";
import {HttpErrors} from "@loopback/rest";

@bind({scope: BindingScope.SINGLETON})
export class PushNotificationService {

    constructor(
        @service(RabbitMqService) public rabbitMqService: RabbitMqService
    ) {
        if (process.env.MEVOLVE_SERVICE_ID !== process.env.PUSH_NOTIFICATION_SERVICE) {
            // enable this service only in the conigured service
            return;
        }
        const agent = new HttpsProxyAgent('http://proxy-chain.intel.com:912');
        //Do not forget set gcm server to: npx http-server --proxy https://proxy-chain.intel.com:912 when running
        console.log("Initializing Firebase admin from", process.env.GOOGLE_APPLICATION_CREDENTIALS);
        try {
            const config: AppOptions = {
                credential: admin.credential.applicationDefault(agent),
                databaseURL: "https://mevolve-gcp-11896186-default-rtdb.firebaseio.com"
            }
            if (process.env.LOCAL || process.env.IS_LOCALHOST_ENV) {
                config.httpAgent = agent;
            }
            admin.initializeApp(config);


            this.rabbitMqService.subscribe(QMessegeType.SEND_PUSH_NOTIFICATION_TO_DEVICE, this.sendPushNotification);
            this.rabbitMqService.subscribe(QMessegeType.SEND_PUSH_NOTIFICATION_TO_TOPIC, this.sendPushNotificationToTopic);

            this.rabbitMqService.subscribe(QMessegeType.SUBSCRIBE_TO_TOPIC, this.subscribeToTopic);
            this.rabbitMqService.subscribe(QMessegeType.UNSUBSCRIBE_FROM_TOPIC, this.unSubscribeFromTopic);

        } catch (e) {
            console.error("Failed to initialize firebase", e);
        }
    }


    async subscribeToTopic(payload: QMessageTopicSubscription): Promise<string> {
        const {tokens, topic} = payload;
        if ((!tokens || tokens.length === 0) && (!topic || topic?.toString()?.length < 2)) {
            throw new HttpErrors.Conflict("Missing tokens / topic name");

        }
        return new Promise(resolve => {
            admin.messaging().subscribeToTopic(tokens, topic)
                .then(res => {

                    console.log('Successfully subscribed to topic:', res);
                    resolve('Successfully subscribed to topic');
                })
                .catch(error => {
                    console.log('Error subscribing to topic:', error);
                    resolve(`Server Error subscribing to topic_${topic}`)
                });
        });
    }

    async unSubscribeFromTopic(payload: QMessageTopicSubscription): Promise<string> {
        const {tokens, topic} = payload;
        return new Promise(resolve => {

            admin.messaging().unsubscribeFromTopic(tokens, topic)
                .then(res => {

                    console.log('Successfully subscribed to topic:', res);
                    resolve(`Successfully subscribed to topic_${topic}`);
                })
                .catch(error => {
                    console.log('Error subscribing to topic:', error);
                    resolve(`Error subscribing to topic_${topic}`);

                });
        });
    }


    async sendPushNotificationToTopic(payload: TopicQMessagePushNotification): Promise<string> {
        console.log("iam here")
        const {type, topic, ...rest} = payload;
        if (!topic || topic?.length < 2) {
            throw new HttpErrors.Conflict("Missing topic error");

        }
        const message = {
            notification: {
                ...rest
            }
        };
        return new Promise(resolve => {
            admin.messaging().sendToTopic(topic, message)
                .then((res) => {
                    console.log('Successfully sent message:', res);
                    resolve('Successfully sent message!')

                })
                .catch((error) => {
                    console.log('Error sending message:', error);
                    resolve("Server Error occurred during notification sending")

                });
        });
    }

    async sendPushNotification(payload: QMessagePushNotification): Promise<string> {
        const {type, tokens, ...rest} = payload;
        const message = {
            notification: {
                ...rest
            }
        };
        return new Promise(resolve => {
            admin.messaging().sendToDevice(tokens, message)
                .then((res) => {
                    if (res?.failureCount && res.failureCount > 0) {
                        resolve("Error occurred during notification sending");

                    }
                    resolve('Successfully sent message!');
                })
                .catch((error) => {
                    console.log('Error sending message:', error);
                    resolve("Error occurred during notification sending")
                });
        });
    }

    sendTest() {
        const message = {
            notification: {
                "title": "Testing Notification!",
                "body": "Firebase is awesome",
            },
            token: "ekbmlyWpWWD2T10RAYNeRN:APA91bGfCkkP5_N86Yz8TyydT5y2GWfQzthmTsxaSHYWg_EFm8Zy5OSzEjqX5VhnJVmC0urBiZPOBG77gzByI78_T1mGD3eMCEBjldHKQUAwRnNwK34ITUN69MLAbomui71fOAX5NInM"
        }
        admin.messaging().send(message)
            .then((res) => {
                // Response is a message ID string.
                console.log('Successfully sent message:', res);
            })
            .catch((error) => {
                console.log('Error sending message:', error);
            });
    }
}
