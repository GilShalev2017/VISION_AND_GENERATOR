import {BootMixin} from '@loopback/boot';
import {ApplicationConfig} from '@loopback/core';
import {
  RestExplorerBindings,
  RestExplorerComponent,
} from '@loopback/rest-explorer';
import {RepositoryMixin} from '@loopback/repository';
import {RestApplication} from '@loopback/rest';
import {ServiceMixin} from '@loopback/service-proxy';
import path from 'path';
import {MySequence} from './sequence';
import {AuthenticationComponent, registerAuthenticationStrategy} from "@loopback/authentication";
import {
  JWTAuthenticationComponent,
  RefreshTokenServiceBindings,
  TokenServiceBindings,
  UserServiceBindings
} from "@loopback/authentication-jwt";
import {DbDataSource} from "./datasources";
import {UserRepository} from "./micro-services/users/user.repository";
import {CustomUserService} from "./micro-services/users/custom-user.service";
import {CognitoAuthenticationStrategy} from "./micro-services/users/logic/cognito.strategy";
import {CognitoAuthService} from "./micro-services/users/logic/cognito-auth.service";
import {UserCredentialsRepository} from "./micro-services/users/user-credentials.repository";
import {CustomAuthService} from "./micro-services/users/logic/custom-auth.service";

export {ApplicationConfig};

export class UserServiceApplication extends BootMixin(
  ServiceMixin(RepositoryMixin(RestApplication)),
) {
  constructor(options: ApplicationConfig = {}) {
    super(options);

    // Set up the custom sequence
    this.sequence(MySequence);

    // Set up default home page
    this.static('/', path.join(__dirname, '../public'));
    this.static('/dashboard/*', path.join(__dirname, '../public/dashboard/index.html'));

    // Customize @loopback/rest-explorer configuration here
    this.configure(RestExplorerBindings.COMPONENT).to({
      path: '/explorer',
    });
    this.component(RestExplorerComponent);

    this.projectRoot = __dirname;
    // Customize @loopback/boot Booter Conventions here
    this.bootOptions = {
      repositories: {
        dirs: ['repositories', 'micro-services'],
        extensions: ['.repository.js'],
        nested: true,
      },
      controllers: {
        // Customize ControllerBooter Conventions here
        dirs: ['controllers', 'micro-services'],
        extensions: ['.controller.js'],
        nested: true,
      },
    };

    this.component(AuthenticationComponent);

    if (process.env.AUTHENTICATION_STRATEGY === "LOCAL") {
      this.component(JWTAuthenticationComponent);
      this.bind(UserServiceBindings.USER_CREDENTIALS_REPOSITORY).toClass(UserCredentialsRepository);
      this.service(CustomAuthService, "AuthService");
    } else {
      registerAuthenticationStrategy(this, CognitoAuthenticationStrategy);
      this.service(CognitoAuthService, "AuthService");
    }

    this.dataSource(DbDataSource, UserServiceBindings.DATASOURCE_NAME);
    this.dataSource(DbDataSource, RefreshTokenServiceBindings.DATASOURCE_NAME);

    this.bind(UserServiceBindings.USER_SERVICE).toClass(CustomUserService);
    this.bind(UserServiceBindings.USER_REPOSITORY).toClass(UserRepository);
    this.bind(TokenServiceBindings.TOKEN_EXPIRES_IN).to('5184000');


  }
}
