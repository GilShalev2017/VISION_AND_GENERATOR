export const environment = {
  production: true,
  serverUrl: 'http://127.0.0.1/' // local
};
