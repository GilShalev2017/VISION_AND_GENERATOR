export const environment = {
  production: true,
  serverUrl: 'http://<<server_url>>/' // local
};
