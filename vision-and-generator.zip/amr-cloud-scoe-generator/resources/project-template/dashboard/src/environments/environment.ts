// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  serverUrl: "http://127.0.0.1:3070/", // local
  // serverUrl: 'http://a614f914d89db4350b0e8fdd09327e69-0550fe15a1651deb.elb.us-west-2.amazonaws.com/'  // prod
  // serverUrl: 'http://ad84c4e2a3ca340199e77a7440fb15e3-54db6c01b8f1c2f7.elb.us-west-2.amazonaws.com/'  // dev
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
