import {Component, Inject, OnInit} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import {LoadingProgress} from "../../models/interfaces";

@Component({
  selector: 'app-confirm',
  templateUrl: './confirm.component.html',
  styleUrls: ['./confirm.component.css']
})
export class ConfirmComponent implements OnInit {
  LoadingProgress: typeof LoadingProgress = LoadingProgress;

  state: LoadingProgress = LoadingProgress.DONE;
  error: string;
  okString = 'OK';
  cancelString = 'Cancel';


  constructor(
    public dialogRef: MatDialogRef<ConfirmComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    if (data.okString) { this.okString = data.okString; }
    if (data.cancelString) { this.cancelString = data.cancelString; }
  }

  ngOnInit(): void {
  }

  ok() {
    this.error = null;
    this.state = LoadingProgress.LOADING;
    const $action = this.data.doAction();
    if (!$action) {
      this.dialogRef.close('success');
      return;
    }
    $action.subscribe(response => {
      if (response?.error) {
        this.state = LoadingProgress.ERROR;
        this.error = response.error;
      } else {
        this.state = LoadingProgress.DONE;
        this.dialogRef.close('success');
      }
    }, e => {
      this.state = LoadingProgress.ERROR;
      this.error = e.message;
    });
  }

  cancel() {
    this.dialogRef.close();
  }
}
