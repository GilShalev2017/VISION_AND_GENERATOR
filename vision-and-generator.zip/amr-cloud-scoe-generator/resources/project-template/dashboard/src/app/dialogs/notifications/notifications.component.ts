import {Component, Inject, OnInit} from '@angular/core';
import {FormControl, FormGroup, Validators} from "@angular/forms";
import {FormValiations} from "../../framework/authentication/login/validations";
import {LoadingProgress, USER_ACTIONS} from "../../models/interfaces";
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material/dialog";
import {UserService} from "../../framework/authentication/user.service";
import {MatSnackBar} from "@angular/material/snack-bar";

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.css']
})
export class NotificationsComponent implements OnInit {
  notificationsForm: FormGroup;
  error: string;
  LoadingProgress = LoadingProgress;
  state: LoadingProgress = LoadingProgress.DONE;

  constructor(public dialogRef: MatDialogRef<NotificationsComponent>,
              private userService: UserService,
              @Inject(MAT_DIALOG_DATA) public data: any, private snackBar: MatSnackBar) {
  }

  ngOnInit(): void {

    this.notificationsForm = new FormGroup({
      title: new FormControl('', [Validators.required, Validators.minLength(0)]),
      subtitle: new FormControl(''),
      body: new FormControl('', [Validators.required]),
      icon: new FormControl('', [Validators.pattern('(https?://)?([\\da-z.-]+)\\.([a-z.]{2,6})[/\\w .-]*/?')]),
      clickAction: new FormControl('', [Validators.pattern('(https?://)?([\\da-z.-]+)\\.([a-z.]{2,6})[/\\w .-]*/?')]),
    });
  }

  closeDialog(): void {
    this.dialogRef.close();
  }

  handleSubmit(): void {

    const {deviceKey} = this.data.user;
    if (!deviceKey || deviceKey?.toString()?.length < 6) {
      this.error = 'User device key is invalid';
      return;
    }
    this.state = LoadingProgress.LOADING;

    const notification = {
      ...this.notificationsForm.value,
      tokens: [deviceKey]
    };
    this.userService.sendPushNotification({user: this.data.user, notification}).subscribe(response => {
      this.state = LoadingProgress.DONE;
      this.closeDialog();
      this.snackBar.open('Notification was sent successfully!', 'success', {
        duration: 2000,
      });

    }, error => {
      console.log(error);
      this.error = error;
      this.state = LoadingProgress.DONE;

    });

  }
}
