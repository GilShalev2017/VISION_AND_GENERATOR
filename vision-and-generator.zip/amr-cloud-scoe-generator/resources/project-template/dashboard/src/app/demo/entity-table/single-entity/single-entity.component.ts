import {Component, Inject, OnInit} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material/dialog";
import {LoadingProgress} from 'src/app/models/interfaces';
import {Entity, EntityService} from "../../../models/interfaces";
import {FormGroup} from "@angular/forms";

@Component({
  selector: 'app-single-entity',
  templateUrl: './single-entity.component.html',
  styleUrls: ['./single-entity.component.css']
})
export class SingleEntityComponent implements OnInit {
  LoadingProgress: typeof LoadingProgress = LoadingProgress;

  state: LoadingProgress = LoadingProgress.DONE;
  error: string;
  form: FormGroup;

  constructor(
    public dialogRef: MatDialogRef<SingleEntityComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {
      entity: Entity,
      service: EntityService
    }
  ) {
    this.form = this.data.service.getSingleForm(this.data.entity);
  }

  ngOnInit(): void {
  }

  cancel() {
    this.dialogRef.close();
  }
  returnZero() {
    return 0
  }

  save() {
    this.state = LoadingProgress.LOADING;
    this.data.service.save(this.data.entity?.id, this.form.value).subscribe(entity => {
      this.state = LoadingProgress.DONE;
      this.dialogRef.close();
    }, err => {
      this.error = err;
      this.state = LoadingProgress.ERROR;
    })
  }
}
