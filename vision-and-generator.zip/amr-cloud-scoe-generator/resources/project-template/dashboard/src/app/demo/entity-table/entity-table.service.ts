import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EntityTableService {

  constructor() { }


  formatField(type, value) {
    switch (type) {
      case 'number':
        return +value;
      case 'text':
      default:
        return value;
    }
  }

  formatEntity(fields, entity) {
    for (const field of Object.keys(fields)) {
      entity[field] = this.formatField(fields[field].type, entity[field]);
    }
  }
}
