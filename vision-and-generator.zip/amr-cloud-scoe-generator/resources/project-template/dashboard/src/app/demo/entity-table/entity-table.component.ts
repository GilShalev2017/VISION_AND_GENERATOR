import {Component, Input, OnInit} from '@angular/core';
import {LoadingProgress, USER_ACTIONS, User} from 'src/app/models/interfaces';
import {Entity, EntityService} from '../../models/interfaces';
import {Router} from '@angular/router';
import {ConfirmComponent} from "../../dialogs/confirm/confirm.component";
import {tap} from "rxjs/operators";
import {MatDialog} from "@angular/material/dialog";
import {MatSnackBar} from "@angular/material/snack-bar";
import {MatTableDataSource} from "@angular/material/table";
import {PageEvent} from "@angular/material/paginator";
import {SingleEntityComponent} from "./single-entity/single-entity.component";
import {NotificationsComponent} from "../../dialogs/notifications/notifications.component";


@Component({
  selector: 'app-entity-table',
  templateUrl: './entity-table.component.html',
  styleUrls: ['./entity-table.component.css']
})
export class EntityTableComponent implements OnInit {
  LoadingProgress = LoadingProgress;
  state: LoadingProgress = LoadingProgress.LOADING;
  entities: Entity[] = [];
  entityColumns: string[];
  displayedColumns: string[];
  dataSource = new MatTableDataSource<Entity>();
  page = 0;
  pageSize = 50;
  count = 0;

  @Input()
  resource: EntityService;

  constructor(private router: Router, public dialog: MatDialog, private snackBar: MatSnackBar) {
  }

  ngOnInit(): void {
    this.get();
    this.entityColumns = Object.keys(this.resource.fields);
    this.displayedColumns = this.entityColumns.concat(['actions']);
  }

  get() {
    this.resource.get(this.page, this.pageSize).subscribe(entitiesResponse => {
      this.state = LoadingProgress.DONE;
      this.entities = entitiesResponse;
      this.dataSource.data = entitiesResponse;
    }, err => {
      this.state = LoadingProgress.ERROR;
    });
  }

  delete(entity: Entity) {
    this.dialog.open(ConfirmComponent, {
      width: '600px',
      data: {
        action: 'Confirm Delete',
        name: `Are you sure you would like to delete this ${this.resource.displayName}?`,
        doAction: () => {
          return this.resource.delete(entity.id).pipe(tap(() => {
            this.entities.splice(this.entities.indexOf(entity), 1);
            this.dataSource.data = this.entities;

            this.snackBar.open(this.resource.displayName + ' deleted successfully!', null, {
              duration: 2000,
            });
          }));
        }
      }
    });

  }

  edit(entity: Entity) {
    this.dialog.open(SingleEntityComponent, {
      width: '600px',
      data: {
        entity,
        service: this.resource
      }
    }).afterClosed().subscribe(() => {
      this.get();
    });
  }

  changePage($event: PageEvent) {
    this.page = $event.pageIndex;
    this.get();
  }
  sendNotification(user: User) {
    if (!user?.userSettings?.enableNotifications) {
      this.snackBar.open('Selected user notifications is not enabled!', 'warning', {
        duration: 2500,
      });
      return;
    }
    this.dialog.open(NotificationsComponent, {
      height: '600px',
      width: '800px',
      data: {user, mode: USER_ACTIONS.USER_EDIT}

    });
  }

}
