import {NavbarItem} from './framework/navbar/navbar-config';
import {environment} from '../environments/environment';

export const menuItems: NavbarItem[] = [{
  displayName: 'Users',
  icon: 'account_circle',
  path: 'users',
}, {
  displayName: 'Metrics',
  icon: 'poll',
  path: environment.serverUrl + 'grafana/',
  target: '_blank',
}, {
  displayName: 'Logs',
  icon: 'receipt',
  path: 'http://localhost',
  target: '_blank',
}, {
  displayName: 'API Explorer',
  icon: 'api',
  path: environment.serverUrl,
  target: '_blank'
}, {
  displayName: 'Logout',
  icon: 'logout',
  path: '#',
}];
