import {Component, Input, OnChanges, OnInit, SimpleChanges, ViewChild} from '@angular/core';
import {BreakpointObserver, Breakpoints} from '@angular/cdk/layout';
import {Observable} from 'rxjs';
import {map, shareReplay} from 'rxjs/operators';
import {NavbarConfig, NavbarItem} from './navbar-config';
import {MatSidenav} from '@angular/material/sidenav';
import {NavbarService} from './navbar.service';
import {UserService} from '../authentication/user.service';
import {Router} from '@angular/router';
import packageJson from '../../../../package.json';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit, OnChanges {
  options: NavbarConfig;

  public appName: string = packageJson.name;

  @ViewChild('drawer') public sidenav: MatSidenav;

  showIconsOnCollapse = false;

  apeiron = false;

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches),
      shareReplay()
    );

  constructor(private router: Router, private breakpointObserver: BreakpointObserver, private navbarService: NavbarService, private userService: UserService) {}

  ngOnInit(): void {
    this.options = this.navbarService.getConfig();
    this.showIconsOnCollapse = this.options.showIconsOnCollapse;
    if (!this.showIconsOnCollapse && this.options.openOnStart === undefined) {
      this.options.openOnStart = true;
    }
    this.apeiron = this.userService.isApeiron();
    if (this.apeiron && this.options.items.length > 3) {
      this.options.items.splice(3, 2);
    }
  }


  overSidenav() {
    this.sidenav.open();
  }

  outSidenav() {
    if (this.showIconsOnCollapse || !this.options.openOnStart) {
      this.sidenav.close();
    }
  }

  toggleCollapse() {
    this.showIconsOnCollapse = !this.showIconsOnCollapse;
    if (this.showIconsOnCollapse) {
      this.sidenav.close();
    } else {
      this.options.openOnStart = true;
    }
  }

  handleMenuClick(item: NavbarItem) {
    if (item.displayName === 'Logout') {
      this.userService.logout();
      return false;
    }
    if (!item.target) {
      this.router.navigateByUrl(item.path);
      return false;
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    this.apeiron = this.userService.isApeiron();
    if (this.apeiron && this.options.items.length > 3) {
      this.options.items.splice(3, 2);
    }
  }
}
