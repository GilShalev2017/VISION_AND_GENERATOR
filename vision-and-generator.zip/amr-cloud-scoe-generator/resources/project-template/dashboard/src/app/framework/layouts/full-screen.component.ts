import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-full-screen',
  template: `
    <router-outlet></router-outlet>
  `,
  styles: []
})
export class FullScreenComponent {}
