export interface AuthenticationConfig {
  appHome: 'users';
}
