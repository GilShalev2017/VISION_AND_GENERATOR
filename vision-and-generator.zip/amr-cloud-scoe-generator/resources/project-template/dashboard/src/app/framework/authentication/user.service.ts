import {Injectable} from '@angular/core';
import {AuthenticationConfig} from './authentication-config';
import {environment} from '../../../environments/environment';
import {HttpClient} from '@angular/common/http';
import {catchError, switchMap, tap} from 'rxjs/operators';
import {Router} from '@angular/router';
import {Observable} from 'rxjs';

interface Token {
  accessToken?: string;
  refreshToken?: string;
}

interface TokenResponse {
  token: Token;

  apeiron: boolean;
}

interface ConfirmationCodeResponse {
  token: string;
  identifier: string;
  apeiron?: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class UserService {
  config: AuthenticationConfig;
  user = false;
  token: string;
  apeiron: boolean;

  constructor(private httpClient: HttpClient, private router: Router) {
    const token = localStorage.getItem('mevolve_token');
    if (token && token.toString().length > 10) {
      this.user = true;
      this.token = token;
    }
    const apeiron = localStorage.getItem('mevolve_apeiron');
    if (apeiron && apeiron === '1') {
      this.apeiron = true;
    }
  }

  setOptions(options: AuthenticationConfig): void {
    this.config = options;
  }

  getConfig() {
    return this.config;
  }

  isApeiron(): boolean {
    return this.apeiron;
  }

  isAuthenticated(): boolean {
    return this.user;
  }

  isSuperuser(): boolean {
    const email = this.getUserEmail();
    return email === 'info@mevolve-cloud.com';
  }


  login(data) {

    return this.httpClient.post<TokenResponse>(environment.serverUrl + `users/login`, data)
      .pipe(tap(response => {
          this.user = true;
          const {accessToken, refreshToken} = response.token;
          if (accessToken.toString().length > 5 && refreshToken.toString().length > 5) {
            this.setTokens(accessToken, refreshToken);
            localStorage.setItem('mevolve_apeiron', response.apeiron ? '1' : '0');
            this.token = accessToken;
            this.apeiron = response.apeiron;
          }

        }
      ));
  }

  signup(data) {

    return this.httpClient.post<TokenResponse>(environment.serverUrl + `users/signup`, data).pipe(tap((response) => {
      this.user = true;
      const {accessToken, refreshToken} = response.token;
      this.setTokens(accessToken, refreshToken);

      localStorage.setItem('mevolve_apeiron', response.apeiron ? '1' : '0');
      this.token = accessToken;
      return response;
    }));
  }


  logout() {
    this.user = false;
    localStorage.removeItem('mevolve_token');
    localStorage.removeItem('mevolve_r_token');
    localStorage.removeItem('mevolve_apeiron');
    this.router.navigateByUrl('/login');
    this.token = null;
  }


  getUserEmail() {
    try {
      const decodedToken = JSON.parse(atob(this.token.split('.')[1]));
      return decodedToken.email;
    } catch (e) {
      return null;
    }
  }


  getToken(token_name: string): string {
    return localStorage.getItem(token_name);
  }

  setTokens(accessToken: string, refreshToken: string): void {
    if (accessToken) {
      localStorage.setItem('mevolve_token', accessToken);
    }
    if (refreshToken) {
      localStorage.setItem('mevolve_r_token', refreshToken);
    }
  }


  tokenRefresh(): Observable<any> {
    const refreshToken = this.getToken('mevolve_r_token');
    return this.httpClient.post<any>(
      `${environment.serverUrl + 'users/refreshToken'}`, {refreshToken}).pipe(tap((response: Token) => {

        const {accessToken} = response;
        if (!accessToken) {
          this.logout();
        }
        this.token = accessToken;
        this.setTokens(accessToken, undefined);
        return response;

      }), catchError((err) => {
        this.logout();
        throw new Error('Something went wrong with refresh token process');
      })
    );

  }

  passwordReset(data) {
    return this.httpClient.post(environment.serverUrl + `users/passwordReset`, data).pipe(tap((response: { identifier: string }) => {
      return response;

    }));
  }

  passwordUpdate(data) {
    return this.httpClient.post(environment.serverUrl + `users/passwordUpdate`, data).pipe(tap((response: { identifier: string }) => {
      if (response?.identifier === 'passwordUpdate') {
        this.user = true;

      }
      return response;


    }));
  }

  sendPushNotification({user, notification}) {
    return this.httpClient.post(environment.serverUrl + `users/send-push-notification`, notification);
  }


}
