import {Observable} from "rxjs";
import {FormGroup} from "@angular/forms";

export enum LoadingProgress {
  LOADING,
  ERROR,
  DONE
}

export enum AuthLevel {
  USER = 'USER',
  ADMIN = 'ADMIN',
  SUPER = 'SUPER'
}

export enum USER_ACTIONS {
  USER_EDIT = 'USER_EDIT',
  USER_ADD = 'USER_ADD'
}

export enum Auth {
  LOGIN = 'LOGIN',
  REGISTER = 'REGISTER',
  PASSWORD_RESET = 'PASSWORD_RESET',
  PASSWORD_UPDATE = 'PASSWORD_UPDATE',
  ADMIN_CONFIRMATION = 'ADMIN_CONFIRMATION',
}

export interface Entity {
  id: string;
}

export abstract class EntityService {
  displayName: string;
  fields: { [key: string]: EntityFieldMetadata; };

  abstract delete(id: string): Observable<void>;

  abstract get(page: number, pageSize: number): Observable<Entity[]>;

  abstract getSingleForm(entity?: Entity): FormGroup;

  abstract save(id: string, entity: Entity): Observable<Entity>;
}

export interface EntityFieldMetadata {
  displayName: string;
  type?: string;
}

export interface User {
  id: string;
  email: string;
  firstName?: string;
  lastName?: string;
  weight?: number;
  gender?: string;
  birthDate?: Date;
  height?: number;
  activityLevel?: number;
  apeiron?: boolean;
  age?: number;
  deviceKey?: number;
  authLevel?: AuthLevel;
  userSettings?: {
    enableNotifications?: boolean
  };
}
