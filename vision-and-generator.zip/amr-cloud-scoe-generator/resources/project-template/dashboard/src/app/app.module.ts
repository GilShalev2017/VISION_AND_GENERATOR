import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';

import {AppComponent} from './app.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MaterialModule} from './material/angular-material.module';
import {NavbarComponent} from './framework/navbar/navbar.component';
import {LayoutModule} from '@angular/cdk/layout';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatButtonModule} from '@angular/material/button';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatIconModule} from '@angular/material/icon';
import {MatListModule} from '@angular/material/list';
import {AppRoutingModule} from './app-routing.module';
import {AuthenticationModule} from './framework/authentication/authentication.module';
import {FullScreenComponent} from './framework/layouts/full-screen.component';
import {SidebarComponent} from './framework/layouts/sidebar.component';
import {HttpClientModule} from "@angular/common/http";
import {ConfirmComponent} from "./dialogs/confirm/confirm.component";
import {UsersComponent} from './demo/users/users.component';
import {FormsModule} from "@angular/forms";
import {SelectorCreatorComponent} from './framework/utils/selector-creator/selector-creator.component';
import {InchesPipe, PoundsPipe} from './pipes/inches.pipe';
import {EntityTableComponent} from './demo/entity-table/entity-table.component';
import {SingleEntityComponent} from './demo/entity-table/single-entity/single-entity.component';
import {NotificationsComponent} from './dialogs/notifications/notifications.component';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    FullScreenComponent,
    SidebarComponent,
    ConfirmComponent,
    UsersComponent,
    SelectorCreatorComponent,
    InchesPipe,
    PoundsPipe,
    EntityTableComponent,
    SingleEntityComponent,
    NotificationsComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    MaterialModule,
    LayoutModule,
    MatToolbarModule,
    MatButtonModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    AppRoutingModule,
    AuthenticationModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {
}
