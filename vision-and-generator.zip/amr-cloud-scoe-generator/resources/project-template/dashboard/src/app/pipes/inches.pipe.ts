import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'inches'
})
export class InchesPipe implements PipeTransform {

  transform(value: number, ...args: unknown[]): unknown {
    return value / 25.4;
  }

}

@Pipe({
  name: 'lbs'
})
export class PoundsPipe implements PipeTransform {

  transform(value: number, ...args: unknown[]): unknown {
    return value *  2.205;
  }

}
