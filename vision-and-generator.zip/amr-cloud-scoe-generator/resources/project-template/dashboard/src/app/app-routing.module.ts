import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {RouterModule, Routes} from '@angular/router';
import {CanActivateGuardService} from './framework/authentication/can-activate-guard.service';
import {SidebarComponent} from './framework/layouts/sidebar.component';
import {UsersComponent} from './demo/users/users.component';
import {EntityTableComponent} from "./demo/entity-table/entity-table.component";


const routes: Routes = [
  {
    path: 'users',
    component: SidebarComponent,
    canActivate: [CanActivateGuardService],
    children: [
      {
        path: '',
        component: UsersComponent
      }
    ]
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { relativeLinkResolution: 'legacy' })],
  exports: [RouterModule]
})

export class AppRoutingModule {
}
