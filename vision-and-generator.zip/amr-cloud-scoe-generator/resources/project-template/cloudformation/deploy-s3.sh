aws s3 sync dist/ s3://$S3_BUCKET_NAME/ --exclude "*.js"
aws s3 sync dist/ s3://$S3_BUCKET_NAME/ --exclude "*" --include "*.js" --content-type application/javascript
aws cloudfront create-invalidation --distribution-id $CLOUDFRONT_DIST --paths "/*"
