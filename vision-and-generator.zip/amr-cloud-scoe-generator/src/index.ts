#!/usr/bin/env node

import yargs from "yargs";
import {ProxyUtils} from "./utils/proxy-utils";

let resolver: Function;
let parsePromise = new Promise(resolve => {
    resolver = resolve;
});

export const debug = async () => {
    const all_args = await parsePromise;
    // @ts-ignore
    return all_args.debug;
};

ProxyUtils.SetUserSelectionProxySettings().then(x => {
    const _all_args = yargs.scriptName("scoe")
        .option('debug', {
            default: true,
            type: "boolean"
        })
        .commandDir('cmds')
        .demandCommand()
        .strict()
        .help()
        .argv

// @ts-ignore
    resolver(_all_args);
});





