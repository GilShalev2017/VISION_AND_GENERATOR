import {FileSystem} from "../utils/file-system";
import {DockerUtils} from "../utils/docker-utils";
import {KubectlUtils} from "../utils/kubectl-utils";
import {SCOE_CONFIG_FILE, ScoeConfig, ScoeDeployment, ScoeDeploymentType} from "../model/scoe-config";
import {AwsUtils} from "../utils/aws-utils";
import {RunShellCommand} from "../utils/run-shell-command";


export class DeployProject {

    constructor(private name: string, private version: string, private ngServe: boolean, private install: boolean) {
    }

    async run() {


        const scoeConfig: ScoeConfig = await FileSystem.readJsonFile(SCOE_CONFIG_FILE);
        if (!scoeConfig) {
            throw new Error("Not a valid project directory");
        }
        const appName = scoeConfig.appName;

        let deployment = scoeConfig.deployments.find(env => env.name === this.name);
        if (!deployment) {
            throw new Error("Not a valid deployment name");
        }

        const out = await KubectlUtils.changeCurrentContext(deployment.contextName);
        console.log(out);

        if (!this.install) {
            await KubectlUtils.helmUninstall(appName);
        } else {

            await FileSystem.copyFile('service/config/global.env', 'service/config/.env');
            await FileSystem.appendFile('service/config/.env', await FileSystem.readFile(`service/config/.env.` + this.name));

            console.log(`Attempting to deploy ${appName}, version ${this.version}`);
            await DockerUtils.login();
            await DockerUtils.build(appName, this.version);
            let imageTag = `${appName}:${this.version}`;

            if (deployment.type === ScoeDeploymentType.EKS) {
                await DockerUtils.loginToRegistry();
                await DockerUtils.push(appName, this.version, AwsUtils.getRegistry());
            } else if (deployment.contextName === 'kind-kind') {
                console.log("Loading kind image");
                await KubectlUtils.kindLoadDockerImage(imageTag);
                console.log("Successfully loaded kind image");
            }

            await KubectlUtils.helmUpdateDependencies();

            await KubectlUtils.helmUpgradeInstall(appName, imageTag, deployment.type);

            if (this.ngServe) {
                await RunShellCommand.spawnAsPromise("npm", ['install'], process.cwd() + "/dashboard");
                await RunShellCommand.spawnAsPromise("npm", ['start'], process.cwd() + "/dashboard");
            }
        }
    }
}
