import {FileSystem} from "../utils/file-system";
import {EksctlUtils} from "../utils/eksctl-utils";
import {KubectlUtils} from "../utils/kubectl-utils";
import {SCOE_CONFIG_FILE, ScoeConfig, ScoeDeploymentType} from "../model/scoe-config";
import {AwsUtils} from "../utils/aws-utils";



export class CreateLocalCluster {

    constructor(private name: string, private context: string) {
        if (!name) {
            throw Error("No cluster name");
        }
    }

    async checkRequirements() {
        console.log("Checking requirements...");
        try {
            const kubectl = await KubectlUtils.checkVersion();
            console.log("kubectl version: ", kubectl.stdout);
        } catch (e) {
            throw Error("Failed to run kubectl. Either kubectl not installed or no cluster available.");
        }
        try {
            const helm = await KubectlUtils.checkHelmVersion();
            console.log("helm version: ", helm.stdout);
        } catch (e) {
            throw Error("helm not installed");
        }
    }

    async run() {
        try {
            await this.checkRequirements();
            try {
                const command = await KubectlUtils.changeCurrentContext(this.context);
                console.log(command);
            } catch (e) {
                throw Error("Can't switch to context " + this.context);
            }

            try {
                const command = this.context === 'kind-kind' ? await KubectlUtils.enableNginxDockerDesktopKind() : await KubectlUtils.enableNginxDockerDesktop();
                console.log(command);
            } catch (e) {
                console.log(e);
                throw Error("Can't enable nginx " + this.context);
            }

            const scoeConfig: ScoeConfig = await FileSystem.readJsonFile(SCOE_CONFIG_FILE) || {
                deployments: []
            };

            scoeConfig.deployments.push({
                type: ScoeDeploymentType.LOCAL,
                name: this.name,
                contextName: this.context
            })
            await FileSystem.writeJsonFile(SCOE_CONFIG_FILE, scoeConfig);
            console.log("Local cluster created")
        } catch (e) {
            console.log(e);
            throw Error("Failed creating local cluster");
        }
    }
}
