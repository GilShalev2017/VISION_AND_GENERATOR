import {FileSystem} from "../utils/file-system";
import {ScoeService} from "../model/scoe-config";
import util from "util";
import fs from "fs";

export class ListServices {

    constructor() {
    }

    async run() {
        const services: ScoeService[] = [];
        const cwd = process.cwd();
        const fileNames = FileSystem.getAllFiles(cwd + `/chart/templates/`, [], false);
        for (let fileName of fileNames) {
            if (!fileName.endsWith(".service.yaml")) {
                continue;
            }
            try {
                const serviceName = fileName.split('.service.yaml')[0];
                const filePath = `${cwd}/chart/templates/${serviceName}.service.yaml`;
                const read = util.promisify(fs.readFile);
                const content = await read(filePath, {encoding: 'utf-8'});
                const replicas = content.split('replicas:')[1].split(/\r?\n|\r/)[0].trim();
                const routePattern = content.split('- path: ')[1].split(/\r?\n|\r/)[0].trim().replace('(.*)','*');
                let replicasNumber: number = 1;
                if (replicas) {
                    replicasNumber = +replicas;
                }
                services.push({name: serviceName, replicas: replicasNumber, routePattern: routePattern});
            } catch (e) {
                console.log(e);
            }
        }
        console.log(JSON.stringify(services));
    }
}
