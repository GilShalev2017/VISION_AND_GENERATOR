import {FileSystem} from "../utils/file-system";
import {RunShellCommand} from "../utils/run-shell-command";
import {StringUtils} from "../utils/string-utils";


export class CreateDashboardEntity {

    constructor(private name: string) {}

    async run() {
        const pluralName = StringUtils.pluralize(this.name);
        const folder = process.cwd() + `/dashboard/src/app/demo/${pluralName}`;
        try {
            await FileSystem.createFolder(folder);
        } catch (e) {
            console.log(e);
        }
        console.log("ng".concat([" g", "c", `demo/${pluralName}`, '--skip-tests', '-it', '-is'].join(" ")))
        try {
            await RunShellCommand.asPromise("ng", [
                "g",
                "c",
                `demo/${pluralName}`,
                '--skip-tests',
                '-it',
                '-is'
            ], process.cwd() + "/dashboard");
        } catch(e) {
            const msg = (e as Error).message;
            if (msg.includes('A merge conflicted on path')) {
                throw new Error('ENTITY_EXISTS');
            }
            throw e;
        }

        for (const file of ['service', 'component']) {
            const dest = folder + `/${pluralName}.${file}.ts`;

            try {
                await FileSystem.copyFile(FileSystem.getResourcesPath() + `single-template/dashboard-entity/entity.${file}.ts`, dest);
            } catch (e) {
                console.log(e);
            }
            await FileSystem.replaceInFile(dest, "User", StringUtils.capitalize(this.name));
            await FileSystem.replaceInFile(dest, "user", this.name);
        }

        const importLine = `import {${StringUtils.capitalize(pluralName)}Component} from './demo/${pluralName}/${pluralName}.component';`;
        const routingFile = process.cwd() + '/dashboard/src/app/app-routing.module.ts';
        await FileSystem.prependFile(routingFile, importLine);
        await FileSystem.injectLinesIntoFile(routingFile, 'const routes: Routes = [',
            `{
    path: '${pluralName}',
    component: SidebarComponent,
    canActivate: [CanActivateGuardService],
    children: [
      {
        path: '',
        component: ${StringUtils.capitalize(pluralName)}Component
      }
    ]
  },`);

        await FileSystem.injectLinesIntoFile(process.cwd() + '/dashboard/src/app/menu-items.ts', '}, {',
            `  displayName: '${StringUtils.capitalize(pluralName)}',
  icon: 'account_circle',
  path: '${pluralName}',
}, {`);
    }
}
