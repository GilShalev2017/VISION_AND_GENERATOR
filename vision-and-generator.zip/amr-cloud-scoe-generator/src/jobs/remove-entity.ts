import {FileSystem} from "../utils/file-system";
import {StringUtils} from "../utils/string-utils";
import {doesNotReject} from "assert";
import {app} from "firebase-admin/lib/firebase-namespace-api";

export class RemoveEntity {

    constructor(private entityName:string,private serviceName:string) {}

    async run() {
        if (!this.entityName) {
            throw new Error('Unable to remove entity because entity name is corrupted.');
        }
        const entityPluralName=  StringUtils.pluralize(this.entityName);
        const frontendPath = `${process.cwd()}/dashboard/src/app/demo/`;
        const routingFilePath = `${process.cwd()}/dashboard/src/app/app-routing.module.ts`;

        
        
        //remove entity folder from dashboard
        console.log(`${frontendPath}${entityPluralName}`)
        await FileSystem.deleteFolder(`${frontendPath}${entityPluralName}`)
        
        
        
        //remove selected route attributes from routing module file
        const newRoutingFile = await FileSystem.readFile(routingFilePath);

        const routingRegexRes = await  StringUtils.extractTemplateFromFile(newRoutingFile,'{\n' +
            `    path: '${entityPluralName}',\n` +
            '    component: SidebarComponent,\n' +
            '    canActivate: [CanActivateGuardService],\n' +
            '    children: [\n' +
            '      {\n' +
            '        path: \'\',\n' +
            `        component: ${StringUtils.capitalize(this.entityName)}sComponent\n` +
            '      }\n' +
            '    ]\n' +
            '  },\n')
        console.log(routingRegexRes)
        const {startIndex,endIndex} = routingRegexRes;
        if ( startIndex && endIndex &&startIndex < endIndex) {
            const routingFileOutput = newRoutingFile.substring(0, startIndex) + newRoutingFile.substring(endIndex)
            await FileSystem.writeFile(routingFilePath, routingFileOutput.split('\n').slice(1).join('\n'));
        }
        else { 
            console.log("Unable to remove routing file template. some error occurred");
        }


        
        //remove appModule  from app.module.ts
        const appModuleFile = await FileSystem.readFile(`${process.cwd()}/dashboard/src/app/app.module.ts`)
        const importTemplate =`import { ${StringUtils.capitalize(this.entityName)}sComponent } from './demo/${this.entityName}s/${this.entityName}s.component';`
        const importIndex = StringUtils.extractTemplateFromFile(appModuleFile,importTemplate)
        const declerationIndex = StringUtils.extractTemplateFromFile(appModuleFile,`,\n${StringUtils.capitalize(this.entityName)}sComponent`)

        const moduleOutput = appModuleFile.substring(0,importIndex.startIndex)+appModuleFile.substring(importIndex.endIndex+1,declerationIndex.startIndex)+appModuleFile.substring(declerationIndex.endIndex)
        await FileSystem.writeFile(`${process.cwd()}/dashboard/src/app/app.module.ts`,moduleOutput);
        
        //remove  menu-item from menu-items.ts
        const menuItemsFile = await FileSystem.readFile(`${process.cwd()}/dashboard/src/app/menu-items.ts`);
        const menuItemsRegexRes = await  StringUtils.extractTemplateFromFile(menuItemsFile,`{\ndisplayName: '${StringUtils.capitalize(this.entityName)}s',
  icon: 'account_circle',
  path: '${this.entityName}s',\n
}, `);
        if ( menuItemsRegexRes?.startIndex  < menuItemsRegexRes?.endIndex) {
            const {startIndex, endIndex} = menuItemsRegexRes;
            const menuFileOutput = menuItemsFile.substring(0,startIndex).trim()+menuItemsFile.substring(endIndex);
            await FileSystem.writeFile(`${process.cwd()}/dashboard/src/app/menu-items.ts`,menuFileOutput);

        }
        else{
            console.log("Unable to remove menu item  template. some error occurred");
        }


        const fileDest =process.cwd() + `/service/src/`;
        for (const currFolder of ['models', 'controllers','repositories']) {
            const currFolderIndexFile = await FileSystem.readFile(fileDest+currFolder+'/index.ts');
            if ( currFolderIndexFile) {
                const lines = currFolderIndexFile.toString().split("\n");
                const entityToRemoveIndex = lines.findIndex(cL => cL.indexOf(this.entityName) >0);
                lines.splice(entityToRemoveIndex,1);
                await FileSystem.writeFile(fileDest + currFolder + '/index.ts',lines.join('\n'))
            }

        }

        
        
        
        const backendPath= process.cwd() + `/service/src/micro-services/`;
        const files =  FileSystem.getAllFiles(backendPath,[],true);
        const currServiceFiles = files.filter(cF=>cF.indexOf(this.entityName)>-1);
        for (const file of currServiceFiles) {
            try {
                if ( FileSystem.isFileExist(file)) {
                    await FileSystem.deleteFile(file)
                }
            } catch (e) {
                console.log(e);
            }


        }
    }

     
}


