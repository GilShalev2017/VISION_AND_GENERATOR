import {RunShellCommand} from "../utils/run-shell-command";
import {FileSystem} from "../utils/file-system";

import { Gitlab } from '@gitbeaker/node';
import os from "os";
import {CommitAction} from "@gitbeaker/core/dist/types/resources/Commits";
import {exit} from "yargs";
 
export class Git {
    private api: any;
    private projectId: number;
    private projectPath:string;
    constructor(
        public name?: string,
        public gitToken?: string,
        public user?: string,
        public password?: string) {
        console.log(gitToken ?? process.env.GIT_TOKEN)
        this.api = new Gitlab({
            host: 'https://gitlab.devtools.intel.com/',
            token: gitToken ?? process.env.GIT_TOKEN,
        });
        this.projectId=0;
        this.projectPath="";
    }

    async gitInit() {
        if (!this.gitToken || !this.name){
            console.log(`Something went wrong!\nProject: ${this.name} Token: ${this.gitToken} `)
            return;
        }
        this.projectPath = process.cwd() + this.name;

        const newProject = await this.api.Projects.create({name:this.name})
        console.log(newProject);
        const {id, http_url_to_repo, ssh_url_to_repo} = newProject;
        let url_with_creds = ssh_url_to_repo;
        if (this.user) {
            // If user is defined we need to set remote to https instead of ssh
            url_with_creds = http_url_to_repo.replace('https://', `https://${this.user}:${this.password}@`);
        };

        if ( !id || !url_with_creds ){
           console.log(`Something went wrong!\nProject: ${this.name} Token: ${this.gitToken}\n id:${newProject.id ?? ""}\n web_url: ${url_with_creds} `)
           return;
        }
        this.projectId = id;
        try {
            await RunShellCommand.asPromise('git init', []);
            await RunShellCommand.asPromise(`git remote add origin ${url_with_creds}`, []);
            await RunShellCommand.asPromise('git add .', []);
            await RunShellCommand.asPromise('git commit -m "Initial Commit"', []);
        } catch (e) {
            console.log(e);
            process.exit(1);
        }
        try {
            await RunShellCommand.asPromise('git push -u origin master', []);
        } catch (e) {
            console.log(e);
        }
    }
    async commit(commitMessage:string){
        await RunShellCommand.asPromise('git add',['add','.']);
        await RunShellCommand.asPromise('git commit -m ',['commit','-m',`"${commitMessage ?? "no message commit"}"`]);
        await RunShellCommand.asPromise('git',['push']);
        
    }
}
