import {FileSystem} from "../utils/file-system";
import {StringUtils} from "../utils/string-utils";
import {glob} from "glob";

export interface Entities {
    [key: string]: EntityProperties;
}

export interface EntityProperties {
    [key: string]: string;
}

export class ListEntities {

    constructor() {}

    async getEntityLine(file: string) {
        let index = file.indexOf('Entity {');
        let tempString = file.substring(0, index);
        return tempString.split('\n').length;
    }

    getEntityObject(file: string, interfaceName: string): EntityProperties {
        const split = file.split('extends Entity {');
        // We assume there will be no curled braces in an entity interface
        const entityProperties = split[1].split('}')[0];
        const lines = entityProperties.split(/\r?\n|\r/);
        const properties: EntityProperties = {};
        for (let l of lines) {
            if (l === "") {
                continue
            }
            l = l.trim();
            l = l.replace(';', '');
            const split = l.split(':');
            properties[split[0]] = split[1].trim();
        }
        return properties;
    }

    async run() {
        const entities: Entities = {};
        const dirs = FileSystem.getAllFiles(process.cwd() + `/dashboard/src/app/demo/`, [], false);
        dirs.splice(dirs.indexOf('cache.service.ts'), 1);
        dirs.splice(dirs.indexOf('date-utils.service.ts'), 1);
        dirs.splice(dirs.indexOf('entity-table'), 1);
        for(let ent of dirs) {
            const someFilePath = process.cwd() + `/dashboard/src/app/demo/${ent}/${ent}.service.ts`;
            try {
            const readFile = await FileSystem.readFile(someFilePath);
            const interfaceName = StringUtils.capitalize(StringUtils.singular(ent));
            entities[ent] = await this.getEntityObject(readFile, interfaceName);
            } catch(e) {
                // console.log(e);
            }
            // const entity = await this.getEntityObject(readFile, interfaceName);
        }
        console.log(JSON.stringify(entities));
    }
}
