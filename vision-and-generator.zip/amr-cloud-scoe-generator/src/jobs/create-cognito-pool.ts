import {AwsUtils, CognitoConfig} from "../utils/aws-utils";
import {FileSystem} from "../utils/file-system";

export class CreateCognitoPool {


    constructor(public appName: string, public envName: string) {
    }

    async run() {

        const envFile = await FileSystem.readPropertiesFile('service/config/global.env');
        if (envFile.AUTHENTICATION_STRATEGY !== 'COGNITO') return;

        const configKeyMap = {
            'userPool': 'AWS_COGNITO_USER_POOL',
            'clientId': 'AWS_COGNITO_CLIENT_ID',
            'clientSecret': 'AWS_COGNITO_CLIENT_SECRET',
        };

        AwsUtils.setupCredentialsFromEnvFile(envFile);

        let configString = '';
        const cognitoConfig = await AwsUtils.getCognitoClientSecret(this.appName, this.envName);
        for (const cognitoConfigElement of ['userPool', 'clientId', 'clientSecret']) {
            configString += `${configKeyMap[cognitoConfigElement as keyof CognitoConfig]}=${cognitoConfig[cognitoConfigElement as keyof CognitoConfig]}\n`;
        }
        configString += 'AWS_COGNITO_JWT_PEM=' + `${this.envName}.jwt.pem`;
        await FileSystem.appendFile(`service/config/.env.${this.envName}`, configString);
    }
}
