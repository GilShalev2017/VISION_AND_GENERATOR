import {FileSystem} from "../utils/file-system";
import {RunShellCommand} from "../utils/run-shell-command";
import {StringUtils} from "../utils/string-utils";


export class CreateLoopbackEntity {

    constructor(private name: string, private service: string) {}

    async run() {
        const folder = process.cwd() + `/service/src`;

        for (const file of ['model', 'controller', 'repository']) {
            const pluralFile = StringUtils.pluralize(file);
            const destFolder = folder + `/micro-services/${this.service}/`
            const dest = `${destFolder}/${this.name}.${file}.ts`;
            try {
                await FileSystem.createFolder(destFolder);
            } catch (e) {
                console.log(e);
            }
            await FileSystem.copyFile(FileSystem.getResourcesPath() + `single-template/loopback-entity/entity.${file}.ts`, dest);
            await FileSystem.replaceInFile(dest, "Item", StringUtils.capitalize(this.name));
            await FileSystem.replaceInFile(dest, "item", this.name);
            await FileSystem.prependFile(folder + `/${pluralFile}/index.ts`, `export * from '../micro-services/${this.service}/${this.name}.${file}';`);
        }
    }
}
