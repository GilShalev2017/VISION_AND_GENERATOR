import {FileSystem} from "../utils/file-system";
import {StringUtils} from "../utils/string-utils";
import {glob} from "glob";

const bluebird = require('bluebird');
const globPromise = bluebird.promisify(glob);
interface  Properties{
        service?:string;
        property?: string;
        type?: string;
        newPropertyValue?: string;
        newPropertyType?: string;
    
}
export class UpdateEntity {
    modelPath: string;
    servicePath: string;

    constructor(private name: string) {
        
        const plural = StringUtils.pluralize(name);
        this.modelPath = process.cwd() + `/service/**/${name}.model.ts`;
        this.servicePath = process.cwd() + `/dashboard/src/app/demo/${plural}/${plural}.service.ts`;

    }

    async run(action:string,  properties:Properties[]) {

        if (!action) {
            throw new Error('Action is invalid hence  flow will not execute.\nPlease execute command properly');
        }

        const modelFiles = await getFiles(this.modelPath);
        let serviceFileString = await FileSystem.readFile(this.servicePath);
        let modelFileString = await FileSystem.readFile(modelFiles[0])
        if (!modelFiles && modelFiles.length === 0 || !serviceFileString || serviceFileString.length === 0) {
            throw new Error(`Action's file is invalid hence  flow will not execute.\nPlease execute command properly`);

        }
  
        for (const currProperty of properties) {
            const {property, type,newPropertyType,newPropertyValue} = currProperty
            if (action === 'delete-property') {

                // Removes property from model.ts
                let fileString =  modelFileString.toString();
                const propertyValueIndex = fileString.indexOf(`${property}:`);
                const propertyEndIndex = fileString.indexOf(';', propertyValueIndex);
                const propertyStartIndex = fileString.lastIndexOf('@property', propertyEndIndex);
                modelFileString=`${fileString.substring(0, propertyStartIndex - 1)}\n${fileString.substring(propertyEndIndex + 1)}`;

                // Removes property from service.ts
                fileString = serviceFileString.toString()
                const fileLines = fileString.split(/\r?\n/);
                const template = `${property}: {displayName: '${StringUtils.capitalize(property ?? "")}', type: '${type}'}`;
                const fileOutput = fileLines.filter(cR => cR.indexOf(template) === -1 && cR.indexOf(`${property}: ${type}`) === -1);
                serviceFileString=fileOutput.join('\n')


            } 
            else if (action === 'update-property') {
                const updatedValue = `${newPropertyValue}: ${newPropertyType}`;
                const updatedType = `type: '${newPropertyValue}'`;
                // Replaces model.ts old properties
                const propertyValueIndex = modelFileString.indexOf(`${property}:`);
                const propertyEndIndex = modelFileString.indexOf(';', propertyValueIndex);
                const propertyStartIndex = modelFileString.lastIndexOf('@property', propertyEndIndex);
                let propertyString = modelFileString.substring(propertyStartIndex, propertyEndIndex) + ';';
                propertyString = propertyString.replace(`${property}: ${type}`, updatedValue)
                    .replace(`type: '${type}'`, updatedType);
                modelFileString= `${modelFileString.substring(0, propertyStartIndex - 1)} ${propertyString}${modelFileString.substring(propertyEndIndex + 1)}`;


                // Replaces service.ts old properties
                const fieldsTemplate = `${property}: {displayName: '${StringUtils.capitalize(property??"")}', type: '${type}'}`;
                serviceFileString = modelFileString.toString().replace(fieldsTemplate, `${newPropertyValue}: {displayName: '${StringUtils.capitalize(newPropertyValue ?? "")}', type: '${newPropertyType}'}`)
                const interfaceTemplate = `${property}: ${type}`;
                serviceFileString= serviceFileString.replace(interfaceTemplate, updatedValue);
            } 
            else if (action === 'add-property') {
                const fileLines = serviceFileString.toString().split(/\r?\n/);

                for (let i = 0; i < fileLines.length; i++) {
                    if (fileLines[i].includes('// entity')) {
                        fileLines.splice(i++, 0, `  ${property}: ${type};`);
                    }
                    if (fileLines[i].includes('// fields')) {
                        fileLines.splice(i++, 0, `    ${property}: {displayName: '${StringUtils.capitalize(property??"")}', type: '${type}'},`);
                    }
                }
                serviceFileString=fileLines.join('\n')

                for (let i = 0; i < fileLines.length; i++) {
                    if (fileLines[i].includes('constructor')) {
                        fileLines.splice(i++, 0, `  @property({\n    type: '${type}',\n  })\n  ${property}: ${type};\n`);
                    }
                }
                modelFileString =  fileLines.join('\n')


                console.log("Entity was added successfully.")
            }
        }
        
        
        if ( serviceFileString.length > 5 ) {
            await FileSystem.writeFile(this.servicePath, serviceFileString);
        }
        if ( modelFileString.length > 5) {
            await FileSystem.writeFile(modelFiles[0], modelFileString);
        }


    }
}

const getFiles=async (modelPath:string)=>await globPromise(modelPath).then((files: string[])=>files).catch((e: any)=>e)

