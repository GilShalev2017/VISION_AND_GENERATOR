import {FileSystem} from "../utils/file-system";
import {EksctlUtils} from "../utils/eksctl-utils";
import {KubectlUtils} from "../utils/kubectl-utils";
import {SCOE_CONFIG_FILE, ScoeConfig, ScoeDeploymentType} from "../model/scoe-config";
import {AwsUtils} from "../utils/aws-utils";
import {DashboardUtils} from "../utils/dashboard-utils";
import {RunShellCommand} from "../utils/run-shell-command";

interface managedServices {
    name: string,
    type: boolean
}

export class CreateEksCluster {

    constructor(private name: string, private nodes: string, private eksctlOptions: { [key: string]: string }, private managedServices: managedServices[]) {
        if (!name) {
            throw Error("No cluster name");
        }
        if (!nodes) {
            throw Error("Number of nodes must be provided");
        }
    }

    async checkRequirements() {
        console.log("Checking requirements...");
        try {
            const eksctl = await AwsUtils.checkVersion();
            console.log("aws cli version: ", eksctl.stdout);
        } catch (e) {
            throw Error("aws cli not installed. Please install and configure.")
        }
        try {
            const eksctl = await EksctlUtils.checkVersion();
            console.log("eksctl version: ", eksctl.stdout);
        } catch (e) {
            throw Error("eksctl not installed. Please install and configure: https://docs.aws.amazon.com/eks/latest/userguide/eksctl.html")
        }
        try {
            const kubectl = await KubectlUtils.checkVersion();
            console.log("kubectl version: ", kubectl.stdout);
        } catch (e) {
            throw Error("Failed to run kubectl. Either kubectl not installed or no cluster available.");
        }
    }

    async run() {
        try {

            await this.checkRequirements();
                
            AwsUtils.setupCredentialsFromEnvFile(await FileSystem.readPropertiesFile('service/config/global.env'));
            
            const scoeConfig: ScoeConfig = await FileSystem.readJsonFile(SCOE_CONFIG_FILE) || {
                deployments: []
            };

            const clusterName = scoeConfig.appName + '-' + this.name;
            if (!await AwsUtils.IsClusterExist(clusterName)) {
                console.log("Creating the EKS Cluster now");
                await EksctlUtils.createCluster(clusterName, this.nodes, this.eksctlOptions);
                await KubectlUtils.enableNginxEKS();
            } else {
                console.log("Cluster already exist - not creating it again");
            }

            let configString = `CLUSTER_NAME=${clusterName}\n`;
            const clusterInfo = await AwsUtils.getClusterInfo(clusterName);
            const clusterSubnetIds = clusterInfo.cluster.resourcesVpcConfig.subnetIds.toString();
            let clusterSubnetIdsQuoted = clusterSubnetIds.replace(new RegExp(',', 'g'), "\",\"");
            let templateClusterSubnetIds = "\"SubnetIds\" : [\"" + clusterSubnetIdsQuoted + "\"]";
            const subnetsList = clusterInfo.cluster.resourcesVpcConfig.subnetIds
            const templateAuroraClusterSecurityGroupIds = "\"VpcSecurityGroupIds\" : [\"" + clusterSubnetIdsQuoted + "\"]";

            for (const ms of this.managedServices) {

                switch (ms.name) {
                    case 'postgresType': {
                        if (ms?.type === true) {
                            console.log("Creating Managed postgres!!!");
                            const appName = scoeConfig.appName + "-" + this.name;
                            const rdsStackName = appName + "-rds";
                            const clusterInfo = await AwsUtils.getClusterInfo(clusterName);
                            let vpcSecurityGroupIds = clusterInfo.cluster.resourcesVpcConfig.securityGroupIds.toString();
                            let vpcClusterSecurityGroupId = clusterInfo.cluster.resourcesVpcConfig.clusterSecurityGroupId.toString();
                            let allSecurityGroupIds = vpcSecurityGroupIds + ',' + vpcClusterSecurityGroupId;
                            console.log("clusterSubnetIds=" +clusterSubnetIds);
                            console.log("allSecurityGroupIds=" +allSecurityGroupIds);
                            console.log("clusterSubnetIdsQuoted=" +clusterSubnetIdsQuoted);
                            console.log("templateClusterSubnetIds=" +templateClusterSubnetIds);
                            console.log("clusterSecurityGroupIdsQuoted=" +clusterSubnetIdsQuoted);
                            console.log("templateClusterSecurityGroupIds=" + templateAuroraClusterSecurityGroupIds);
                            await AwsUtils.deployCloudFormation(rdsStackName, "aurora-postgres.json",
                                ["appName=" + appName, "clusterSubnetIds=" + clusterSubnetIdsQuoted, "clusterSecurityGroups=" + clusterSubnetIdsQuoted]);
                            const dbAuroraClusterEndpoint = await AwsUtils.getCloudFormationOutput(rdsStackName, "DBEndpoint");
                            console.log("AuroraClusterEndpoint: ", dbAuroraClusterEndpoint);
                            configString += `AURORA_POSTGRES_ENDPOINT_ADDRESS=${dbAuroraClusterEndpoint}\n`;
                            configString += `IS_POSTGRES_NOT_MANAGED=false\n`;
                        }
                        else {
                            console.log("Creating Postgress as a pod Inside the Cluster!!!");
                            let eksClusterEndpoint = process.env.SCOE_APP_NAME + '-postgresql.default.svc.cluster.local'
                            console.log("EndpointAddress: ", eksClusterEndpoint);
                            configString += `POSTGRES_ENDPOINT_ADDRESS=${eksClusterEndpoint}\n`;
                            configString += `IS_POSTGRES_NOT_MANAGED=true\n`;
                        }
                        configString += `POSTGRES_DATABASE=postgres\n`;

                        break;
                    }
                    case 'messageBrokerType': {
                        if (ms.type) {
                            const securityGroupId = clusterInfo.cluster.resourcesVpcConfig.securityGroupIds.toString();
                            const newBrokerArgs = ["--deployment-mode", "SINGLE_INSTANCE", `--broker-name ${clusterName}`, "--engine-type", "RABBITMQ", "--host-instance-type mq.t3.micro", "--engine-version  3.8.11", "--users", 'ConsoleAccess=true,Groups=test_broker,Password=Admin123456789,Username=admin', `--security-groups ${securityGroupId.toString()}`, `--subnet-ids ${subnetsList[0].toString()}`]
                            const newBrokerRes = await RunShellCommand.asPromise("aws mq create-broker", newBrokerArgs)
                            const region = newBrokerRes.match(/(us(-gov)?|ap|ca|cn|eu|sa)-(central|(north|south)?(east|west)?)-\d/) || []
                            const brokerId = JSON.parse(newBrokerRes).BrokerId;

                            if (brokerId.toString().length > 10 && region.length > 0) {
                                const endPoint = `amqps://${brokerId}.mq.${region[0]}.amazonaws.com:5671`
                                console.log(`Your RabbitMQ web console link:\n${endPoint.replace("amqps", "https")}`)
                                configString += `RABBITMQ=${endPoint}\n`;
                            } else {
                                console.log("No broker id found. some error occurred.")
                            }
                        }
                        break;
                    }
                    case 'efsType':{
                        await EksctlUtils.installEfs(scoeConfig.appName, clusterName)
                        break;
                    }
                }
            }

            configString += `MASTER_USER_NAME=scoeuser\n`;
            configString += `MASTER_USER_PASSWORD=1234abcd\n`;
            const bucketName = scoeConfig.appName + "-" + this.name;
            console.log("Creating s3 bucket with cloudfront. Bucket name: " + bucketName);
            await AwsUtils.deployCloudFormation(bucketName, "cloudfront.json", ["bucketName=" + bucketName]);
            const distributionId = await AwsUtils.getCloudFormationOutput(bucketName, "DistributionId");
            console.log("DistributionId: ", distributionId);
            configString += `S3_BUCKET_NAME=${bucketName}\n`;
            configString += `CLOUDFRONT_DIST=${distributionId}\n`;

            if (!scoeConfig.registry) {
                console.log("Creating ECR repository");
                await AwsUtils.deployCloudFormation(bucketName + '-ecr',"ecr.json", ["appName=" + bucketName]);
                const registry = await AwsUtils.getCloudFormationOutput(bucketName + '-ecr', "RepositoryURL");
                scoeConfig.registry = registry;
                console.log("ECR repository: ", registry);
            }
            if (scoeConfig.registry) {
                const registryParts = scoeConfig.registry.split('/');
                await FileSystem.copyFile(FileSystem.getResourcesPath() + `single-template/ci-template.yml`, '.gitlab-ci.yml');
                await FileSystem.replaceInFile(".gitlab-ci.yml", "<<ecr_repository>>", registryParts[0]);
                await FileSystem.replaceInFile(".gitlab-ci.yml", "<<app_name>>", scoeConfig.appName);
                await FileSystem.replaceInFile(".gitlab-ci.yml", "<<aws_account>>", await AwsUtils.getAccountNumber());
                configString += `ECR_REPO_NAME=${registryParts[1]}\n`;
            }


            await FileSystem.appendFile(`service/config/.env.${this.name}`, configString);

            const serverUrl = 'http://' + (await AwsUtils.getClusterUrl(clusterName)).trim();
            console.log("API url: ", serverUrl);
            await FileSystem.copyFile(
                FileSystem.getResourcesPath() + `single-template/environment.template.ts`,
                `dashboard/src/environments/environment.${this.name}.ts`);
            await FileSystem.replaceInFile(`dashboard/src/environments/environment.${this.name}.ts`, "<<server_url>>", serverUrl);

            await DashboardUtils.createAngularConfiguration(this.name);

            const frontendUrl = 'http://' + (await AwsUtils.getCloudfrontDomainName(distributionId)).trim();
            console.log("Dashboard url: ", frontendUrl);

            const url = 'http://127.0.0.1/users/initial';
            await RunShellCommand.asPromise(`curl -X POST ${url} -H "Content-Type: application/json" -d "{\\"email\\":\\"admin@admin.com\\",\\"firstName\\":\\"System\\",\\"lastName\\":\\"Admin\\",\\"authLevel\\": \\"ADMIN\\",\\"password\\":\\"A123456789\\"}"`, []);
        
            scoeConfig.deployments.push({
                type: ScoeDeploymentType.EKS,
                name: this.name,
                contextName: (await KubectlUtils.getCurrentContext()).replace(/\s/g, ""),
                dashboardUrl: frontendUrl,
                apiUrl: serverUrl
            })
            await FileSystem.writeJsonFile(SCOE_CONFIG_FILE, scoeConfig);
        } catch (e) {
            console.log(e);
            throw Error("Failed creating eks cluster");
        }
    }
}
