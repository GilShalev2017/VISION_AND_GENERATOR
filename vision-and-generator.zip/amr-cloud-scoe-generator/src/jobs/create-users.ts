import {RunShellCommand} from "../utils/run-shell-command";
import {FileSystem} from "../utils/file-system";
import {SCOE_CONFIG_FILE, ScoeConfig} from "../model/scoe-config";
import {AwsUtils} from "../utils/aws-utils";

interface Answers {
    action: string,
    userId: string,
    update: string[],
    email: string,
    password: string,
    passwordUpdate: string,
    authLevelUpdate: string,
    environment: 'eks' | 'local'
}

const adminUser = {
    email: "admin@admin.com",
    password: "A123456789",
    firstName: "System",
    lastName: "admin",
    authLevel: "ADMIN",

}

export class CreateUsers {
    url: string = 'http://127.0.0.1:3070';

    constructor(public answers: Answers) {
    }

    async run() {
        try {
            if (this.answers?.environment === 'eks') {
                const env = await FileSystem.readFile("./service/config/global.env");
                const split = env.toString().split("\n");
                this.url = split.find(cR => cR.toString().indexOf("SERVER_URL") > -1)?.substring(11).trim() || ""
            }
            const {action} = this.answers;

            const adminUserCommand = RunShellCommand.buildCurlRequest(
                this.url.concat('/users/initial'),
                "POST",
                [],
                adminUser);
            await RunShellCommand.asPromise(adminUserCommand, []);

            const adminUserLoginCommand = RunShellCommand.buildCurlRequest(this.url.concat('/users/login'),
                "POST",
                [],
                {
                    email: adminUser.email,
                    password: adminUser.password
                })
            const loginRes = await RunShellCommand.asPromise(adminUserLoginCommand, []);
            const parsed = JSON.parse(loginRes);
            const token = parsed.token.accessToken;
            switch (action) {
                case 'add': {

                    const addCommand = RunShellCommand.buildCurlRequest(
                        this.url.concat('/users/initial'),
                        "POST",
                        [`"Authorization: Bearer ${token.toString().trim()}" `],
                        {
                            ...adminUser,
                            email: this.answers.email,
                            password: this.answers.password
                        });

                    await RunShellCommand.asPromise(addCommand, [])
                    break;
                }
                case 'list': {

                    const listCommand = await RunShellCommand.buildCurlRequest(
                        this.url.concat('/users'),
                        "GET",
                        [`"Authorization: Bearer ${token.toString().trim()}" `]);
                    const list = await RunShellCommand.asPromise(listCommand, [])
                    console.log(JSON.parse(list))
                    break;

                }
                case 'update': {

                    const requestBody = {
                        'passwordUpdate': this.answers.passwordUpdate,
                        'authLevelUpdate': this.answers.authLevelUpdate
                    }
                    const updateCommand = await RunShellCommand.buildCurlRequest(
                        this.url.concat(`/users/${this.answers.userId}`),
                        "PATCH",
                        [`"Authorization: Bearer ${token.toString().trim()}" `],
                        requestBody);
                    await RunShellCommand.asPromise(updateCommand, [])
                    break;
                }
                case 'delete': {

                    const deleteCommand = await RunShellCommand.buildCurlRequest(
                        this.url.concat(`/users/${this.answers.userId}`),
                        "DEL",
                        [`"Authorization: Bearer ${token.toString().trim()}"`]);
                    await RunShellCommand.asPromise(deleteCommand, [])
                    break;

                }
                default: {

                    console.log("No matching option found.")
                    break;

                }
            }
        } catch (e) {
            console.log(e);
            new Error("Failed performing users crud actions.");
        }
    }
}
