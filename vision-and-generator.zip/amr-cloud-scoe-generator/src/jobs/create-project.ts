import {FileSystem} from "../utils/file-system";
import path from "path";
import {SCOE_CONFIG_FILE, ScoeConfig, ScoeDeploymentType} from "../model/scoe-config";
import {KubectlUtils} from "../utils/kubectl-utils";
import {AwsUtils, CognitoConfig} from "../utils/aws-utils";
import * as os from "os";
import {ProgressBar} from "../utils/progress-bar";
import {RunShellCommand} from "../utils/run-shell-command";

const components: { [key: string]: string } = {
    "RabbitMq": "  - name: \"rabbitmq\"\n" +
        "    version: \"~7.6.6\"\n" +
        "    repository: \"https://charts.bitnami.com/bitnami\"",
    "MongoDB": "  - name: \"mongodb\"\n" +
        "    version: \"~9.1.1\"\n" +
        "    repository: \"https://charts.bitnami.com/bitnami\"",
    "Prometheus": "  - name: \"kube-prometheus-stack\"\n" +
        "    version: \"~9.4.1\"\n" +
        "    repository: \"https://prometheus-community.github.io/helm-charts\"",
    "ElasticSearch": "  - name: \"elasticsearch\"\n" +
        "    version: \"~7.16.2\"\n" +
        "    repository: \"https://helm.elastic.co\"\n" +
        "  - name: \"kibana\"\n" +
        "    version: \"~7.16.2\"\n" +
        "    repository: \"https://helm.elastic.co\"\n" +
        "  - name: \"apm-server\"\n" +
        "    version: \"~7.16.2\"\n" +
        "    repository: \"https://helm.elastic.co\"\n" +
        "  - name: \"fluentd-elasticsearch\"\n" +
        "    version: \"~9.6.2\"\n" +
        "    repository : \"https://kiwigrid.github.io\"",
    "PostgreSQL": "  - name: \"postgresql\"\n" +
        "    version: \"~10.2.6\"\n" +
        "    repository: \"https://charts.bitnami.com/bitnami\"\n" +
        "    condition: \"isInCluster\""

}

export interface Answers {
    components: string[];
    authentication: "Local" | "AWS Cognito";
    cloud: "None" | "AWS";
    awsAccessKey: string;
    awsSecretKey: string;
    awsRegion: string;
}

export class CreateProject {
    constructor(public name: string, public answers: Answers) {
    }

    async run() {
        try {
            const templateSize = FileSystem.getFolderSize(FileSystem.getResourcesPath() + 'project-template')
            console.log('\n')
            const pb = new ProgressBar(0, 100);
            pb.startPb()
            const pbInterval = setInterval(() => {
                const folderSize = FileSystem.getFolderSize(process.cwd() + '/' + this.name);
                const currPercent = (folderSize / (1024 * 1024)) / (templateSize / (1024 * 1024))
                if (currPercent > 0.90) {
                    pb.updateTick(100)
                    pb.endPb()
                    clearInterval(pbInterval)

                } else {
                    pb.updateTick(100 * currPercent);
                }

            }, 10000)
            await FileSystem.copyFolder(FileSystem.getResourcesPath() + 'project-template', process.cwd() + '/' + this.name);

            await FileSystem.replaceInFile(this.name + "/dashboard/package.json", "client-framework", this.name);
            await FileSystem.replaceInFile(this.name + "/dashboard/src/app/app.component.ts", "client-framework", this.name);

            await FileSystem.replaceInFile(this.name + "/service/config/global.env", "<<appname>>", this.name);
            await FileSystem.replaceInFile(this.name + "/service/config/global.env", "<<appname>>", this.name);
            const strategy = this.answers.authentication === "Local" ? "LOCAL" : "COGNITO";
            await FileSystem.replaceInFile(this.name + "/service/config/global.env", "<<authentication_strategy>>", strategy);

            if (this.answers.cloud === 'AWS') {
             
                if (this.answers.awsAccessKey) {
                    process.env.AWS_ACCESS_KEY_ID = this.answers.awsAccessKey;
                    process.env.AWS_SECRET_ACCESS_KEY = this.answers.awsSecretKey;
                }
                await AwsUtils.getCurrentUser();
                if (process.env.AWS_ACCESS_KEY_ID && process.env.AWS_SECRET_ACCESS_KEY) {
                    await FileSystem.replaceInFile(this.name + "/service/config/global.env", "<<aws_access_key>>", process.env.AWS_ACCESS_KEY_ID);
                    await FileSystem.replaceInFile(this.name + "/service/config/global.env", "<<aws_secret_key>>", process.env.AWS_SECRET_ACCESS_KEY);
                } else {
                    const profile = process.env.AWS_PROFILE ?? 'default';
                    console.log("Getting credentials from profile", profile)
                    const credentials = await FileSystem.readFile(os.homedir() + '/.aws/credentials');
                    const credentialsLines = credentials.split(/\r?\n/);
                    for (let i = 0; i < credentialsLines.length; i++) {
                        const line = credentialsLines[i];
                        if (line.indexOf('[' + profile + ']') > -1) {
                            const accessKey = credentialsLines[i + 1].split('=')[1].trim();
                            const secretKey = credentialsLines[i + 2].split('=')[1].trim();
                            console.log(accessKey, secretKey);
                            await FileSystem.replaceInFile(this.name + "/service/config/global.env", "<<aws_access_key>>", accessKey);
                            await FileSystem.replaceInFile(this.name + "/service/config/global.env", "<<aws_secret_key>>", secretKey);
                        }
                    }
                }
            }


            for (const component of this.answers.components) {
                if (components[component]) {
                    await FileSystem.appendFile(this.name + "/chart/Chart.yaml", components[component]);
                    switch (component) {
                        case "PostgreSQL": {
                            await FileSystem.appendFile(this.name + "/service/config/global.env", "POSTGRESS=true");
                            break;
                        }

                        default:
                            console.log(`No match found for component named: ${component}`)
                    }
                } else {

                    switch (component) {
                        case "Notifications": {
                            await FileSystem.replaceInFile(this.name + "/service/config/global.env", "<<firebase_credentials_path>>", '/home/node/app/config/firebase_credentials.json');
                            break;
                        }
                        case "Argo": {
                            await FileSystem.replaceInFile(this.name + "/service/src/micro-services/argo/argo.controller.ts", 'undocumented', 'documented')
                            break;
                        }
                        default:
                            console.log(`No match found for component named: ${component}`)

                    }


                }
            }

            const scoeConfig: ScoeConfig = {
                appName: this.name,
                deployments: [],
                services: [
                    {name: "users", replicas: 1, routePattern: '/users/*'},
                    {name: "files", replicas: 1, routePattern: '/files/*'}
                ]
            };
            await FileSystem.writeJsonFile(this.name + "/" + SCOE_CONFIG_FILE, scoeConfig);

            console.log("Created new project at ", path.join(process.cwd(), this.name));
        } catch (e) {
            console.log(e);
            new Error("Failed creating starter project");
        }
    }
}
