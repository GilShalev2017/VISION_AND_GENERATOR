import {SCOE_CONFIG_FILE, ScoeConfig, ScoeDeploymentType} from "../model/scoe-config";
import {FileSystem} from "../utils/file-system";
import {AwsUtils} from "../utils/aws-utils";
import {KubectlUtils} from "../utils/kubectl-utils";
import {EksctlUtils} from "../utils/eksctl-utils";
import inquirer from "inquirer";

export class DeleteEnv {

    constructor(private name: string) {}

    async run() {
        
        const scoeConfig: ScoeConfig = await FileSystem.readJsonFile(SCOE_CONFIG_FILE);
        const env = scoeConfig.deployments.find(env => env.name === this.name);
        AwsUtils.setupCredentialsFromEnvFile(await FileSystem.readPropertiesFile('service/config/global.env'));

        if (!env) {
            const deleteByForceAnswer= await   inquirer
                .prompt([{
                    name: "confirm",
                    message: "Selected env does not exists. would you like to try delete cluster resources?",
                    type: "input",
                }]);
            if ( deleteByForceAnswer.confirm !== 'y' && deleteByForceAnswer.confirm !== 'yes'){ 
                console.log("No env to delete.")
                process.exit(1);
            }
            else{
                try {
                    const clusterName = scoeConfig.appName + '-' + this.name;
                    await EksctlUtils.deleteCluster(clusterName);
                    const cognitoStackName = clusterName + '-cognito';
                    await AwsUtils.deleteCloudFormation(cognitoStackName);
                    process.exit(1);
                }catch(e){
                    console.log(e);
                    console.log("Falied to delete cluster resources.");
                }

            }
        }


        const cognitoStackName = scoeConfig.appName + '-' + this.name + '-cognito';
        await AwsUtils.deleteCloudFormation(cognitoStackName);

        if (  env?.type === ScoeDeploymentType.EKS) {
            const envFile = await FileSystem.readPropertiesFile('service/config/.env.' + this.name);
            if ( envFile.ECR_REPO_NAME ) {
                await AwsUtils.deleteCloudFormation(envFile.ECR_REPO_NAME + '-rds');
            }
            if ( envFile.S3_BUCKET_NAME) {
                await AwsUtils.emptyS3Bucket(envFile.S3_BUCKET_NAME);
                await AwsUtils.deleteCloudFormation(envFile.S3_BUCKET_NAME);
            }
            if ( envFile.ECR_REPO_NAME) {
                await AwsUtils.deleteCloudFormation(envFile.ECR_REPO_NAME + '-ecr');
            }

            try {
                await KubectlUtils.enableNginxEKS(true);
            } catch (e) {}
            
            try {
                await EksctlUtils.deleteCluster(envFile?.CLUSTER_NAME);
            }catch(e){
               console.log(e);
               console.log("Failed to delete cluster resources.");
            }
        }
        if ( env ) {
            scoeConfig.deployments.splice(scoeConfig.deployments.indexOf(env), 1);
            await FileSystem.writeJsonFile(SCOE_CONFIG_FILE, scoeConfig);
            await FileSystem.deleteFile('service/config/.env.' + this.name);
            await FileSystem.deleteFile(`service/config/${this.name}.jwt.pem`);
        }
    }
}
