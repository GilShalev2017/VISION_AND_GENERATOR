import {CreateProject} from "../jobs/create-project";
import {DeployProject} from "../jobs/deploy-project";
import {SCOE_CONFIG_FILE, ScoeConfig, ScoeDeploymentType} from "../model/scoe-config";
import {KubectlUtils} from "../utils/kubectl-utils";
import {FileSystem} from "../utils/file-system";

exports.command = 'undeploy [name]'
exports.desc = 'Undeploy app from a cluster'
exports.builder = {
}
exports.handler = async (argv: {
    name: string;
}) => {
    const deployProject = new DeployProject(argv.name, '', false, false);
    await deployProject.run();
}
