
import {FileSystem} from "../utils/file-system";
import {CreateDashboardEntity} from "../jobs/create-dashboard-entity";
import {CreateLoopbackEntity} from "../jobs/create-loopback-entity";
import {UpdateEntity} from "../jobs/update-entity";
import {SCOE_CONFIG_FILE, ScoeConfig} from "../model/scoe-config";
import {RemoveEntity} from "../jobs/remove-entity";

exports.command = 'actions   [action] [name] [actionsString]';
exports.desc = 'Generate project actions from actions string';
exports.builder = {};
exports.handler = async (argv: {
    action: string;
    name: string;
    actionsString?:string;
}) => {
    console.log(argv)
    if ( !argv.actionsString || argv.actionsString.length <=5){
        throw Error("Invalid actions string");
    }
    const actions = JSON.parse(
        Buffer.from(argv.actionsString, 'base64').toString('utf-8')
    );
    
    
    for (const pA of actions) {
        const currAction = pA.action ?? {};
        if (currAction.toString().indexOf("entity") > -1) {
            const {properties,name,service} = pA.parameters;
            switch (currAction) {
                case "remove-entity":{
                    try {
                        const deleteEntity  = new RemoveEntity(name,service);
                        await deleteEntity.run();
                    }catch(e)
                    {
                        console.log("Unable to perform remove-entity command caused by followed error:\n");
                        console.log(e);
                    }
                    break; 
                }
                case "add-entity": {
                    try {
          
                        const createDashboardEntity = new CreateDashboardEntity(name);
                        await createDashboardEntity.run();
                        const createLoopbackEntity = new CreateLoopbackEntity(name, service);
                        await createLoopbackEntity.run();
                    }catch(e)
                    {
                        console.log("Unable to perform add-entity command caused by followed error:\n");
                        console.log(e);
                    }
                    break;
                }
                case "edit-entity": {
                    try {
                        const updateProperty = new UpdateEntity(name);
                        await updateProperty.run('update-property',properties);
                    }catch(e)
                    {
                        console.log("Unable to perform edit-entity command caused by followed error:\n");
                        console.log(e);
                    }
                    break;
                }
                case "entity-add-property": {
                    try {
                        const updateEntity = new UpdateEntity(name);
                        await updateEntity.run('add-property',properties);
                    }catch(e)
                    {
                        console.log("Unable to perform entity-add-property command caused by followed error:\n");
                        console.log(e);
                    }
                    break;
                }
                case "entity-update-property": {
                    try {
                        const updateProperty = new UpdateEntity(name);
                        await updateProperty.run('update-property',properties);
                    }catch(e)  {
                        console.log("Unable to perform entity-update-property command caused by followed error:\n");
                        console.log(e);
                    }
                    break;
                }
                case "entity-delete-property": {
                    try {
                        const deleteProperty = new UpdateEntity(name);
                        await deleteProperty.run('delete-property',properties);
                    }catch(e)  {
                        console.log("Unable to perform entity-delete-property command caused by followed error:\n");
                        console.log(e);
                    }
                    break;
                }
            }
        } else if (currAction.toString().indexOf("service") > -1) {
            const config: ScoeConfig = await FileSystem.readJsonFile(SCOE_CONFIG_FILE);

            const {name, replicas, routePattern} = pA.parameters;
            switch (currAction) {
                case "add-service":
                case "edit-service": {
                    const template = routePattern ? 'service' : 'service-noingress';

                    if (currAction.indexOf('add') > -1) {
                        try {
                            await FileSystem.createFolder(`service/src/micro-services/` + name);
                        } catch (e) {
                            console.log(e);
                        }
                        config.services.push({
                            name: name,
                            replicas: replicas,
                            routePattern: routePattern
                        })
                    } else {
                        const service = config.services.find(item => item.name === name);
                        if (!service) {
                            throw Error("No service found");
                        }
                        service.replicas = replicas;
                        service.routePattern = routePattern;
                    }

                    await FileSystem.copyFile(`chart/templates/${template}.yaml-template`, `chart/templates/${name}.service.yaml`);
                    await FileSystem.replaceInFile(`chart/templates/${name}.service.yaml`, "<<servicename>>", name);
                    await FileSystem.replaceInFile(`chart/templates/${name}.service.yaml`, "<<replicas>>", String(replicas));
                    await FileSystem.replaceInFile(`chart/templates/${name}.service.yaml`, "<<routePattern>>",
                        routePattern.substring(1, routePattern.length - 2));

                    await FileSystem.writeJsonFile(SCOE_CONFIG_FILE, config);
                    console.log(`Service ${name} successfully ${currAction.indexOf("add") > -1 ? 'add' : 'edit'}ed`);
                    if (!routePattern) {
                        console.log("Service is not exposed outside of the cluster");
                    } else {
                        console.log(`All http traffic that fits the pattern ${routePattern} will be routed to this service by the load balancer`);
                    }
                    console.log(`Note: you will need to redeploy to see the changes, using this command: scoe deploy <<deployment-name>>`);

                    break;
                }

                case "delete-service": {
                    try {
                        await FileSystem.deleteFile(`chart/templates/${name}.service.yaml`);
                        config.services = config.services.filter(service => service.name !== name);
                        await FileSystem.writeJsonFile(SCOE_CONFIG_FILE, config);
                    }catch(e)  {
                        console.log("Unable to perform delete-service command caused by followed error:\n");
                        console.log(e);
                    }
                    break;
                }
            }
        }
    }

}
