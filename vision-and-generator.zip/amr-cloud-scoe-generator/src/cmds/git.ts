import {Git} from "../jobs/git";
const argsRegexTemplate = /^[a-zA-Z0-9-_]{0,1000}$/;
exports.command = 'git  [action] [name] [token] [user] [password] [commitMessage]'
exports.desc = 'Perform a git command'
exports.builder = {
}

exports.handler = async (argv: {
    action: string,
    name: string;
    token?: string;
    user?: string;
    password?: string;
    commitMessage?: string;
}) => {

    const {action, commitMessage, name, token, user, password} = argv;
    console.log(argv);
    if (!argsRegexTemplate.test(name) ) {
        throw Error(`Retrieved invalid args:\n name: ${name}\ntoken:${token}\n`);
    }
    switch (action) {
        case 'init': {
            if (!token ||  !argsRegexTemplate.test(token)) {
                throw Error(`Retrieved invalid args:\n name: ${name}\ntoken:${token}\n`);
            }
            try {
                // We assume that if user is defined than https is chosen over ssh
                const git = user ? new Git(name, token, user, password) : new Git(name, token);
                await git.gitInit();
            } catch(e){
                console.log(e);
            }
            break;

        }
        case 'deploy_changes':
        {
          
                if (!commitMessage || commitMessage.toString().length<2) {
                    throw Error(`Retrieved invalid args:\n commit message:${commitMessage}`);
                }
                try {
                    const git = new Git();
                    await git.commit(commitMessage);
                }catch(e){
                    console.log(e);
                }    
          
            break;
        }
    }
}
