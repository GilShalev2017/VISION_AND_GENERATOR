import {CreateProject} from "../jobs/create-project";
import {DeployProject} from "../jobs/deploy-project";
import {ScoeDeploymentType} from "../model/scoe-config";
import {RunShellCommand} from "../utils/run-shell-command";
import inquirer from "inquirer";
import {CreateUsers} from "../jobs/create-users";

exports.command = 'users'
exports.desc = 'Manage users'
exports.builder = {}
exports.handler = async (argv: {
    action: string;


}) => {
    inquirer
        .prompt([
            {
                name: "environment",
                message: "Please select users environment",
                type: "list",
                choices: ["eks", "local"]
            },
            {
                name: "action",
                message: "Please select action to perform",
                type: "list",
                choices: ["add", "list", "delete", "update"]
            }, {
                name: "email",
                message: "Set new user email:",
                type: "input",
                validate: (input) => new RegExp(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/).test(input) ? true : "Email format entered is wrong",
                when: (answers) => answers.action === 'add'
            },
            {
                name: "password",
                message: "password:",
                type: "input",
                // validate: (input) => new RegExp(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*]).{6,}$/).test(input) ? true : "Password must have more than 8 chars,at least one number,at least one special character",
                when: (answers) => answers.email
            },
            {
                name: "delete",
                message: "Please type user id:",
                type: "input",
                when: (answers) => answers.action === 'delete'
            },

            {
                name: "update",
                message: "Please select attributes to edit:\n",
                choices: ["password", "authLevel"],
                type: "checkbox",
                when: (answers) => answers.action === 'update'
            },
            {
                name: "userId",
                message: "Please type user id:",
                type: "input",
                when: (answers) => answers.action === 'update'
            },
            {
                name: "passwordUpdate",
                message: "Please type new password:",
                type: "input",
                when: (answers) => answers.action === 'update' && answers.update.indexOf('password') > -1
            },
            {
                name: "authLevelUpdate",
                message: "Please type new email:",
                type: "input",
                when: (answers) => answers.action === 'update' && answers.update.indexOf('authLevel') > -1
            }

        ])
        .then(async answers => {
            const createUsers = new CreateUsers( answers);
            await createUsers.run();
            console.log(answers)
        })
        .catch(error => console.log(error));


}
