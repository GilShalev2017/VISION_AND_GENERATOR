import {CreateProject} from "../jobs/create-project";
import {DeployProject} from "../jobs/deploy-project";
import {SCOE_CONFIG_FILE, ScoeConfig, ScoeDeploymentType} from "../model/scoe-config";
import {RunShellCommand} from "../utils/run-shell-command";
import {KubectlUtils} from "../utils/kubectl-utils";
import {FileSystem} from "../utils/file-system";

exports.command = 'db [name]'
exports.desc = 'Manage users'
exports.builder = {
    name: {
        default: 'postgres',
        choices: ["postgres", "mongo"],
    },
    port: {
        default: '7000',
        description: "Port to expose"
    },
}
exports.handler = async (argv: {
    name: string;
    port: string;
}) => {
    const config: ScoeConfig = await FileSystem.readJsonFile(SCOE_CONFIG_FILE);
    if (!config) {
        throw Error("Invalid project root");
    }
    if (argv.name === 'postgres') {
        await KubectlUtils.portForward(config.appName + '-postgresql-0', '5432', argv.port);
    }
}
