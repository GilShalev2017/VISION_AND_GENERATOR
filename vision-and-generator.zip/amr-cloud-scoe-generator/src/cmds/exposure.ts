import {CreateProject} from "../jobs/create-project";
import inquirer from "inquirer";

inquirer.registerPrompt('autocomplete', require('inquirer-autocomplete-prompt'));
import {KubectlUtils} from "../utils/kubectl-utils";

exports.command = 'expose [name]'
exports.desc = 'Expose service port'
exports.builder = {}
exports.handler = async (argv: {
    name: string;
}) => {

    if (!/^[a-z0-9-]{2,53}$/.test(argv.name)) {
        throw Error("Invalid app name. App names must only contain lowercase alphanumerical characters or -");
    }
    const pods = await KubectlUtils.getPods()
    inquirer
        .prompt([
            {
                type: 'autocomplete',
                name: 'pod',
                pageSize: 20,
                message: 'Choices support multiline choices (should increase pagesize)',
                source: () => pods
            },
            {
                name: "localPort",
                message: "Enter local port:",
                type: "input",
                when: (answers) => answers.pod
            },
            {
                name: "originPort",
                message: "Enter origin port(inner cluster port):",
                type: "input",
                when: (answers) => answers.pod
            }

        ]).then((answers) => {
        const {pod, originPort, localPort} = answers;
        if (pod && originPort && localPort) {
            KubectlUtils.portForward(pod, originPort, localPort);

        }

    }).catch(e => {
        console.log("Error occured", e)
    });

}
