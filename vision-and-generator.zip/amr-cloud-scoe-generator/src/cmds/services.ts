import {CreateProject} from "../jobs/create-project";
import {CreateEksCluster} from "../jobs/create-eks-cluster";
import {FileSystem} from "../utils/file-system";
import {SCOE_CONFIG_FILE, ScoeConfig} from "../model/scoe-config";
import {CreateLocalCluster} from "../jobs/create-local-cluster";
import {ListEntities} from "../jobs/list-entities";
import {ListServices} from "../jobs/list-services";

exports.command = 'services [action]'
exports.desc = 'Add & manage services'
exports.builder = {
    action: {
        default: 'list',
        choices: ["add", "list", "edit", "remove"],
        description: "Action to perform"
    },
    name: {
        description: "Service name",
    },
    routePattern: {
        default: '',
        description: "Url pattern to route requests to service. Leave empty to block all outside connection to service"
    },
    replicas: {
        default: 1,
        type: 'number',
        description: "Number of container instances"
    },
}
exports.handler = async (argv: {
    action: string;
    name: string;
    replicas: number;
    routePattern: string;
}) => {
    const config: ScoeConfig = await FileSystem.readJsonFile(SCOE_CONFIG_FILE);
    switch (argv.action) {
        case "add":
        case "edit":
            if (!argv.name || !/^[a-z0-9-]{1,53}$/.test(argv.name)) {
                throw Error("Invalid service name. Service names must only contain lowercase alphanumerical characters or -");
            }

            const template = argv.routePattern ? 'service' : 'service-noingress';
            if (argv.action === 'add') {
                try {
                    await FileSystem.createFolder(`service/src/micro-services/` + argv.name);
                } catch (e) {
                    console.log(e);
                }
                config.services.push({
                    name: argv.name,
                    replicas: argv.replicas,
                    routePattern: argv.routePattern
                })
            } else {
                const service = config.services.find(item => item.name === argv.name);
                if (!service) {
                    throw Error("No service found");
                }
                service.replicas = argv.replicas;
                service.routePattern = argv.routePattern;
            }

            await FileSystem.copyFile(`chart/templates/${template}.yaml-template`, `chart/templates/${argv.name}.service.yaml`);
            await FileSystem.replaceInFile(`chart/templates/${argv.name}.service.yaml`, "<<servicename>>", argv.name);
            await FileSystem.replaceInFile(`chart/templates/${argv.name}.service.yaml`, "<<replicas>>", String(argv.replicas));
            await FileSystem.replaceInFile(`chart/templates/${argv.name}.service.yaml`, "<<routePattern>>",
                argv.routePattern.substring(1, argv.routePattern.length - 2));

            await FileSystem.writeJsonFile(SCOE_CONFIG_FILE, config);
            console.log(`Service ${argv.name} successfully ${argv.action}ed`);
            if (!argv.routePattern) {
                console.log("Service is not exposed outside of the cluster");
            } else {
                console.log(`All http traffic that fits the pattern ${argv.routePattern} will be routed to this service by the load balancer`);
            }
            console.log(`Note: you will need to redeploy to see the changes, using this command: scoe deploy <<deployment-name>>`);
            break;
        case "remove":
            await FileSystem.deleteFile(`chart/templates/${argv.name}.service.yaml`);
            config.services = config.services.filter(service => service.name !== argv.name);
            await FileSystem.writeJsonFile(SCOE_CONFIG_FILE, config);
            console.log(`Service ${argv.name} successfully removed. Note: you will need to redeploy to see the changes`);
            break;
        case "list":
            const listServices = new ListServices();
            await listServices.run();
            break;
        default:
            console.log("Services:");
            console.log(config.services);
    }
}
