import {CreateProject} from "../jobs/create-project";
import {FileSystem} from "../utils/file-system";
import {SCOE_CONFIG_FILE, ScoeConfig} from "../model/scoe-config";
import {StringUtils} from "../utils/string-utils";
import {RunShellCommand} from "../utils/run-shell-command";
import {CreateDashboardEntity} from "../jobs/create-dashboard-entity";
import {CreateLoopbackEntity} from "../jobs/create-loopback-entity";
import inquirer from "inquirer";
import {UpdateEntity} from "../jobs/update-entity";
import {ListEntities} from "../jobs/list-entities";


exports.command = 'entity [action]'
exports.desc = 'Entity operations'
exports.builder = {
    action: {
        default: 'list',
        choices: ['add', 'add-property', 'list', 'delete-property','update-property'],
        description: "Action to perform"
    },
    name: {
        description: "Entity name",
    },
    property: {
        description: "Property name",
    },
    type: {
        description: "Property type",
        default: 'string',
        choices: ["string", 'number', 'list', 'date', 'boolean'],
    },
    newPropertyValue: {
        description: "New Property name",
    },
    newPropertyType: {
        description: "New Property type",
        default: 'string',
        choices: ["string", 'number', 'list', 'date', 'boolean'],
    },
    service: {
        description: "Service selection",
    },
}
exports.handler = async (argv: {
    action: string;
    name: string;
    property: string;
    type: string;
    service: string;
    newPropertyValue? :string;
    newPropertyType ?:string;
}) => {
    // DEBUG ONLY
    // process.chdir('C:\\Users\\rmichael\\egi\\generator-workspace\\workspace2\\vtg');
    // process.chdir('C:\\test\\roy-test');
    
    const config: ScoeConfig = await FileSystem.readJsonFile(SCOE_CONFIG_FILE);
    if (!config) {
        throw Error("Invalid project root");
    }
    // debugger
    if (argv.action !== 'list' && (!argv.name || !/^[a-z0-9-]{1,53}$/.test(argv.name))) {
        throw Error("Invalid entity name. Entity names must only contain lowercase alphanumerical characters or -");
    }
    switch (argv.action) {
        case 'delete':
        case 'add':
            const choices = config.services.map(item => item.name);
            if (!argv.service) {
                inquirer
                    .prompt([{
                        name: "service",
                        message: "Select service",
                        type: "list",
                        choices,
                        default: []
                    }])
                    .then(async answers => {
                        const selected = answers.service;
                        const createDashboardEntity = new CreateDashboardEntity(argv.name);
                        await createDashboardEntity.run();
                        const createLoopbackEntity = new CreateLoopbackEntity(argv.name, selected);
                        await createLoopbackEntity.run();
                        console.log(`Note: you will need to redeploy to see the changes, using this command: scoe deploy <<deployment-name>>`);
                    })
                    .catch(error => {
                        console.log(error);
                        if (error.isTtyError) {
                            // Prompt couldn't be rendered in the current environment
                        } else {
                            // Something else when wrong
                        }
                    });
            } else {
                const selected = argv.service
                if (!choices.includes(selected)) {
                    throw new Error(`${selected} service does not exist`);
                }
                const createDashboardEntity = new CreateDashboardEntity(argv.name);
                await createDashboardEntity.run();
                const createLoopbackEntity = new CreateLoopbackEntity(argv.name, selected);
                await createLoopbackEntity.run();
            }
            break;
        case 'add-property':
            const updateEntity = new UpdateEntity(argv.name);
            await updateEntity.run('add-property',[{ property:argv.property, type:argv.type,service: argv.service}]);
            break;
        case 'update-property':
            const updateProperty = new UpdateEntity(argv.name);
            await updateProperty.run('update-property',[{property:argv.property,type: argv.type,service:argv.service,newPropertyValue:argv.newPropertyValue,newPropertyType:argv.newPropertyType}]);
            break;
        case 'delete-property':
            const deleteProperty = new UpdateEntity(argv.name);
            await deleteProperty.run('delete-property',[{property: argv.property,type: argv.type,service:argv.service}]);
            break;
        case 'list':
            const listEntities = new ListEntities();
            await listEntities.run();
            break;
    }
}

