import {CreateProject} from "../jobs/create-project";
import {CreateEksCluster} from "../jobs/create-eks-cluster";
import {FileSystem} from "../utils/file-system";
import {SCOE_CONFIG_FILE, ScoeConfig} from "../model/scoe-config";
import {CreateLocalCluster} from "../jobs/create-local-cluster";
import {AwsUtils, CognitoConfig} from "../utils/aws-utils";
import {CreateCognitoPool} from "../jobs/create-cognito-pool";
import {DeleteEnv} from "../jobs/delete-env";
import inquirer from "inquirer";
import {KubectlUtils} from "../utils/kubectl-utils";
import {exit} from "yargs";

exports.command = 'env [action]'
exports.desc = 'Add & manage environments'
exports.builder = {
    type: {
        default: 'local',
        alias: 't',
        choices: ["eks", "local"],
        description: "Currently supported: amazon ('eks'), local"
    },
    action: {
        default: 'list',
        choices: ["add", "list", "delete"],
        description: "Action to perform"
    },

    name: {
        description: "Name of the env, e.g 'local', 'dev'"
    },
    contextName: {
        description: "Context name",
        default: "docker-desktop"
    },
    nodes: {
        description: "Number of nodes in cluster (desired capacity)"
    },
    eksctl: {
        description: "Any valid eksctl option. For example: '--eksctl.nodes-min 4'"
    },
    default: {
        description: "Set true for managed PostgreSQL default"
    }
}
exports.handler = async (argv: {
    action: string;
    name: string;
    contextName: string;
    type: "eks" | "local";
    nodes: string;
    eksctl: { [key: string]: string }
    default?: boolean;
}) => {
    switch (argv.action) {
        case "add":
            if (!argv.name || !/^[a-z0-9-]{1,53}$/.test(argv.name)) {
                throw Error("Invalid cluster name. Cluster names must only contain lowercase alphanumerical characters or -");
            }
            const regionRes =await  inquirer.prompt([{
                name: "region",
                message: "Select a region to apply:\n",
                type: "input",
                validate:(region=>region && /^us-[a-z]{0,9}-[0-9]/.test(region) ? true:"Wrong values entered")
            }]);
            if ( regionRes.region) {
                await FileSystem.replaceInFile(`service/config/global.env`,'<<aws_region>>',regionRes.region)
            }
            else{
                console.log("region values are wrong.")
                process.exit(0);
            }

            if (argv.type === "eks") {
                if (argv.default) {
                    try {
                        const createEksCluster = new CreateEksCluster(argv.name, argv.nodes, argv.eksctl, [{name:'postgresType',type:true}]);
                        await createEksCluster.run();
                        const isArgo = await FileSystem.readFile(process.cwd() + "/service/src/micro-services/argo/argo.controller.ts");
                        if (isArgo.toString().indexOf("undocumented") === -1) {
                            await KubectlUtils.installArgo()
                        }
                        await AwsUtils.createCognitoPool(argv.name);
                    } catch (e) {
                        console.log(e);
                        console.log("Env build failed.")
                        await deleteEnv(argv.name);
                        exit(1, new Error('Create EKS env failed'));
                    }
                } 
                else {
                    inquirer
                        .prompt([{
                            name: "postgresType",
                            message: "Select PostgreSQL Type",
                            type: "list",
                            choices: ["Managed", "In-Cluster"],
                            default: ["Managed"]
                        },
                        {
                            name: "messageBrokerType",
                            message: "Select message broker Type",
                            type: "list",
                            choices: ["Managed", "In-Cluster"],
                            default: ["Managed"]
                        }, 
                            {
                                name:"efsType",
                                message: "Select Efs mounting device",
                                type: "list",
                                choices: ["Managed", "None"],
                                default: ["Managed"]
                            },
                    ])
                    .then(async answers => {
                        const managedServices = Object.keys(answers).map(cAk => ({
                            name: cAk,
                            type: answers[cAk] === "Managed"
                        }))
                        const createEksCluster = new CreateEksCluster(argv.name, argv.nodes ??1, argv.eksctl, managedServices);
                        await createEksCluster.run();

                    })
                    .catch(error => {
                        console.log(error);
                    });
            }}
            
            const scoeConfig: ScoeConfig = await FileSystem.readJsonFile(SCOE_CONFIG_FILE);
            const createCognitoPool = new CreateCognitoPool(scoeConfig.appName, argv.name);
            await createCognitoPool.run();
            break;
        case "delete":
            await deleteEnv(argv.name);
            break;
        default:
            console.log("Environments:");
            const config: ScoeConfig = await FileSystem.readJsonFile(SCOE_CONFIG_FILE);
            console.log(config.deployments);
    }
}
const deleteEnv=async (envName:string)=>{
    inquirer
        .prompt([{
            name: "confirm",
            message: "This will delete all cloud resources associated with this environment. Are you sure (y/N)?",
            type: "input",
        }])
        .then(async answers => {
            if (answers.confirm === 'y') {
                const deleteEnv = new DeleteEnv(envName);
                await deleteEnv.run();
            }
        })
        .catch(error => {
            console.log(error);
            console.log("Failed to remove environment.")
            process.exit(1);
        });
}
