import {CreateProject} from "../jobs/create-project";
import {FileSystem} from "../utils/file-system";
import {SCOE_CONFIG_FILE, ScoeConfig} from "../model/scoe-config";
import path from "path";

exports.command = 'update'
exports.desc = 'Update project'
exports.builder = {

}
exports.handler = async (argv: {
}) => {
    const config: ScoeConfig = await FileSystem.readJsonFile(SCOE_CONFIG_FILE);
    if (!config) {
        throw new Error("Not a valid project directory");
    }
    await FileSystem.copyFolder(FileSystem.getResourcesPath() + 'project-template', process.cwd(), (src, dest) => {
        return ['Chart.yaml', '.env'].indexOf(path.basename(dest)) === -1;
    });
}
