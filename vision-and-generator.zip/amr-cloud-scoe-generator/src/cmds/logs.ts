import {CreateProject} from "../jobs/create-project";
import {DeployProject} from "../jobs/deploy-project";
import {SCOE_CONFIG_FILE, ScoeConfig, ScoeDeploymentType} from "../model/scoe-config";
import {RunShellCommand} from "../utils/run-shell-command";
import {KubectlUtils} from "../utils/kubectl-utils";
import {FileSystem} from "../utils/file-system";

exports.command = 'logs [name]'
exports.desc = 'Quick logs with tail'
exports.builder = {
    name: {
        description: "Service name"
    },
    tail: {
        type: 'number',
        default: '50',
        description: "How much to tail"
    },
}
exports.handler = async (argv: {
    name: string;
    tail: number;
}) => {
    await KubectlUtils.logs(`scoe=${argv.name}-service`, argv.tail);
}
