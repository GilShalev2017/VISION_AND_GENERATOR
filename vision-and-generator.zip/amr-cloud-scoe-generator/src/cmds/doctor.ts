import {AwsUtils} from "../utils/aws-utils";
import {EksctlUtils} from "../utils/eksctl-utils";
import {DockerUtils} from "../utils/docker-utils";
import {KubectlUtils} from "../utils/kubectl-utils";
import {ProxyUtils} from "../utils/proxy-utils";

const constants = require('../utils/constants');
const logger = require('../utils/winston');

exports.command = 'doctor'
exports.desc = 'Checks generator cli tools, proxy settings and k8s cluster'
exports.builder = {
}

exports.handler = async (argv: {

}) => {
    let foundKubeCtl:boolean = false;
    let foundEksCtl:boolean = false;
    let foundHelmCtl:boolean = false;
    let foundDocker:boolean = false;
    let foundAwsCli:boolean = false;
    let foundAwsUser:boolean = false;
    let foundAwsRegion:boolean = false;
    let currentAwsUser: string = "";
    let currentAwsRegion: string = "";

    let kubectlVersionMajor: string = "";
    let kubectlVersionMinor: string = "";
    let eksVersion: string = "";
    let helmVersion: string = "";
    let dockerVersion: string = "";
    let awsCliVersion: string = "";

    try {
        let version = await KubectlUtils.checkVersion();
        kubectlVersionMajor = version.stdout.split('Major:"')[1].split('",')[0];
        kubectlVersionMinor = version.stdout.split('Minor:"')[1].split('",')[0];
        foundKubeCtl = true;
    } catch (e) {}

    try {
        let foundEksVersion = await EksctlUtils.checkVersion();
        eksVersion = foundEksVersion.stdout.trim();
        foundEksCtl = true;
    } catch (e) {}

    try {
        let foundHelmVersion = await KubectlUtils.checkHelmVersion();
        helmVersion = foundHelmVersion.stdout.split('{Version:"')[1].split('",')[0];
        foundHelmCtl = true;
    } catch (e) {}

    try {
        let foundDockerVersion = await DockerUtils.checkVersion();
        dockerVersion = foundDockerVersion.stdout.split('Version:')[1].split('API version')[0].trim();
        foundDocker = true;
    } catch (e) {}

    try {
        let foundAwsCliVersion = await AwsUtils.checkVersion();
        awsCliVersion = foundAwsCliVersion.stdout.split('aws-cli/')[1].split(' ')[0];
        foundAwsCli = true;
    } catch (e) {}

    try {
        const currentUser = await AwsUtils.getCurrentUser();
        let re = /\"/gi;
        currentAwsUser = currentUser.split('UserName')[1].split(',')[0].replace(':','').replace(re,'').trim();
        foundAwsUser = true;
    } catch (e) {}

    try {
        currentAwsRegion = await AwsUtils.getCurrentRegion();
        foundAwsRegion = true;
    } catch (e) {}

    logger.log("info","Installed Tools:");
    foundKubeCtl ? logger.log("debug",`+ kubectl client is installed. Version: Major:${kubectlVersionMajor}, Minor: ${kubectlVersionMinor}`,constants.DEFAULT_COLOR) : logger.log("error","- kubectl client is not installed. Please install and configure.",constants.DEFAULT_COLOR);
    foundEksCtl ? logger.log("debug",`+ eksctl is installed. Version: ${eksVersion}`,constants.DEFAULT_COLOR) : logger.log("error","- eksctl is not installed. Please install and configure.",constants.DEFAULT_COLOR);
    foundHelmCtl ? logger.log("debug",`+ helm is installed. Version: ${helmVersion}`,constants.DEFAULT_COLOR) : logger.log("error","- helm is not installed. Please install and configure.",constants.DEFAULT_COLOR);
    foundDocker ? logger.log("debug",`+ docker is installed. Version ${dockerVersion}`,constants.DEFAULT_COLOR) : logger.log("error","- docker is not installed. Please install and configure.",constants.DEFAULT_COLOR);
    foundAwsCli ? logger.log("debug",`+ aws cli is installed. Version ${awsCliVersion}`,constants.DEFAULT_COLOR) : logger.log("error","- aws cli is not installed. Please install and configure.",constants.DEFAULT_COLOR);

    ProxyUtils.printProxyEnvironmentSettings();
    await ProxyUtils.printProxyConfigFileSettings();

    console.log(constants.DEFAULT_COLOR,"\nAws Settings:");
    foundAwsUser ? console.log(constants.OK_COLOR,`+ aws_user = ${currentAwsUser}`,constants.DEFAULT_COLOR) : console.log(constants.FAIL_COLOR,"- aws_user = not set!!!",constants.DEFAULT_COLOR);
    foundAwsRegion ? console.log(constants.OK_COLOR,`+ aws_region = ${currentAwsRegion}`,constants.DEFAULT_COLOR) : console.log(constants.FAIL_COLOR,"- aws_region = not set!!!",constants.DEFAULT_COLOR);

    console.log(constants.DEFAULT_COLOR,"\nLocal cluster(s):");
    let contextNames = ["kind-kind","docker-desktop"];
    await KubectlUtils.findLocalClusters(contextNames);

    console.log(constants.DEFAULT_COLOR,"\n");
}
