import {CreateProject, Answers} from "../jobs/create-project";
import inquirer from "inquirer";
import {FileSystem} from "../utils/file-system";
import os from "os";

exports.command = 'create [name] [default]'
exports.desc = 'Create a new project'
exports.builder = {
}
exports.handler = async (argv: {
    name: string;
    default?: boolean;
}) => {
    // const credentials = await FileSystem.getAllFiles(process.cwd(),[],true);
    // console.log(credentials)
    // return;
    if (!/^[a-z0-9-]{2,53}$/.test(argv.name)) {
        throw Error("Invalid app name. App names must only contain lowercase alphanumerical characters or -");
    }
    if (!argv.default) {
        inquirer
            .prompt([{
                name: "components",
                message: "Select components",
                type: "checkbox",
                choices: ["RabbitMq", "PostgreSQL", "MongoDB", "Prometheus", "ElasticSearch", "Argo"],
                default: ["RabbitMq", "PostgreSQL", "Prometheus", "ElasticSearch"]
            }, {
                name: "cloud",
                message: "Select Cloud Provider",
                type: "list",
                choices: ["None", "AWS"],
                default: ["AWS"]
            }, {
                name: "awsAccessKey",
                message: "Enter AWS Access Key (leave empty to use environment default, e.g ~/.aws/credentials)",
                type: "input",
                when: (answers) => answers.cloud === 'AWS'
            }, {
                name: "awsSecretKey",
                message: "Enter AWS Secret Key (leave empty to use environment default, e.g ~/.aws/credentials)",
                type: "input",
                when: (answers) => answers.cloud === 'AWS'
            }, {
                name: "awsRegion",
                message: "Enter AWS Region (leave empty to use environment default, e.g ~/.aws/credentials)",
                type: "input",
                when: (answers) => answers.cloud === 'AWS'
            }, {
                name: "authentication",
                message: "Select Authentication Strategy",
                type: "list",
                choices: ["Local", "AWS Cognito"],
                default: ["AWS Cognito"]
            }])
            .then(async answers => {

                const createProject = new CreateProject(argv.name, answers);
                await createProject.run();

            })
            .catch(error => {
                console.log(error);
                if (error.isTtyError) {
                    // Prompt couldn't be rendered in the current environment
                } else {
                    // Something else when wrong
                }
            });
    } else {
        const answers: Answers = {
            components: ["RabbitMq", "PostgreSQL"],
            authentication: "AWS Cognito",
            cloud: "AWS",
            awsAccessKey: 'AKIAWKTEUXFJNXU2RZ6L',
            awsSecretKey: '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',
            awsRegion: 'us-west-1'
        }
        try {
            const createProject = new CreateProject(argv.name, answers);
            await createProject.run();
        } catch (e) {
            console.log(e);
        }
    }


}
