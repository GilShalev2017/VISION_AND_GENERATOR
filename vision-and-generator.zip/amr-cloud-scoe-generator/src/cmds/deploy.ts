import {CreateProject} from "../jobs/create-project";
import {DeployProject} from "../jobs/deploy-project";
import {ScoeDeploymentType} from "../model/scoe-config";

exports.command = 'deploy [name]'
exports.desc = 'Deploy to a specific environment'
exports.builder = {
    ngServe: {
        description: "Whether to deploy ng serve locally"
    },
    appVersion: {
        description: "Version to be injected to helm release"
    },
}
exports.handler = async (argv: {
    name: string;
    appVersion: string;
    ngServe: boolean;
}) => {

    const deployProject = new DeployProject(argv.name, argv.appVersion || '' + Date.now(), argv.ngServe, true);
    await deployProject.run();
}
