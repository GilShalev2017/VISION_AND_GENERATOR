import {ProxyUtils} from "../utils/proxy-utils";

exports.command = 'proxy [action]'
exports.desc = 'Sets or gets the environment and docker proxy settings'
exports.builder = {
    action: {
        default: 'get',
        choices: ["get", "set","unset"],
        description: "Action to perform"
    },
}

exports.handler = async (argv: {
    action: string;
}) => {

    if (argv.action === 'get') {
        ProxyUtils.printProxyEnvironmentSettings();
        await ProxyUtils.printProxyConfigFileSettings();
    }
    else if(argv.action === 'set') {
        ProxyUtils.setProxyEnvironmentSettings();
        await ProxyUtils.appendProxySettingsToJsonConfigFile();
    }
    else if(argv.action === 'unset') {
        ProxyUtils.unsetProxyEnvironmentSettings();
        await ProxyUtils.removeProxySettingsFromJsonConfigFile();
    }
    else {
        console.log("No such option");
    }
}

