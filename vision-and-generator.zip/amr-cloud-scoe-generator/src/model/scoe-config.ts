export const SCOE_CONFIG_FILE = "scoe-config.json";
export const DOCKER_CLIENT_CONFIG_FILE = "config.json";

export enum ScoeDeploymentType {
    EKS = "eks",
    LOCAL = "local"
}

export interface ScoeDeployment {
    type: ScoeDeploymentType;
    registry?: string;
    contextName: string;
    name: string;
    dashboardUrl?: string;
    apiUrl?: string;
}

export interface ScoeService {
    name: string;
    mountedStorage?: boolean;
    routePattern: string;
    replicas: number;
}

export interface ScoeConfig {
    appName: string;
    registry?: string;
    deployments: ScoeDeployment[];
    services: ScoeService[];
}
