export interface ClusterDescription {
    subnetIds: string[];
    securityGroupIds: string[];
}