const cliProgress = require('cli-progress');

export class ProgressBar {

    startValue: number;
    total: number;
    pb: any;

    constructor(startValuePrm: number, totalPrm: number) {
        this.startValue = startValuePrm;
        this.total = totalPrm;
        this.pb = new cliProgress.SingleBar({}, cliProgress.Presets.legacy);

    }

    startPb() {
        this.pb.start(this.total, this.startValue)
    }

    updateTick(tick: number): void {
        this.pb.update(tick)
    }

    endPb(): void {
        this.pb.stop()
    }
}