import util from "util";
import child_process, {spawn} from "child_process";
import {RunShellCommand} from "./run-shell-command";
import {AwsUtils} from "./aws-utils";

const exec = util.promisify(child_process.exec);

const USERNAME = 'mosheshaham';
const PASSWORD = 'yappie52!';

export class DockerUtils {
    static async checkVersion() {
        return await exec('docker version');
    }

    static async build(name: string, version: string) {
        return await RunShellCommand.asPromise("docker", [
            "build",
            "-t",
            name + ":" + version,
            "-t",
            AwsUtils.getRegistry() + ":" + name + "_" + version,
            "."
        ], process.cwd() + "/service");
    }

    static async push(name: string, version: string, registry: string) {
        return await RunShellCommand.asPromise("docker", [
            "push",
            AwsUtils.getRegistry() + ":" + name + "_" + version
        ], process.cwd() + "/service");
    }

    static async login() {
        return await RunShellCommand.spawnAsPromise("docker", [
            "login",
            "-u", USERNAME,
            '-p', PASSWORD
        ], process.cwd() + "/service");
    }

    static async loginToRegistry() {
        return await RunShellCommand.asPromise("aws ecr get-login-password --region us-west-2 | docker login --username AWS --password-stdin", [
            AwsUtils.getRegistry()
        ], process.cwd() + "/service");
    }
}
