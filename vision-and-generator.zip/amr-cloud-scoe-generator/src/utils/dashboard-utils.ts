import {FileSystem} from "./file-system";

export class DashboardUtils {
    static async createAngularConfiguration(name: string) {
        const angularJson = await FileSystem.readJsonFile('dashboard/angular.json');
        angularJson.projects['client-framework'].architect.build.configurations[name] = {
            "fileReplacements": [
                {
                    "replace": "src/environments/environment.ts",
                    "with": `src/environments/environment.${name}.ts`
                }
            ],
            "optimization": true,
            "outputHashing": "all",
            "sourceMap": false,
            "namedChunks": false,
            "extractLicenses": true,
            "vendorChunk": false,
            "buildOptimizer": true,
            "budgets": [
                {
                    "type": "initial",
                    "maximumWarning": "2mb",
                    "maximumError": "5mb"
                },
                {
                    "type": "anyComponentStyle",
                    "maximumWarning": "6kb",
                    "maximumError": "10kb"
                }
            ]
        }
        await FileSystem.writeJsonFile('dashboard/angular.json', angularJson);
    }
}
