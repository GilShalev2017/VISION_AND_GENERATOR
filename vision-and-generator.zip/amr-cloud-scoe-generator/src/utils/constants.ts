module.exports = Object.freeze({
    OK_COLOR: "\x1b[32m",
    FAIL_COLOR: "\x1b[31m",
    DEFAULT_COLOR: "\x1b[0m"
});
