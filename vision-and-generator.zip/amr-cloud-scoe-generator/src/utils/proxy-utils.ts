import {DOCKER_CLIENT_CONFIG_FILE} from "../model/scoe-config";
import {FileSystem} from "./file-system";

const constants = require('./constants');

export class ProxyUtils {

    static printProxyEnvironmentSettings() {

        console.log(constants.DEFAULT_COLOR, "\nProxy Environment Settings:");
        process.env.http_proxy ? console.log(constants.OK_COLOR, `http_proxy = ${process.env.http_proxy}`, constants.DEFAULT_COLOR) : console.log(constants.FAIL_COLOR, `http_proxy = not set!!!`, constants.OK_COLOR);
        process.env.https_proxy ? console.log(constants.OK_COLOR, `https_proxy = ${process.env.https_proxy}`, constants.DEFAULT_COLOR) : console.log(constants.FAIL_COLOR, `https_proxy = not set!!!`, constants.OK_COLOR);
        process.env.no_proxy ? console.log(constants.OK_COLOR, `no_proxy = ${process.env.no_proxy}`, constants.DEFAULT_COLOR) : console.log(constants.FAIL_COLOR, `no_proxy = not set!!!`,constants.OK_COLOR);
    }

    static getDockerConfigFilePath():string {
        let filePath = "";
        if(process.platform === "win32") {
            filePath = process.env.USERPROFILE + "\\.docker\\" + DOCKER_CLIENT_CONFIG_FILE;
        }
        else if(process.platform === "linux") {
            filePath = process.env.HOME + "/.docker/" + DOCKER_CLIENT_CONFIG_FILE;
        }
        return filePath;
    }

    static async printProxyConfigFileSettings() {
        let filePath = ProxyUtils.getDockerConfigFilePath();
        if(FileSystem.isFileExist(filePath)) {
            console.log(constants.DEFAULT_COLOR, "\nProxy Docker Config File Settings:",constants.DEFAULT_COLOR);
            let jsonFileContent = await FileSystem.readJsonFile(filePath);
            if(jsonFileContent["proxies"]) {
                console.log(jsonFileContent["proxies"]["default"]);
            }
            else {
                console.log(constants.FAIL_COLOR,"No settings found in file",constants.DEFAULT_COLOR);
            }
        }
        else {
            console.log(constants.FAIL_COLOR, "\nDocker Config File Not Found:",constants.DEFAULT_COLOR);
        }
    }

    static async appendProxySettingsToJsonConfigFile() {
        try {
            let filePath = ProxyUtils.getDockerConfigFilePath();
            await ProxyUtils.appendHardCodedSettings(filePath);
        }
        catch (e) {
            console.log("command failed to set proxy settings in docker config file!!! " + e);
        }
    }

    static async appendHardCodedSettings(path: string) {
        let configObject = await FileSystem.readJsonFile(path);
        let proxyConfig =
            {
                "default": {
                    "httpProxy": "http://proxy-chain.intel.com:911",
                    "httpsProxy": "http://proxy-chain.intel.com:912",
                    "noProxy": "intel.com,.intel.com,localhost,127.0.0.1,docker.internal"
                }
            }
        configObject["proxies"] = proxyConfig;
        await FileSystem.writeJsonFile(path, configObject);
    }

    static async removeSettings(path: string) {
        let configObject = await FileSystem.readJsonFile(path);
        if(configObject["proxies"]) {
            delete configObject["proxies"];
        }
        await FileSystem.writeJsonFile(path, configObject);
    }

    static setProxyEnvironmentSettings() {
        process.env.http_proxy = "http://proxy-chain.intel.com:911";
        process.env.https_proxy = "http://proxy-chain.intel.com:912";
        process.env.no_proxy = "intel.com,.intel.com,localhost,127.0.0.1,docker.internal";
    }

    static async SetUserSelectionProxySettings() {
        try {
            let filePath = ProxyUtils.getDockerConfigFilePath();
            let configObject = await FileSystem.readJsonFile(filePath).then( configObject=> {
                if (configObject["proxies"]) {
                    ProxyUtils.setProxyEnvironmentSettings();
                }
            });
        }
        catch (e) {
            console.log("command failed to set user proxy settings" + e);
        }
    }

    static unsetProxyEnvironmentSettings()
    {
        process.env.http_proxy = "";
        process.env.https_proxy = "";
        process.env.no_proxy = "";
    }

    static async removeProxySettingsFromJsonConfigFile()
    {
        try {
            let filePath = ProxyUtils.getDockerConfigFilePath();
            await ProxyUtils.removeSettings(filePath);
        }
        catch (e) {
            console.log("command failed to unset proxy settings in docker config file!!! " + e);
        }
    }
}