import util from "util";
import child_process, {spawn} from "child_process";
import {RunShellCommand} from "./run-shell-command";
import {ScoeDeploymentType} from "../model/scoe-config";
import {FileSystem} from "./file-system";
import {AwsUtils} from "./aws-utils";

const constants = require('./constants');
const exec = util.promisify(child_process.exec);

export class KubectlUtils {
    static async checkVersion() {
        return await exec('kubectl version --client=true');
    }

    static async checkClientAndServerVersions() {
        return await exec('kubectl version');
    }

    static async checkHelmVersion() {
        return await exec('helm version');
    }

    static async getCurrentContext() {
        const context = await exec('kubectl config current-context');
        return context.stdout;
    }
    static async changeCurrentContext(contextName: string) {
        const context = await exec('kubectl config use-context ' + contextName);
        return context.stdout;
    }
    static async findLocalClusters(contextNames: string[]) {
        let clusterNum = 0;
        for (const contextName of contextNames) {
            try {
                await KubectlUtils.changeCurrentContext(contextName);
                await KubectlUtils.checkClientAndServerVersions();
                console.log(constants.OK_COLOR, `+ found cluster with context: ${contextName}`, constants.DEFAULT_COLOR);
                clusterNum++;
            } catch {
            }
        }
        if (clusterNum == 0) {
            console.log(constants.FAIL_COLOR, "- No local cluster found", constants.DEFAULT_COLOR);
        }
    }
    static async kindLoadDockerImage(image: string) {
        const context = await exec('kind load docker-image ' + image);
        return context.stdout;
    }

    static async portForward(pod: string, originPort: string, localPort: string, isBackground?: boolean) {
        const args = ["port-forward", pod, `${localPort}:${originPort}`]

        if (isBackground) {
            await RunShellCommand.spawnInBackground("kubectl", args)
        } else {
            await RunShellCommand.spawnAsPromise("kubectl", args);
        }
    }

    static async getPods(specificPod ?: string): Promise<string[]> {
        try {
            const context = await exec('kubectl get pods --no-headers -o custom-columns=":metadata.name"');
            const podsArr = context.stdout.toString().split("\n").filter(cP => cP.toString() !== '');
            return specificPod ? podsArr.filter(p => p.toString().indexOf(specificPod) > -1) : podsArr
        } catch (e) {
            return [];
        }

    }

    static async logs(label: string, tail: number) {
        // const context = await exec(`kubectl port-forward ${pod} ${localPort}:${originPort}`);
        await RunShellCommand.spawnAsPromise("kubectl", [
            "logs",
            '-l',
            label,
            '--tail',
            '' + tail
        ], '', true);
    }

    static async enableNginxEKS(unapply = false): Promise<void> {
        const NGINX_VERSION = '0.35.0';
        console.log("Current ingress nginx version:", NGINX_VERSION);
        await RunShellCommand.asPromise("kubectl", [
            unapply ? "delete" : "apply",
            "-f",
            `https://raw.githubusercontent.com/kubernetes/ingress-nginx/controller-v${NGINX_VERSION}/deploy/static/provider/aws/deploy.yaml`
        ]);
    }

    static async enableNginxDockerDesktop(): Promise<void> {
        const NGINX_VERSION = '0.41.2';
        console.log("Current ingress nginx version:", NGINX_VERSION);
        await RunShellCommand.asPromise("kubectl", [
            "apply",
            "-f",
            `https://raw.githubusercontent.com/kubernetes/ingress-nginx/controller-v0.41.2/deploy/static/provider/cloud/deploy.yaml`
        ]);
    }

    static async enableNginxDockerDesktopKind(): Promise<void> {
        await RunShellCommand.asPromise("kubectl", [
            "apply",
            "-f",
            `https://raw.githubusercontent.com/kubernetes/ingress-nginx/master/deploy/static/provider/kind/deploy.yaml`
        ]);
    }

    static async createElasticSecrets() {
        await RunShellCommand.spawnAsPromise('kubectl', [
            'create',
            'secret',
            'generic',
            'elastic-credentials',
            '--from-literal=password=hamorim52',
            '--from-literal=username=elastic'
        ])

        let chartsPath = process.cwd() + '/chart/';


        await RunShellCommand.spawnAsPromise('kubectl', [
            'create',
            'secret',
            'generic',
            'elastic-certificates',
            `--from-file=elastic-certificates.p12=${chartsPath.concat('certs/elastic-certificates.p12')}`
        ])

        await RunShellCommand.spawnAsPromise('kubectl', [
            'create',
            'secret',
            'generic',
            'elastic-certificates-pem',
            `--from-file=elastic-certificates.pem=${chartsPath.concat('certs/elastic-certificates.pem')}`
        ])
        await RunShellCommand.spawnAsPromise('kubectl', [
            'create',
            'secret',
            'generic',
            'kibana',
            '--from-literal=encryptionkey="something_at_least_32_characters"'
        ])

    }

    static async helmUpdateDependencies(): Promise<void> {
        await RunShellCommand.asPromise("helm", [
            "dependency",
            "update",
            "chart/"
        ])
    }

    static async helmUpgradeInstall(releaseName: string, imageTag: string, type: ScoeDeploymentType): Promise<void> {
        let args = [
            "upgrade",
            "-i",
            releaseName,
            "chart/",
            "--values",
            "chart/values.yaml",
            "--set",
            "image.tag=" + imageTag,
            "--set",
            "mongodb.persistence.size=4Gi",
            "--set",
            "rabbitmq.persistence.size=4Gi"
        ];
        if (type === ScoeDeploymentType.LOCAL) {
            args = args.concat([
                "--set",
                "image.pullPolicy=Never",
                "--set",
                "isLocalHostEnv=true",
            ])
        }
        await RunShellCommand.asPromise("helm", args);
    }

    static async helmUninstall(releaseName: string): Promise<void> {
        await RunShellCommand.asPromise("helm uninstall " + releaseName, []);
    }

    static async installArgo() {
        await RunShellCommand.asPromise("kubectl", ["create", "ns", "argo"]);
        await RunShellCommand.asPromise("kubectl", ["apply", "-n", "argo", "-f", "https://raw.githubusercontent.com/argoproj/argo-workflows/master/manifests/quick-start-postgres.yaml"]);
    }
}
