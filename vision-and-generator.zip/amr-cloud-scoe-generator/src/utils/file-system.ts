import * as fs from "fs";
import * as fse from "fs-extra";
import * as https from "https";
import * as http from "http";
import extract from "extract-zip";
import * as util from "util";
import {CopyFilterSync} from "fs-extra";
import path from "path";

export class FileSystem {
    static downloadFile(url: string, dest: string): Promise<null> {
        return new Promise<null>((resolve, reject) => {
            const file = fs.createWriteStream(dest);
            https.get(url, function (response) {
                response.pipe(file);
                file.on('finish', function () {
                    file.close();
                    resolve(null);
                });
            }).on('error', function (err) { // Handle errors
                fs.unlink(dest, () => {
                    reject(err);
                });
            });
        });
    }

    static getUrl(url: string): Promise<string> {
        return new Promise<string>((resolve, reject) => {
            http.get({
                host: "proxy-us.intel.com",
                port: 912,
                path: url,
            }, function (res) {
                res.setEncoding('utf8');
                res.on('data', function (body) {
                    resolve(body);
                });
            }).on('error', function (err) { // Handle errors
                console.log("Error in get", err);
                reject();
            });
        });
    }

    static async unzip(zip: string, dest: string) {
        try {
            await extract(zip, {dir: dest})
        } catch (err) {
            console.log("Error unzip", err);
            throw Error("Error zipping");
        }
    }

    static getResourcesPath(): string {
        return __dirname + "/../resources/";
    }

    static rename(src: string, dest: string): Promise<void> {
        const rename = util.promisify(fs.rename);
        return rename(src, dest);
    }

    static copyFolder(src: string, dest: string, filter?: CopyFilterSync): Promise<void> {
        return fse.copy(src, dest, {filter});
    }

    static writeJsonFile(path: string, json: any) {
        const write = util.promisify(fs.writeFile);
        const readableJson = JSON.stringify(json, null, 2);
        return write(path, readableJson);
    }

    static async readJsonFile(path: string) {
        const read = util.promisify(fs.readFile);
        try {
            const content = await read(path, {encoding: 'utf-8'});
            return JSON.parse(content);
        } catch (e) {
            return null;
        }
    }

    static async readFile(path: string) {
        return util.promisify(fs.readFile)(path, {encoding: 'utf-8'});
    }

    static async writeFile(path: string, data: string): Promise<void> {
        return util.promisify(fs.writeFile)(path, data);
    }

    static async createFolder(dest: string): Promise<void> {
        return util.promisify(fs.mkdir)(dest);
    }

    static async copyFile(src: string, dest: string): Promise<void> {
        // return util.promisify(fs.copyFile)(src, dest);
        console.log(src, dest);
        return fs.copyFileSync(src, dest);
    }

    static async deleteFile(file: string): Promise<void> {
        return util.promisify(fs.unlink)(file);
    }

    static async replaceInFile(path: string, search: string, replace: string, regex = true): Promise<void> {
        const read = util.promisify(fs.readFile);
        const write = util.promisify(fs.writeFile);
        const content = await read(path, {encoding: 'utf-8'});
        const toSearch = regex ? new RegExp(search, 'g') : search;
        const newContent = content.replace(toSearch, replace);
        return await write(path, newContent);
    }

    static async prependFile(path: string, text: string): Promise<void> {
        const read = util.promisify(fs.readFile);
        const write = util.promisify(fs.writeFile);
        const content = await read(path, {encoding: 'utf-8'});
        return await write(path, text + '\n' + content);
    }

    static async appendFile(path: string, text: string): Promise<void> {
        const read = util.promisify(fs.readFile);
        const write = util.promisify(fs.writeFile);
        let content = '';
        try {
            content = await read(path, {encoding: 'utf-8'});
        } catch (e) {
            console.log("Writing file", path);
        }
        return await write(path, content + '\n' + text);
    }

    static async injectLinesIntoFile(file: string, previousLine: string, newLines: string) {
        return await this.replaceInFile(file, previousLine, previousLine + `${newLines}`, false);
    }

    static async readPropertiesFile(path: string) {
        const contents = await this.readFile(path);
        const properties: { [key: string]: string } = {};
        const lines = contents.split(/\r?\n/);
        for (const line of lines) {
            if (line.indexOf('=') === -1) continue;
            const keyval = line.split('=');
            properties[keyval[0].trim()] = keyval[1].trim();
        }
        return properties;
    }

    static isFileExist(path: string): boolean {
        try {
            if (fs.existsSync(path)) {
                return true;
            }
        } catch (err) {
            console.error(err)
        }
        return false;
    }


    static getAllFiles(dirPath: string, arrayOfFiles: string[], recursive = true) {
        const files = fs.readdirSync(dirPath)
        if (recursive) {
            files.forEach(function (file) {
                if (fs.statSync(dirPath + "/" + file).isDirectory()) {
                    arrayOfFiles = FileSystem.getAllFiles(dirPath + "/" + file, arrayOfFiles)
                } else {
                    arrayOfFiles.push(path.join(dirPath, file))
                }
            })
        } else {
            return files;
        }

        return arrayOfFiles
    }

    static getFolderSize(directoryPath: string) {
        //returns folder size in bytes.../(1024*1024) to convert to mb
        const arrayOfFiles = FileSystem.getAllFiles(directoryPath, [])

        let totalSize = 0
        arrayOfFiles.forEach((filePath, filesArr) => {
            totalSize += fs.statSync(filePath).size
        })

        return totalSize
    }

    static async deleteFolder(dirPath: string) {
            const doesFolderExists = fs.existsSync(dirPath);
            console.log(`does file exists _${doesFolderExists}`)
            if (doesFolderExists) {
                fs.rmSync(dirPath,{recursive:true,force:true})
            }
            return;
      

    }
}
