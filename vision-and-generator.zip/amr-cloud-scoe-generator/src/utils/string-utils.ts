import pluralize from "pluralize";
interface  RegexExtraction{
 regex:RegExp | number;
 startIndex:number;
 endIndex:number;
 length:number;
}
export class StringUtils {
    static capitalize(s: string) {
        return s.charAt(0).toUpperCase() + s.slice(1);
    }

    static pluralize(s: string) {
        return pluralize(s);
    }

    static singular(s: string) {
        return pluralize.singular(s);
    }
    static   extractTemplateFromFile(baseData:string,stringToExtract:string):RegexExtraction{
        try {
            const file = baseData;
            const template = stringToExtract.trim().replace('[', '[[]').replace(/\s+/g, '@@@');
            const regexTemplate = template.split("@@@").join('[\\s\\n\\r]{0,40}');
            const templated = new RegExp(regexTemplate);
            const startIndex = file.search(regexTemplate);
            const matched = file.match(regexTemplate) || "";
            const endIndex = startIndex + (matched.toString().length??0);
            console.log({regex: templated, startIndex: startIndex, endIndex: endIndex, length: endIndex - startIndex})
            return {regex: templated, startIndex: startIndex, endIndex: endIndex, length: endIndex - startIndex};
        }catch (e){
            console.log(e);
            return {regex:-1,startIndex:-1,endIndex:-1,length:-1};
        }
    }
}
