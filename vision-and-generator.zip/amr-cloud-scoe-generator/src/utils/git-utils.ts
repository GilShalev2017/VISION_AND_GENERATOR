import {RunShellCommand} from "./run-shell-command";


export class GitUtils {
    constructor(public projectName: string,public gitToken:string) {}

   async gitInit(){
        if (!this.gitToken || !this.projectName){
            console.log(`Something went wrong!\nProject: ${this.projectName} Token: ${this.gitToken} `)
            return;
        }
        try {
            await RunShellCommand.asPromise("git", ['init']);
        }catch(e){
            console.log(e);
            return;
        }

   }
    async commit(commitMessage:string){
        
        try {
          
            await RunShellCommand.asPromise("git", ['commit', '-m', commitMessage]);
        }catch(e)
        {
        console.log(e);
        return;
        }
    }
    
    async push(){
        
        try {
            await RunShellCommand.asPromise("git", ['push']);
        }catch(e)
        {
            console.log(e);
            return;
        }
    }
 
}
