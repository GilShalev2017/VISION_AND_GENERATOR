import util from "util";
import child_process, {spawn} from "child_process";
import {RunShellCommand} from "./run-shell-command";
import {AwsUtils} from "./aws-utils";
import {KubectlUtils} from "./kubectl-utils";
import * as cluster from "cluster";

const exec = util.promisify(child_process.exec);


export class EksctlUtils {
    static async checkVersion() {
        return await exec('eksctl version');
    }

    static async deleteCluster(name: string) {
        return RunShellCommand.spawnAsPromise("eksctl", [
            "delete",
            "cluster",
            "--name",
            name
        ]);
    }

    static async createCluster(name: string, nodes: string, options: { [key: string]: string }): Promise<void> {
        console.log(options)
        return new Promise<void>((resolve, reject) => {
            let args = [
                'create',
                'cluster',
                '--name',
                name,
                '--managed',
                '--nodes',
                nodes
            ];
            for (let key in options) {
                if (key === key.toLowerCase()) {
                    args.push("--" + key);
                    args.push(options[key]);
                }
            }
            console.log("Running: eksctl", args.join(' '));
            const child = spawn('eksctl', args);

            child.stdout.setEncoding('utf8').on('data', (chunk) => {
                console.log("[eksctl]", chunk);
            });
            child.stderr.setEncoding('utf8').on('data', (chunk) => {
                console.log("[eksctl error]", chunk);
            });

            child.on('close', (code) => {
                // @ts-ignore
                if (code > 0) {
                    console.log(`child process exited with code ${code}`);
                    reject();
                } else {
                    resolve();
                }
            });
        });
    }

    static async installEfs(appName: string, cluster_name: string) {
        try {
            console.log("here process.cwd(():")
            console.log(process.cwd())
            const now = new Date().valueOf();
            const region = await AwsUtils.getCurrentRegion()
            await RunShellCommand.asPromise("aws", ["eks", `--region ${region}`, "update-kubeconfig", `--name ${cluster_name}`])
            const accountID = await AwsUtils.getAccountNumber();
            const clusterInfo = await AwsUtils.getClusterInfo(cluster_name)
            const {vpcId} = clusterInfo.cluster.resourcesVpcConfig
            await RunShellCommand.asPromise("eksctl", ["utils", "associate-iam-oidc-provider", `--region=${region}`, "--cluster=test-test", "--approve"])
            await RunShellCommand.asPromise("curl", ["-o", `${process.cwd()}/cloudformation/iam-policy-example.json`, "https://raw.githubusercontent.com/kubernetes-sigs/aws-efs-csi-driver/v1.3.2/docs/iam-policy-example.json"])
            await AwsUtils.createIamPolicy(`${cluster_name}_AmazonEKS_EFS_CSI_Driver_Policy_${now}`, `${process.cwd()}/cloudformation/iam-policy-example.json`)
            await RunShellCommand.asPromise(`eksctl create iamserviceaccount `, ["--name efs-csi-controller-sa",
                "--namespace kube-system",
                `--cluster ${cluster_name}`,
                `--attach-policy-arn arn:aws:iam::${accountID}:policy/${cluster_name}_AmazonEKS_EFS_CSI_Driver_Policy_${now}`,
                "--approve",
                "--override-existing-serviceaccounts",
                `--region ${region}`]);

            await RunShellCommand.asPromise("rm", [`${process.cwd()}/cloudformation/iam-policy-example.json`])
            const cidr = await RunShellCommand.asPromise("aws", ["ec2 describe-vpcs",
                `--vpc-ids ${vpcId}`,
                '--query "Vpcs[].CidrBlock"',
                "--output text"])

            const newRules = {
                groupName: `${appName}_security_group_${new Date().valueOf()}`,
                vpc_id: vpcId,
                output: "text",
                description: `${appName}_efs_security_group`,
                rules: [{port: "2049", protocol: "tcp"}]
            }


            const newSecurityGroupID = await AwsUtils.createSecurityGroup(cidr, vpcId, newRules)

            const fileSystemID = await RunShellCommand.asPromise("aws efs create-file-system", [`--region ${region}`, "--performance-mode", "generalPurpose", "--query", 'FileSystemId', "--output text"])
            await RunShellCommand.asPromise("kubectl", ['get', 'nodes'])
            const subNetTable = await RunShellCommand.asPromise("aws ec2 describe-subnets", ["--filters", `"Name=vpc-id,Values=${vpcId}"`, `--query "Subnets[*].{SubnetId: SubnetId,AvailabilityZone: AvailabilityZone,CidrBlock: CidrBlock}"`, "--output table"])
            const subNetsList = subNetTable.toString().match(/subnet-[0-9a-zA-Z]{17}/g);

            for (const sub of subNetsList || []) {
                await RunShellCommand.asPromise("aws efs create-mount-target", [`--file-system-id ${fileSystemID.toString().trim()}`, "--subnet-id", `${sub.toString().trim()}`, `--security-groups ${newSecurityGroupID}`])
            }
            console.log("EFS stage has been completed.")
        } catch (e) {
            console.log("EFS volume stage has failed with the followinf error:\m")
            console.log(e);
        }
    }
}
