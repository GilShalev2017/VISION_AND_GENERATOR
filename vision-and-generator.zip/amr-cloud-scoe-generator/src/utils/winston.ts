const appRoot = require('app-root-path');
const winston = require('winston');

const { format, transports } = require('winston');

//
// Logging levels
//
const config = {
    levels: {
        error: 0,
        debug: 1,
        warn: 2,
        data: 3,
        info: 4,
        verbose: 5,
        silly: 6,
        custom: 7
    },
    colors: {
        error: 'red',
        debug: 'green',
        warn: 'yellow',
        data: 'grey',
        info: 'white',
        verbose: 'cyan',
        silly: 'magenta',
        custom: 'green'
    }
};

winston.addColors(config.colors);

// define the custom settings for each transport (file, console)
const options = {
    file: {
        level: 'info',
        filename: `${appRoot}/logs/app.log`,
        handleExceptions: true,
        json: true,
        maxsize: 5242880, // 5MB
        maxFiles: 5,
        colorize: true,
        timestamp: true
    },
    console: {
        level: 'info',
        handleExceptions: true,
        json: false,
        format: winston.format.simple(),
        colorize: true,
        timestamp: true
    },
};

// instantiate a new Winston Logger with the settings defined above
const logger = new winston.createLogger ({
    format: format.combine(
        format.timestamp(),
        format.json()
    ),
    levels: config.levels,
    transports: [
        new winston.transports.File(options.file),
        //new winston.transports.Console(options.console)
        new transports.Console({
            level: 'info',
            timestamp: true,
            format: format.combine(
                format.colorize({ all: true }),
                format.printf(
                    (info :any) => {
                        // return `${info.level}: ${info.message}`;
                        return `${info.message}`;
                    })
            )
        }),
    ],
    exitOnError: false, // do not exit on handled exceptions
});

module.exports = logger;