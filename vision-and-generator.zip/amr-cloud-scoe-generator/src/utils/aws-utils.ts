import util from "util";
import child_process, {spawn} from "child_process";
import {RunShellCommand} from "./run-shell-command";
import {FileSystem} from "./file-system";
import jwkToPem from "jwk-to-pem";
import {SCOE_CONFIG_FILE, ScoeConfig} from "../model/scoe-config";
import {CreateCognitoPool} from "../jobs/create-cognito-pool";

const exec = util.promisify(child_process.exec);

export interface CognitoConfig {
    userPool: string;
    clientId: string;
    clientSecret: string;
}

interface SecurityGroup {
    groupName: string,
    vpc_id: string,
    rules: { protocol: string, port: string }[],
    output?: string,
    description?: string,
}



export class AwsUtils {
    static async checkVersion() {
        return await exec('aws --version');
    }

    static getRegistry() {
        return "435076512082.dkr.ecr.us-west-2.amazonaws.com/mevolve";
    }

    static async getAccountNumber() {
        const accountInfoJson = await RunShellCommand.asPromise("aws sts get-caller-identity", [], process.cwd());
        const accountInfo = JSON.parse(accountInfoJson);
        return accountInfo.Account;
    }

    static async getClusterUrl(clusterName: string) {
        const clusterInfoJson = await RunShellCommand.asPromise("aws eks describe-cluster --name " + clusterName, [], process.cwd());
        const clusterInfo = JSON.parse(clusterInfoJson);
        const clusterVpc = clusterInfo.cluster.resourcesVpcConfig.vpcId;
        const loadBalancerJson = await RunShellCommand.asPromise("aws elbv2 describe-load-balancers", [], process.cwd());
        const loadBalancers = JSON.parse(loadBalancerJson);
        for (const loadBalancer of loadBalancers.LoadBalancers) {
            if (loadBalancer.VpcId === clusterVpc) {
                return loadBalancer.DNSName;
            }
        }
    }

    static async IsClusterExist(clusterName: string) {
        try {
            const clusterInfoJson = await RunShellCommand.asPromise("aws eks describe-cluster --name " + clusterName, [], process.cwd());
            if (clusterInfoJson)
                return true;
        } catch (e) {

        }
        return false;
    }

    static async getClusterInfo(clusterName: string) {
        const clusterInfoJson = await RunShellCommand.asPromise("aws eks describe-cluster --name " + clusterName, [], process.cwd());
        const clusterInfo = JSON.parse(clusterInfoJson);
        return clusterInfo;
    }

    static async getCloudfrontDomainName(distributionId: string) {
        return await RunShellCommand.asPromise(`aws cloudfront get-distribution --id ${distributionId} --query "Distribution.DomainName" --output text`, [], process.cwd())
    }

    static setupCredentialsFromEnvFile(fileContent: { [key: string]: string }) {
        process.env.AWS_ACCESS_KEY_ID = fileContent.AWS_ACCESS_KEY_ID;
        process.env.AWS_SECRET_ACCESS_KEY = fileContent.AWS_SECRET_ACCESS_KEY;
        process.env.AWS_DEFAULT_REGION = fileContent.AWS_REGION;
    }

    static async getCurrentUser() {
        return await RunShellCommand.asPromise("aws iam get-user", [], process.cwd());
    }

    static async getCurrentRegion() {
        if (process.env.AWS_DEFAULT_REGION) {
            return process.env.AWS_DEFAULT_REGION;
        }
        const region = await RunShellCommand.asPromise("aws configure get region", [], process.cwd());
        return region.replace(/[\n\r]/g, '');
    }

    static async deployCloudFormation(stackName: string, cloudformationFile: string, parameters: string[], cwd: string = '') {
        return await RunShellCommand.spawnAsPromise("aws", [
            "cloudformation",
            "deploy",
            "--template-file",
            "cloudformation/" + cloudformationFile,
            "--parameter-overrides",
            parameters.join(' '),
            "--stack-name",
            stackName
        ], process.cwd() + cwd);
    }

    static async deleteCloudFormation(stackName: string) {
        return await RunShellCommand.spawnAsPromise("aws", [
            "cloudformation",
            "delete-stack",
            "--stack-name",
            stackName
        ], process.cwd());
    }

    static async getCloudFormationOutput(stackName: string, key: string) {
        const outputsJson = await RunShellCommand.asPromise("aws", [
            "cloudformation",
            "describe-stacks",
            "--stack-name",
            stackName,
            "--query",
            '"Stacks[0].Outputs"'
        ], process.cwd());
        const outputs = JSON.parse(outputsJson);
        for (const output of outputs) {
            if (output.OutputKey === key) {
                return output.OutputValue;
            }
        }
    }

    static async getCognitoClientSecret(appName: string, envName: string): Promise<CognitoConfig> {
        const config: CognitoConfig = {clientId: "", clientSecret: "", userPool: ""};
        const stackName = appName + '-' + envName + '-cognito';
        await this.deployCloudFormation(stackName, 'cognito.json', ["appName=" + appName + '-' + envName]);
        const outputsJson = await RunShellCommand.asPromise("aws", [
            "cloudformation",
            "describe-stacks",
            "--stack-name",
            stackName,
            "--query",
            '"Stacks[0].Outputs"'
        ], process.cwd());
        const outputs = JSON.parse(outputsJson);
        for (const output of outputs) {
            if (output.OutputKey === 'CognitoClientId') {
                config.clientId = output.OutputValue;
            } else if (output.OutputKey === 'CognitoPoolId') {
                config.userPool = output.OutputValue;
            }
        }
        config.clientSecret = await RunShellCommand.asPromise(`aws cognito-idp describe-user-pool-client --user-pool-id "${config.userPool}"  --client-id "${config.clientId}" --query "UserPoolClient.ClientSecret" --output text`, []);

        const region = await AwsUtils.getCurrentRegion();
        const url = `https://cognito-idp.${region}.amazonaws.com/${config.userPool}/.well-known/jwks.json`;
        console.log("Downloading jwks.json", url);
        const jwk = await FileSystem.getUrl(url);
        console.log("Successfully downloaded", jwk);

        const parsed = JSON.parse(jwk);
        console.log("Creating pem for key ", parsed.keys[0].kid);
        const pem = jwkToPem(parsed.keys[0]);
        await FileSystem.writeFile(`service/config/${envName}.jwt.pem`, pem);

        return config;
    }

    static async createCognitoPool(name: string) {
        const scoeConfig: ScoeConfig = await FileSystem.readJsonFile(SCOE_CONFIG_FILE);
        const createCognitoPool = new CreateCognitoPool(scoeConfig.appName, name);
        await createCognitoPool.run();
    }


    static async emptyS3Bucket(name: string) {
        return RunShellCommand.spawnAsPromise("aws", [
            "s3",
            "rm",
            "s3://" + name,
            "--recursive"
        ]);
    }


    static async createSecurityGroup(cidr_ip: string, vpc_id: string, securityGroup: SecurityGroup): Promise<string> {
        console.log(`cidr_range: ${cidr_ip} , voc_id: ${vpc_id}`)
        try {
            const newSecurityGroupID = await RunShellCommand.asPromise("aws ec2 create-security-group", [`--group-name ${securityGroup.groupName}`, ` --description ${securityGroup.description}`, ` --vpc-id ${vpc_id}`, " --output text "])
            for (const rule of securityGroup.rules) {
                await RunShellCommand.asPromise("aws ec2 authorize-security-group-ingress", [` --group-id ${newSecurityGroupID.toString().trim()}`, `--protocol ${rule.protocol}`, ` --port ${rule.port}`, ` --cidr ${cidr_ip}`])
            }
            return newSecurityGroupID.toString().trim();

        } catch (e) {
            console.log(e);
            return "-1"
        }
    }

    static async createIamPolicy(policyName: string, policyFilePath: string) {
        try {
            console.log("aws".concat(["iam", "create-policy", "--policy-name", `${policyName}`, "--policy-document", 'file://'.concat(policyFilePath)].toString()))
            const newPolicy = await RunShellCommand.asPromise("aws", ["iam", "create-policy", "--policy-name", `${policyName}`, "--policy-document", 'file://'.concat(policyFilePath)])
            return newPolicy ? 1 : -1
        } catch (e) {
            console.log(e)
            return -1;
        }
    }


}
