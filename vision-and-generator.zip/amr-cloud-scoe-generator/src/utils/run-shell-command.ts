import {exec, spawn} from "child_process";
import * as util from "util";
import {debug} from "../index";

export class RunShellCommand {
    static spawnInBackground(command: string, args: string[]) {
        spawn(command, args, {
            detached: true
        });
    }

    static async asPromise(command: string, args: string[], cwd: string = "") {
        const commandStr = command + ' ' + args.join(' ');
        console.log(cwd)
        const {stdout, stderr} = await util.promisify(exec)(commandStr, cwd ? {
            cwd: cwd
        } : {});
        console.log("$ ", commandStr);
        console.log('stdout:', stdout);

        if (stderr) {
            console.error('stderr:', stderr);
        }
        return stdout;
    }

    static async spawnAsPromise(command: string, args: string[], cwd: string = "", output = false): Promise<void> {
        return new Promise<void>(async (resolve, reject) => {
            console.log("$ ", command, args.join(' '));
            const child = spawn(command, args, cwd ? {
                cwd,
                shell: true
            } : {});

            if (output || await debug()) {
                child.stdout.setEncoding('utf8').on('data', (chunk) => {
                    console.log(`[${command}]`, chunk);
                });
            }
            child.stderr.setEncoding('utf8').on('data', (chunk) => {
                console.log(`[${command} error]`, chunk);
            });

            child.on('close', (code) => {
                // @ts-ignore
                if (code > 0) {
                    console.log(`[${command}] child process exited with code ${code}`);
                    reject();
                } else {
                    resolve();
                }
            });
        });

    }

    static buildCurlRequest(url: string, method: string, headers: string[], body?: { [key: string]: string }): string {

        const curledHeaders = headers.map(cH => `-H ${cH}`).concat([`-H "Content-Type: application/json"`]).join(' ').toString().trim()
        const curledBody = body ? Object.keys(body).filter(cK => body[cK] !== undefined).map(cK => `\\"${cK}\\":\\"${body[cK]}\\"`) : [];
        const curlCommand = `curl -X ${method} ${url} ${curledHeaders} `;
        return curledBody?.length ? curlCommand + ` -d "{${curledBody}}"` : curlCommand

    }
}
