# SCOE-CLI

A CLI to generate and configure SCOE full-stack projects. 


## Install

Setup registry:

`echo @scoe:registry=https://gitlab.devtools.intel.com/api/v4/packages/npm/ >> .npmrc`

Install:

`npm i @scoe/scoe-cli -g`

Check that installation works:

`scoe --version`


## Usage

Create a new project:

`scoe create <<project-name>>`

Create a new local environment:

`cd <<project-name>>`

`scoe env add --name <<deployment-name>>`

Run the local environment:

`scoe deploy <<env-name>> --ngServe`   
(to deploy only the backend remove `--ngServe`)


Add a new entity:

`scoe entity <<entity-name>>`

Add a new kubernetes micro-service:

`scoe services add --name <<service-name>>`


Add a new admin user:

`scoe users add --name a@a.com --password A123456789`


Expose cluster db to local machine (port forward):

`scoe db`


### Note

Currently, local environments require having docker desktop installed, with Kubernetes enabled, and helm installed. EKS deployments require having also eksctl and AWS-cli installed and configured.
