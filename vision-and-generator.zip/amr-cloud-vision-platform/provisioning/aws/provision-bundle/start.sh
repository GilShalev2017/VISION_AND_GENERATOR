#!/bin/bash
display_usage() {

        echo -e "\nUsage: $0 <email> <password> <deviceId> \n"
        echo "Vision Platform AWS IoT Installer installs dependencies, configures and installs AWS IoT core according to given inputs"
        }

# if less than three arguments supplied, display usage
        if [  $# -le 2 ]
        then
                display_usage
                exit 1
        fi

# check whether user had supplied -h or --help . If yes display usage
        if [[ ( $# == "--help") ||  $# == "-h" ]]
        then
                display_usage
                exit 0
        fi

export EMAIL=$1
export PASSWORD=$2
export DEVID=$3

echo "==> Installing Docker"
apt-get remove docker docker-engine docker.io containerd runc
apt-get update
apt-get install -y \
    apt-transport-https \
    ca-certificates \
    curl \
    gnupg \
    lsb-release
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
echo \
  "deb [arch=amd64 signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu \
  $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
apt-get update -y
apt-get install -y docker-ce docker-ce-cli containerd.io

echo "==> Install node.js"
curl -fsSL https://deb.nodesource.com/setup_14.x | sudo -E bash -
sudo apt-get install -y nodejs
npm install

echo "==> Install python"
sudo apt-get install -y pip
sudo apt-get install -y python3

echo "==> Installing Unzip & Java"
apt install -y unzip
apt install -y openjdk-16-jre-headless

echo "==> Starting enrollment process"
node device_enroll $EMAIL $PASSWORD $DEVID
