#!/bin/bash

display_usage() {

	echo -e "\nUsage: $0 certificate key thingName endpoint \n"
	echo "Vision Platform AWS IoT Installer uses your given endpoint to request temporary"
	echo "credentials, installs the AWS IoT Core software and provisions the device"

	}

# if less than two arguments supplied, display usage
	if [  $# -le 3 ]
	then
		display_usage
		exit 1
	fi

# check whether user had supplied -h or --help . If yes display usage
	if [[ ( $# == "--help") ||  $# == "-h" ]]
	then
		display_usage
		exit 0
	fi

## display usage if the script is not run as root user
#	if [[ "$EUID" -ne 0 ]]; then
#		echo "This script must be running with root privileges."
#		exit 1
#	fi

# Install jq if it is not installed already
if [ $(dpkg-query -W -f='${Status}' jq 2>/dev/null | grep -c "ok installed") -eq 0 ];
then
  apt-get install jq;
fi

export CERT=$1
export KEY=$2
export NAME=$3
export ENDPOINT=$4
export HEADER="x-amzn-iot-thingname: $3"
echo $HEADER
curl -s --cert $1 --key $2 -H "x-amzn-iot-thingname: $NAME"  "https://$ENDPOINT/role-aliases/VisionPlatformProvisionRoleAlias/credentials" > creds.json
export AWS_ACCESS_KEY_ID=$(cat creds.json | jq -r '.credentials' | jq -r '.accessKeyId')
export AWS_SECRET_ACCESS_KEY=$(cat creds.json | jq -r '.credentials' | jq -r '.secretAccessKey')
export AWS_SESSION_TOKEN=$(cat creds.json | jq -r '.credentials' | jq -r '.sessionToken')

sudo -E java -Droot="/greengrass/v2" -Dlog.store=FILE \
  -jar ./MyGreengrassCore/lib/Greengrass.jar \
  --aws-region us-east-1 \
  --thing-name roy-aws \
  --thing-group-name group-test-1 \
  --tes-role-name GreengrassV2TokenExchangeRole \
  --tes-role-alias-name GreengrassCoreTokenExchangeRoleAlias \
  --component-default-user ggc_user:ggc_group \
  --provision true \
  --setup-system-service true \
--deploy-dev-tools true
