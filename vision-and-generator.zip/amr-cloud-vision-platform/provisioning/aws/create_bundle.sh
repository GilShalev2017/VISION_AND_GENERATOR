#!/bin/bash

display_usage() {

	echo -e "\nUsage: $0 deviceId \n"
	echo "Vision Platform test bundle generator, bundle will be compressed and should be extracted on target machine"

	}

# if less than two arguments supplied, display usage
	if [  $# -le 0 ]
	then
		display_usage
		exit 1
	fi

# check whether user had supplied -h or --help . If yes display usage
	if [[ ( $# == "--help") ||  $# == "-h" ]]
	then
		display_usage
		exit 0
	fi


export DEV=$1
#export BUNDLES_URL="dn62sfq0w0t3e.cloudfront.net"
export BUNDLES_URL="d2i9lp71nvpny1.cloudfront.net"

echo "==> Vision Platform provisioning bundle generator"
echo "- Starting device provisioning bundle process for $DEV..."

echo "- Generating device certificates..."
./device_cert_generator/devCertGenerator.sh $DEV
echo "- Creating base directory..."
cp -rf provision-bundle provision-$DEV
echo "- Copying device certificates..."
#rm -rf provision-$DEV/certs
#cp -rf device_cert_generator/device_certs/$DEV_NAME/* provision-$DEV/certs
echo "- Creating bundle archive..."
tar -zcvf provision-$DEV.tar.gz provision-$DEV
echo "- Cleaning resources..."
rm -rf provision-$DEV device_cert_generator/device_certs/$DEV_NAME
git co -- device_cert_generator
git clean -xdf device_cert_generator
echo "==> Bundle creation completed"

echo "==> Deploying to S3..."
set -a
source ../../service/config/global.env
aws s3 sync deploy s3://vp-test-bundles-2
mkdir deploy
cp -rf provision-$DEV.tar.gz deploy
aws s3 sync deploy s3://vp-test-bundles-2
rm -rf deploy
echo ""
echo "==> Bundle deployed, use the following commands on your instance to download and extract the bundle:"
echo "$ curl http://$BUNDLES_URL/provision-$DEV.tar.gz -o provision-$DEV.tar.gz"
echo "$ tar -xvf provision-$DEV.tar.gz"
echo ""
echo "==> To enroll the device use the following commands:"
echo "$ cd provision-$DEV"
echo "$ sudo ./start.sh <email> <password> $DEV"
echo ""
