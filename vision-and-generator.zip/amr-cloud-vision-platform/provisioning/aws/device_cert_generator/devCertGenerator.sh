#!/bin/bash

display_usage() {

        echo -e "\nUsage: $0 deviceId \n"
        echo "Vision Platform test certificates generator"

        }

# if less than two arguments supplied, display usage
        if [  $# -le 0 ]
        then
                display_usage
                exit 1
        fi

# check whether user had supplied -h or --help . If yes display usage
        if [[ ( $# == "--help") ||  $# == "-h" ]]
        then
                display_usage
                exit 0
        fi


export DEV_NAME=$1
export CWD="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
echo $CWD

$CWD/gen/certGen.sh create_edge_device_identity_certificate $DEV_NAME
mkdir -p $CWD/device_certs/$DEV_NAME

openssl x509 -req -in $CWD/gen/csr/iot-edge-device-identity-$DEV_NAME.csr.pem -CA $CWD/gen/certs/azure-iot-test-only.root.ca.cert.pem -CAkey $CWD/gen/private/azure-iot-test-only.root.ca.key.pem -CAcreateserial -out $CWD/device_certs/$DEV_NAME/device.crt -days 99999 -sha256 -passin pass:1234

openssl rsa -in $CWD/gen/private/iot-edge-device-identity-$DEV_NAME.key.pem -out $CWD/device_certs/$DEV_NAME/device.key

cp -rf $CWD/gen/certs/azure-iot-test-only.root.ca.cert.pem $CWD/device_certs/$DEV_NAME/rootCA.pem

