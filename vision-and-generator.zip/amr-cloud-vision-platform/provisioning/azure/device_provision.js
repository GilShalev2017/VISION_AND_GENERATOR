'use strict';

var fs = require('fs');
let request = require('request');
const { exec } = require("child_process");

// Local BE credentials
// const url = 'http://localhost:3070';

if (process.argv[2] === '-h' || process.argv[2] === '--help') {
    console.log(`Usage: ${process.argv[0]} [email] [password] [deviceId]`);
    process.exit(1);
}

// Remote BE Credentials
const url = 'http://a3e25ae371754479eae8255868ce0b05-7d5adcec3f2cd793.elb.us-east-1.amazonaws.com/'
const email = process.argv[2] ?  process.argv[2] : 'roy.gilmilel@gmail.com';
// Options
const password = process.argv[3] ? process.argv[3] : 'A123456789';

// Device unique identifier and certificates
var registrationId = process.argv[4] ? process.argv[4] : 'roy-x509';


async function login(email, password) {
    console.log('===> Logging in...');
    let requestUrl = url + '/users/login';
    return new Promise((resolve, reject) => {
        var options = {
            method: 'POST',
            body: {
                email: email,
                password: password
            },
            json: true,
            url: requestUrl
        };
        request(options,
            function (error, response, body) {
                if (error) {
                    console.log(error);
                    reject('===> Login failed:', error);
                }
                resolve(body);
            })
    });
}

async function getUserDetails(token) {
    console.log('===> Getting user details ...');
    let requestUrl = url + '/users/me';
    return new Promise((resolve, reject) => {
        var options = {
            method: 'GET',
            json: true,
            url: requestUrl,
            headers: {
                'Authorization':'Bearer ' + token
            }
        };
        request(options,
            function (error, response, body) {
                if (error) {
                    reject('===> Get user failed: ', error);
                }
                console.log(body);
                resolve(body);
            })
    });
}

async function enrollDevice(deviceId, token) {
    console.log(`===> Enrolling device ${deviceId}...`);
    const certificate = fs.readFileSync("./certificates/device.cert.pem").toString()
    let requestUrl = url + '/devices/enroll';
    return new Promise((resolve, reject) => {
        var options = {
            method: 'POST',
            body: {
                deviceId: deviceId,
                certificate: certificate
            },
            json: true,
            url: requestUrl,
            headers: {
                'Authorization':'Bearer ' + token
            }
        };
        request(options,
            function (error, response, body) {
                if (error) {
                    // reject('===> Enroll device failed: ', error);
                    resolve('===> Enroll failed', error)
                }
                resolve(body);
            })
    });
}

async function start() {
    try {
        const token = (await login(email, password)).token.accessToken;
        console.log(token);

        // Get user details
        const user = await getUserDetails(token);
        console.log(user);
        const idScope = user.cloudProvider.dpsIdScope;
        console.log('===> DPS idScope: ' + idScope);
        const enrollment = await enrollDevice(registrationId, token);
        console.log(enrollment);

        const edgeConfig = fs.readFileSync("/etc/aziot/config.toml").toString()
        fs.writeFile('/etc/aziot/config.toml.cp.' + new Date(), edgeConfig, function (err) {
            if (err) return console.log(err);
            console.log('===> Backed up Azure config');
        });

        const config = `
                        [provisioning]
                        source = "dps"
                        global_endpoint = "https://global.azure-devices-provisioning.net"
                        id_scope = "${idScope}"
                        [provisioning.attestation]
                        method = "x509"
                        registration_id = "${registrationId}"
                        identity_cert = "file:///home/ubuntu/enroll/certificates/device.cert.pem"
                        identity_pk = "file:///home/ubuntu/enroll/certificates/device.key.pem"
                        `
        fs.writeFile('/etc/aziot/config.toml', config, function (err) {
            if (err) return console.log(err);
            console.log('===> Azure Config updated');
        });

        console.log('===> Applying new configuration to edgeClient and provisioning device ...')

        exec("iotedge config apply", (error, stdout, stderr) => {
            if (error) {
                console.log(`error: ${error.message}`);
                return;
            }
            if (stderr) {
                console.log(`stderr: ${stderr}`);
                return;
            }
            console.log(`stdout: ${stdout}`);
            console.log(`===> Device ${registrationId} provisioning finished`)
        });
        // const register = await registerDevice(idScope);

    } catch (e) {
        console.log(e);
    }
}

start();
