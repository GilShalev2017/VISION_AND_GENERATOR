#!/bin/sh

REPOSITORY_URL="739177214603.dkr.ecr.us-east-1.amazonaws.com"
ECR_REPO_NAME="vision-platform-vpdev"
CI_PIPELINE_IID="local_9"
CLUSTER_NAME="vpdev"
AWS_ACCOUNT="739177214603"
AWS_REGION="us-east-1"

#cd service
#sed -i "s/<<version>>/$CI_PIPELINE_IID/g" public/index.html
#docker build --tag $ECR_REPO_NAME:latest -t $REPOSITORY_URL/$ECR_REPO_NAME:services_$CI_PIPELINE_IID .
#cd ..
#sed -i "s/0000/$CI_PIPELINE_IID/g" chart/Chart.yaml
#aws ecr get-login-password --region $AWS_REGION | docker login --username AWS --password-stdin $REPOSITORY_URL
#docker push $REPOSITORY_URL/$ECR_REPO_NAME:services_$CI_PIPELINE_IID
#aws eks --region $AWS_REGION update-kubeconfig --name $CLUSTER_NAME
#kubectl config use-context arn:aws:eks:$AWS_REGION:$AWS_ACCOUNT:cluster/$CLUSTER_NAME
#
#helm dependency update chart/
helm upgrade -i vision-platform chart/ --values chart/values.yaml --set image.tag=$REPOSITORY_URL/$ECR_REPO_NAME:services_$CI_PIPELINE_IID --set kibana.ingress.hosts="{kibana.alephz.com}"



