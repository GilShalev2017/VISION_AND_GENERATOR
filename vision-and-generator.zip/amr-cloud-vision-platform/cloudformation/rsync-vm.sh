
rsync.exe -Pav . administrator@mes-moshe-ubuntu.jer.intel.com:/home/administrator/projects/vision-platform --exclude='/.git' --filter="dir-merge,- .gitignore"
