import {
    Count,
    CountSchema,
    Filter,
    FilterExcludingWhere,
    repository,
    Where,
} from '@loopback/repository';
import {
    post,
    param,
    get,
    getModelSchemaRef,
    patch,
    put,
    del,
    requestBody,
} from '@loopback/rest';
import {Feature, User} from '../../models';
import {FeatureRepository, UserRepository} from '../../repositories';
import {authenticate} from "@loopback/authentication";
import {inject} from "@loopback/core";
import {SecurityBindings} from "@loopback/security";
import {DeviceController} from "./device.controller";
import {FileSystem} from "../../services/file-system";

@authenticate('jwt')
export class FeatureController {
    constructor(
        @repository(FeatureRepository)
        public featureRepository: FeatureRepository,
        @repository(UserRepository) protected userRepository: UserRepository) {

    }

    @post('/features', {
        responses: {
            '200': {
                description: 'Feature model instance',
                content: {'application/json': {schema: getModelSchemaRef(Feature)}},
            },
        },
    })
    async create(@inject(SecurityBindings.USER) currentUserProfile: User,
                 @requestBody({
                     content: {
                         'application/json': {
                             schema: getModelSchemaRef(Feature, {
                                 title: 'NewFeature',
                                 exclude: ['id'],
                             }),
                         },
                     },
                 })
                     feature: Omit<Feature, 'id'>,
    ): Promise<Feature> {
        const createdFeature = await DeviceController.getUserIoTService(currentUserProfile).createComponent(feature);
        return this.featureRepository.create(createdFeature);
    }

    @get('/features/count', {
        responses: {
            '200': {
                description: 'Feature model count',
                content: {'application/json': {schema: CountSchema}},
            },
        },
    })
    async count(
        @param.where(Feature) where?: Where<Feature>,
    ): Promise<number> {
        const {count} = await this.featureRepository.count(where);
        return count;
    }

    @get('/features', {
        responses: {
            '200': {
                description: 'Array of Feature model instances',
                content: {
                    'application/json': {
                        schema: {
                            type: 'array',
                            features: getModelSchemaRef(Feature, {includeRelations: true}),
                        },
                    },
                },
            },
        },
    })
    async find(@inject(SecurityBindings.USER) currentUserProfile: User,
               @param.filter(Feature) filter?: Filter<Feature>,
    ): Promise<Feature[]> {
        return this.featureRepository.find(filter);
        //return DeviceController.getUserIoTService(currentUserProfile).getComponents();
    }

    @patch('/features', {
        responses: {
            '200': {
                description: 'Feature PATCH success count',
                content: {'application/json': {schema: CountSchema}},
            },
        },
    })
    async updateAll(
        @requestBody({
            content: {
                'application/json': {
                    schema: getModelSchemaRef(Feature, {partial: true}),
                },
            },
        })
            feature: Feature,
        @param.where(Feature) where?: Where<Feature>,
    ): Promise<Count> {
        return this.featureRepository.updateAll(feature, where);
    }

    @get('/features/{id}', {
        responses: {
            '200': {
                description: 'Feature model instance',
                content: {
                    'application/json': {
                        schema: getModelSchemaRef(Feature, {includeRelations: true}),
                    },
                },
            },
        },
    })
    async findById(
        @param.path.string('id') id: string,
        @param.filter(Feature, {exclude: 'where'}) filter?: FilterExcludingWhere<Feature>
    ): Promise<Feature> {
        return this.featureRepository.findById(id, filter);
    }

    @patch('/features/{id}', {
        responses: {
            '204': {
                description: 'Feature PATCH success',
            },
        },
    })
    async updateById(
        @param.path.string('id') id: string,
        @requestBody({
            content: {
                'application/json': {
                    schema: getModelSchemaRef(Feature, {partial: true}),
                },
            },
        })
            feature: Feature,
    ): Promise<void> {
        await this.featureRepository.updateById(id, feature);
    }

    @put('/features/{id}', {
        responses: {
            '204': {
                description: 'Feature PUT success',
            },
        },
    })
    async replaceById(
        @inject(SecurityBindings.USER) currentUserProfile: User,
        @param.path.string('id') id: string,
        @requestBody() feature: Feature,
    ): Promise<void> {
        await this.featureRepository.replaceById(id, feature);
        await DeviceController.getUserIoTService(currentUserProfile).createComponent(feature);
    }

    @del('/features/{id}', {
        responses: {
            '204': {
                description: 'Feature DELETE success',
            },
        },
    })
    async deleteById(@inject(SecurityBindings.USER) currentUserProfile: User,
                     @param.path.string('id') id: string): Promise<void> {
        const featureId = id.split('_image_id')[0].split('feature_id:')[1];//`feature_id:${entity.id}_image_id:${entity.picture}`;
        const imageId = id.split('_image_id:')[1].split('_component_arn:')[0];
        const componentArn = id.split('_component_arn:')[1];

        await FileSystem.removeFileFromS3(imageId);
        await this.featureRepository.deleteById(featureId);
        DeviceController.getUserIoTService(currentUserProfile).deleteComponent(componentArn);
    }
}
