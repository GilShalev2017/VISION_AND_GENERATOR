import {Filter, repository,} from '@loopback/repository';
import {del, get, getModelSchemaRef, HttpErrors, param, patch, post, put, requestBody,} from '@loopback/rest';
import {Chart, User} from '../../models';
import {ChartRepositoryRepository, UserRepository} from '../../repositories';
import {inject} from "@loopback/core";
import {SecurityBindings} from "@loopback/security";
import {authenticate} from "@loopback/authentication";


@authenticate('jwt')
export class ChartsController {
    constructor(
        @repository(UserRepository) protected userRepository: UserRepository,
        @repository(ChartRepositoryRepository) private chartRepository: ChartRepositoryRepository
    ) {
    }

    @post('/chart', {
        summary: 'Add new chart',
        responses: {
            '200': {
                description: 'Add new chart',
                content: {
                    'application/json': {
                        schema: {properties: {chartId: {type: 'string'}}}
                    },
                },
            },
        },
    })
    async createNewChart(
        @requestBody({
            content: {'application/json': {schema: getModelSchemaRef(Chart, {exclude: ['userId', 'id']})}},

        })
        @inject(SecurityBindings.USER) currentUserProfile: User,
        newChart: Omit<Chart, 'userId' | 'chartId'>
    ): Promise<{ chartId: string }> {
        try {
            const newChartRes = await this.chartRepository.create({...newChart, userId: currentUserProfile.id});
            return {chartId: newChartRes?.chartId ?? ''};
        } catch (e) {
            console.log(e);
            throw new HttpErrors.InternalServerError(e?.code);
        }
    }


    @put('/chart/{id}', {
        summary: 'Update chart data',
        responses: {
            '200': {
                description: 'Update chart data',
                content: {
                    'application/json': {
                        schema: {
                            type: 'object',
                            properties: {
                                success: {
                                    type: 'boolean',
                                },
                            },
                        },
                    },
                },
            },
        },
    })
    async updateChart(
        @requestBody({
            content: {
                'application/json': {
                    schema: getModelSchemaRef(Chart, {exclude: ['userId', 'id']}),
                },
            },
        })
        @inject(SecurityBindings.USER) currentUserProfile: User,
        newChartData: Chart,
        @param.path.string('id') id: string,
    ): Promise<{ success: boolean }> {
        try {
            await this.chartRepository.updateById(id, newChartData);
            return {success: true};
        } catch (e) {
            console.log(e);
            throw new HttpErrors.InternalServerError(e?.code);
        }
    }

    @get('/chart/user', {
        summary: "Collection of user's charts by user with filter",
        responses: {
            '200': {
                description: "User's charts",
                content: {
                    'application/json': {
                        schema: {type: 'array', items: getModelSchemaRef(Chart, {exclude: ['userId']})},
                    },
                },
            },
        },
    })
    async getUserCharts(
        @inject(SecurityBindings.USER) currentUserProfile: User,
        @param.query.object('filter') filter?: Filter,
    ): Promise<Omit<Chart[], 'userId'>> {
        try {
            if (filter?.where) {
                filter.where = {...filter.where, userId: currentUserProfile.id};
            }
            return await this.chartRepository.find(filter);
        } catch (e) {
            console.log(e);
            throw new HttpErrors.InternalServerError(e?.code);
        }
    }


    @get('/chart/{id}', {
        summary: "Get Chart by chart id",
        responses: {
            '200': {
                description: "Chart id",
                content: {'application/json': {schema: getModelSchemaRef(Chart, {exclude: ['userId', 'id']})}},

            }
        },
    })
    async findChartById(
        @inject(SecurityBindings.USER) currentUserProfile: User,
        @param.path.string('id') id: string
    ): Promise<Chart> {
        try {
            return await this.chartRepository.findById(id);

        } catch (e) {
            console.log(e);
            throw new HttpErrors.InternalServerError(e?.code);

        }
    }


    @del('/chart/{id}', {
        summary: "Remove chart by chart id",
        responses: {
            '200': {
                description: 'Remove chart by id',
                content: {
                    'application/json': {
                        schema: {
                            type: 'object',
                            properties: {
                                success: {
                                    type: 'boolean',
                                },
                            },
                        },
                    },
                },
            },
        },
    })
    async removeChart(
        @param.path.string('id') id: string,
        @inject(SecurityBindings.USER) currentUserProfile: User,
    ): Promise<{ success: boolean }> {
        try {
            await this.chartRepository.deleteById(id);
            return {success: true}
        } catch (e) {
            console.log(e);
            throw new HttpErrors.InternalServerError(e?.code);

        }
    };


}