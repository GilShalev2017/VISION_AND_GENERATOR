import {Entity, model, property} from '@loopback/repository';

@model()
export class Chart extends Entity {

    @property({
        type: 'string',
        id: true,
        generated: false,
        defaultFn: 'uuidv4',
    })
    chartId: string;


    @property({
        type: 'string',
        required: true,
    })
    userId: string;


    @property({
        type: 'string',
        required: true,
    })
    chartDescription: string;

    @property({
        type: 'number',
        required: true,
    })
    colorPallete: number;

    @property({
        type: 'array',
        itemType: 'string',
        required: true,
    })
    dataFields: string[];

    @property({
        type: 'string',
        required: true,
    })
    module: string;

    @property({
        type: 'string',
        required: false,
    })
    xAxis: string;



    // Define well-known properties here

    // Indexer property to allow additional data
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    [prop: string]: any;

    constructor(data?: Partial<Chart>) {
        super(data);
    }
}

export interface ChartsRelations {
    // describe navigational properties here
}

export type ChartsWithRelations = Chart & ChartsRelations;
