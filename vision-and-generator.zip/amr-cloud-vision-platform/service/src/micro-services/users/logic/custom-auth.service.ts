import {HttpErrors, Request, Response, RestBindings} from "@loopback/rest";
import {genSalt, hash} from "bcryptjs";
import {NewMevolveUserModel} from "../../../models";
import _ from "lodash";
import {bind, BindingScope, inject, service} from "@loopback/core";
import {
    Credentials,
    MyUserService, RefreshTokenService,
    RefreshTokenServiceBindings, TokenObject,
    TokenServiceBindings,
    UserServiceBindings
} from "@loopback/authentication-jwt";
import {TokenService} from "@loopback/authentication";
import {SecurityBindings, UserProfile} from "@loopback/security";
import {repository} from "@loopback/repository";
import {UserRepository} from "../user.repository";
import {AuthorizationService, AwsUtilsService} from "../../../services";
import {ConfirmationRepository, RequestsRateRepository} from "../../../repositories";
import {AbstractAuthService, PasswordResetRequest, RefreshGrant} from "./abstract-auth.service";

@bind({scope: BindingScope.TRANSIENT})
export class CustomAuthService implements AbstractAuthService{

    constructor(
        @inject(TokenServiceBindings.TOKEN_SERVICE)
        public jwtService: TokenService,
        @inject(UserServiceBindings.USER_SERVICE)
        public userService: MyUserService,
        @inject(SecurityBindings.USER, {optional: true})
        public user: UserProfile,
        @repository(UserRepository) protected userRepository: UserRepository,
        @service(AuthorizationService) public authorizationService: AuthorizationService,
        @repository(ConfirmationRepository) public confirmationRepository: ConfirmationRepository,
        @repository(RequestsRateRepository) public requestRateRepository: RequestsRateRepository,
        @inject(RestBindings.Http.RESPONSE) private response: Response,
        @inject(RestBindings.Http.REQUEST) private request: Request,
        @inject(RefreshTokenServiceBindings.REFRESH_TOKEN_SERVICE) public refreshService: RefreshTokenService,
    ) {}

    refresh(refreshGrant: RefreshGrant): Promise<TokenObject> {
        return this.refreshService.refreshToken(refreshGrant.refreshToken);
    }

    async signUp(newUserRequest: NewMevolveUserModel): Promise<{ identifier: string, token: TokenObject, id: string }> {
        const email = newUserRequest.email?.toLowerCase();
        const {password} = newUserRequest;
        const doesEmailExists = await this.userRepository.find({where: {email: email}})
        if (!doesEmailExists || doesEmailExists.length > 0) {
            throw new HttpErrors.Conflict('Email entered already exists')


        }
        if (!newUserRequest || !password || !this.authorizationService.passwordValidation(password)) {
            throw new HttpErrors.Unauthorized("Password requires at least one upper case letter and min of 8 digits");

        }
        if (!email || !this.authorizationService.emailValidation(email)) {
            throw new HttpErrors.Unauthorized("Email entered is wrong");

        }


        const saltedPassword = await hash(newUserRequest.password, await genSalt());

        const savedUser = await this.userRepository.create(
            _.omit(newUserRequest, 'password', 'password2'),
        );

        await this.userRepository.userCredentials(savedUser.id).create({password: saltedPassword});

        //Generate token for new registered user
        const newUser = await this.userService.verifyCredentials({email, password});
        // convert a User object into a UserProfile object (reduced set of properties)
        const userProfile = this.userService.convertToUserProfile(newUser);
        // create a JSON Web Token based on the user profile
        const token = await this.jwtService.generateToken(userProfile);
        const tokens = await this.refreshService.generateToken(
            userProfile,
            token,
        );
        return {identifier: 'signUp', token: {...tokens}, id: newUser.id};
    }

    async login(credentials: Credentials): Promise<{ identifier: string, token: TokenObject }> {

        const {password, email} = credentials;

        const isTestMode = this.request?.headers?.auth === "testMode";
        if (!isTestMode) {
            await this.authorizationService.validateRequestContent(this.request, email);
        }


        if (!email || !this.authorizationService.emailValidation(email)) {
            throw new HttpErrors.Unauthorized("Email entered is wrong");

        }
        if (!password || !this.authorizationService.passwordValidation(password)) {
            throw new HttpErrors.Unauthorized("Password requires at least one upper case letter and min of 8 digits");

        }


        const user = await this.userService.verifyCredentials(credentials);
        // convert a User object into a UserProfile object (reduced set of properties)
        const userProfile = this.userService.convertToUserProfile(user);

        const mevolveUser = await this.userRepository.findById(user.id);


        // create a JSON Web Token based on the user profile
        const token = await this.jwtService.generateToken(userProfile);
        const tokens = await this.refreshService.generateToken(
            userProfile,
            token,
        );
        if (mevolveUser?.authLevel === "ADMIN" && Boolean(process?.env?.LOCAL) && !process.env.LOCAL) {
            const {id} = mevolveUser;
            const confirmationCode = await this.authorizationService.generateCryptoToken('base64', 15);
            await this.confirmationRepository.create({
                userId: id,
                confirmationCode: confirmationCode,
                token: token,
                expiration: new Date().valueOf() + 30 * 60000
            })

            const confirmationLink = `${process.env.DASHBOARD_URL}adminLogin?cc=${confirmationCode}`;
            await AwsUtilsService.sendEmail(email, "Message from Mevolve", `Hi, \nPlease follow this link in order to reset you password:\n${confirmationLink}`);
            return {
                identifier: 'confirmationCodeRequired',
                token: {accessToken: "-1", refreshToken: "-1"}
            }
        }
        return {identifier: 'login', token: tokens};
    }

    async forgotPassword(email: string): Promise<{ identifier: "passwordReset" }> {
        const user = await this.userRepository.find({where: {email: email}});
        const confirmationCode = await this.authorizationService.generateCryptoToken('base64', 15);

        if (!user || user?.length === 0 || !email) {
            throw new HttpErrors.Conflict('User does not exist')

        }


        const currUser = user[0];
        await this.confirmationRepository.create({
            userId: currUser.id,
            confirmationCode: confirmationCode,
            token: new Date().valueOf().toString(),
            expiration: new Date().valueOf() + 30 * 60000
        })

        const confirmationLink = `${process.env.DASHBOARD_URL}passwordReset?cc=${confirmationCode}`;

        await AwsUtilsService.sendEmail(email, "Message from Mevolve", `Hi, \nPlease follow this link in order to reset you password:\n${confirmationLink}`);
        return {identifier: 'passwordReset'}
    }

    async resetPassword(request: PasswordResetRequest): Promise<{ identifier: "passwordUpdate" }> {

        const isConfirmed = await this.authorizationService.confirmationCodeValidator(request.confirmationCode)
        if (!isConfirmed || isConfirmed?.length === 0) {
            throw new HttpErrors.Unauthorized('Confirmation code is invalid');

        }
        const currUser = isConfirmed[0].userId
        if (currUser) {
            const password = await hash(request.password, await genSalt());

            await this.userRepository.userCredentials(currUser).patch({password});
        }


        return {identifier: 'passwordUpdate'}
    }
}
