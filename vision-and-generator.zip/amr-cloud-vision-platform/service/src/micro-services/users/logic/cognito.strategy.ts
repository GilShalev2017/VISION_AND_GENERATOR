// Copyright IBM Corp. 2019,2020. All Rights Reserved.
// Node module: @loopback/authentication
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT

import {inject, injectable} from '@loopback/core';
import {
    asSpecEnhancer,
    HttpErrors, mergeOpenAPISpec,
    OASEnhancer,
    OpenApiSpec, ReferenceObject,
    Request, SecuritySchemeObject,
} from '@loopback/rest';
import {securityId, UserProfile} from '@loopback/security';
import {asAuthStrategy, AuthenticationStrategy} from "@loopback/authentication";
import * as jwt from 'jsonwebtoken';
import {FileSystem} from "../../../services/file-system";
import {repository} from "@loopback/repository";
import {UserRepository} from "../user.repository";
import apm from "elastic-apm-node";

export type SecuritySchemeObjects = {
    [securityScheme: string]: SecuritySchemeObject | ReferenceObject;
};

export const OPERATION_SECURITY_SPEC = [
    {
        // secure all endpoints with 'jwt'
        jwt: [],
    },
];

export const SECURITY_SCHEME_SPEC: SecuritySchemeObjects = {
    jwt: {
        type: 'http',
        scheme: 'bearer',
        bearerFormat: 'JWT',
    },
};

interface IdToken {
    sub: string;
    email: string;
}

@injectable(asAuthStrategy, asSpecEnhancer)
export class CognitoAuthenticationStrategy implements AuthenticationStrategy, OASEnhancer {
    name = 'jwt';

    constructor(
        @repository(UserRepository) protected userRepository: UserRepository,
    ) {}

    async authenticate(request: Request): Promise<UserProfile | undefined> {
        if (!request.headers.authorization) {
            throw new HttpErrors.Unauthorized(`Authorization header not found.`);
        }

        // for example : Basic Z2l6bW9AZ21haWwuY29tOnBhc3N3b3Jk
        const authHeaderValue = request.headers.authorization;

        if (!authHeaderValue.startsWith('Bearer')) {
            throw new HttpErrors.Unauthorized(`Authorization header is not of type 'Bearer'.`,);
        }
        const authTokenParts = authHeaderValue.split(' ');
        const pemPath = process.cwd() + "/config/" + process.env.AWS_COGNITO_JWT_PEM;

        try {
            const decodedToken = jwt.verify(authTokenParts[1], await FileSystem.getFileAsString(pemPath), {algorithms: ['RS256']}) as IdToken;
            console.log("Decoded token for", decodedToken.email, apm.currentTraceIds.toString());
            const user = await this.userRepository.findById(decodedToken?.sub);
            apm.setUserContext({
                id: user.id,
                email: user.email,
                username: user.email
            })
            return {
                ...user,
                [securityId]: user.id
            };
        } catch (e) {
            console.log("Error decoding token", e);
            throw new HttpErrors.Unauthorized(`Invalid token`);
        }

        return;
    }

    modifySpec(spec: OpenApiSpec): OpenApiSpec {
        const patchSpec = {
            components: {
                securitySchemes: SECURITY_SCHEME_SPEC,
            },
            security: OPERATION_SECURITY_SPEC,
        };
        return mergeOpenAPISpec(spec, patchSpec);
    }
}
