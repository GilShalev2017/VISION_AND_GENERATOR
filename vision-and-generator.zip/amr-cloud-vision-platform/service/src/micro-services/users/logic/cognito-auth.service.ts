import {AuthLevel, NewMevolveUserModel} from "../../../models";
import {bind, BindingScope} from "@loopback/core";
import {Credentials, TokenObject} from "@loopback/authentication-jwt";
import {
    AbstractAuthService,
    ILoginResponseBase,
    LoginResponse,
    PasswordResetRequest,
    RefreshGrant
} from "./abstract-auth.service";
import AWS, {CognitoIdentityServiceProvider} from "aws-sdk";
import proxy from "proxy-agent";
import * as crypto from "crypto";
import {HttpErrors} from "@loopback/rest";
import _ from "lodash";
import {repository} from "@loopback/repository";
import {UserRepository} from "../user.repository";
import {securityId, UserProfile} from "@loopback/security";
import * as jwt from 'jsonwebtoken';

@bind({scope: BindingScope.TRANSIENT})
export class CognitoAuthService implements AbstractAuthService {
    cognito: CognitoIdentityServiceProvider;

    constructor(
        @repository(UserRepository) protected userRepository: UserRepository,
    ) {
        if (process.env.IS_LOCALHOST_ENV?.toString() === "true" || process.env.USE_PROXY) {
            console.log("Using proxy for AWS");
            const httpOptions = {agent: proxy("http://proxy-us.intel.com:911")}
            AWS.config.update({httpOptions});
        }

        this.cognito = new AWS.CognitoIdentityServiceProvider();
    }

    async refresh(refreshGrant: RefreshGrant): Promise<TokenObject> {
        try {
            if (!refreshGrant.oldAccessToken) {
                throw new Error("Access Token is needed");
            }
            const decoded = jwt.decode(refreshGrant.oldAccessToken) as {sub: string};
            const hash = this.getHash(decoded.sub);

            const loginResponse = await this.cognito.adminInitiateAuth({
                UserPoolId: process.env.AWS_COGNITO_USER_POOL,
                ClientId: process.env.AWS_COGNITO_CLIENT_ID,
                AuthFlow: "REFRESH_TOKEN_AUTH",
                AuthParameters: {
                    REFRESH_TOKEN: refreshGrant.refreshToken,
                    SECRET_HASH: hash
                }
            }).promise();

            console.log("loginResponse", loginResponse);
            return {
                    accessToken: loginResponse.AuthenticationResult?.IdToken ?? '',
                    expiresIn: '' + loginResponse.AuthenticationResult?.ExpiresIn,
                    refreshToken: loginResponse.AuthenticationResult?.RefreshToken
            }
        } catch (e) {
            console.log("Error refresh", e);
            // if (e?.code === 'CodeMismatchException') {
            //     throw new HttpErrors.BadRequest("INVALID_VERIFICATION_CODE");
            // }
            throw new Error("Unknown error in refresh");
        }
    }

    getHash(username: string) {
        return crypto.createHmac('SHA256', process.env.AWS_COGNITO_CLIENT_SECRET)
            .update(username + process.env.AWS_COGNITO_CLIENT_ID)
            .digest('base64');
    }

    async signUp(newUserRequest: NewMevolveUserModel): Promise<LoginResponse> {
        try {
            const hash = this.getHash(newUserRequest.email);

            if (newUserRequest.verificationToken) {
                console.log("verifying", newUserRequest.email);
                await this.cognito.confirmSignUp({
                    ClientId: process.env.AWS_COGNITO_CLIENT_ID,
                    Username: newUserRequest.email,
                    ConfirmationCode: newUserRequest.verificationToken,
                    SecretHash: hash
                }).promise();
                return await this.login({
                    email: newUserRequest.email,
                    password: newUserRequest.password
                }, true);
            } else {
                const response = await this.cognito.signUp({
                    ClientId: process.env.AWS_COGNITO_CLIENT_ID,
                    SecretHash: hash,
                    Username: newUserRequest.email,
                    Password: newUserRequest.password
                }).promise();
                console.log("Signed up successfully", response);

                await this.userRepository.create({
                    ..._.omit(newUserRequest, 'password', 'password2'),
                    id: response.UserSub
                });
                return {
                    identifier: "confirmationCodeRequired",
                    token: {
                        accessToken: ''
                    }
                }
            }
        } catch (e) {
            console.log("Error signing up", e);
            if (e?.code === 'UsernameExistsException') {
                throw new HttpErrors.BadRequest("EMAIL_ALREADY_EXISTS");
            }
            throw new HttpErrors.BadRequest(e?.code);
        }
    }

    async login(credentials: Credentials, firstLogin?: boolean): Promise<LoginResponse> {
        try {
            const hash = this.getHash(credentials.email);

            const loginResponse = await this.cognito.adminInitiateAuth({
                UserPoolId: process.env.AWS_COGNITO_USER_POOL,
                ClientId: process.env.AWS_COGNITO_CLIENT_ID,
                AuthFlow: "ADMIN_USER_PASSWORD_AUTH",
                AuthParameters: {
                    USERNAME: credentials.email,
                    PASSWORD: credentials.password,
                    SECRET_HASH: hash
                }
            }).promise();

            const user = await this.userRepository.findOne({where: {email: credentials.email}});

            return {
                token: {
                    accessToken: loginResponse.AuthenticationResult?.IdToken ?? '',
                    expiresIn: '' + loginResponse.AuthenticationResult?.ExpiresIn,
                    refreshToken: loginResponse.AuthenticationResult?.RefreshToken
                },
                identifier: firstLogin ? 'firstLogin' : 'login',
                admin: user?.authLevel === AuthLevel.ADMIN
            }
        } catch (e) {
            console.log("Error signing up", e);
            if (e?.code === 'NotAuthorizedException') {
                throw new HttpErrors.BadRequest("WRONG_USERNAME_PASSWORD");
            }
            throw new Error("Unknown error in signup");
        }
    }

    async forgotPassword(email: string): Promise<ILoginResponseBase> {
        try {
            const hash = this.getHash(email);

            const response = await this.cognito.forgotPassword({
                ClientId: process.env.AWS_COGNITO_CLIENT_ID,
                Username: email,
                SecretHash: hash
            }).promise();

            console.log("response", response);
            return {identifier: "passwordReset"};
        } catch (e) {
            console.log("Error forgot password", e);
            throw new Error("Unknown error in forgot password");
        }
    }

    async resetPassword(request: PasswordResetRequest): Promise<ILoginResponseBase> {
        if (!request.email) {
            throw new HttpErrors.BadRequest("USERNAME_NOT_SUPPLIED");
        }
        try {
            const hash = this.getHash(request.email);

            const response = await this.cognito.confirmForgotPassword({
                ClientId: process.env.AWS_COGNITO_CLIENT_ID,
                Username: request.email,
                ConfirmationCode: request.confirmationCode,
                Password: request.password,
                SecretHash: hash
            }).promise();

            console.log("response", response);
            return {identifier: "passwordUpdate"};
        } catch (e) {
            console.log("Error resetPassword", e);
            if (e?.code === 'CodeMismatchException') {
                throw new HttpErrors.BadRequest("INVALID_VERIFICATION_CODE");
            } else if (e?.code === 'InvalidPasswordException') {
                throw new HttpErrors.BadRequest("INVALID_PASSWORD");
            } else if (e?.code === 'ExpiredCodeException') {
                throw new HttpErrors.BadRequest("VERIFICATION_CODE_EXPIRED");
            }
            throw new Error("Unknown error in resetPassword");
        }
    }
}
