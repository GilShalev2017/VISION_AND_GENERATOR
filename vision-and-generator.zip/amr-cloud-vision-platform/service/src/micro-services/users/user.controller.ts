import {Count, CountSchema, Filter, FilterExcludingWhere, repository, Where,} from '@loopback/repository';
import {del, get, getModelSchemaRef, HttpErrors, param, patch, post, put, requestBody,} from '@loopback/rest';
import {
    NewMevolveUserModel,
    User,
} from '../../models';
import {
    UserRepository
} from '../../repositories';
import {authenticate} from "@loopback/authentication";
import {inject, service} from "@loopback/core";
import {SecurityBindings, securityId, UserProfile} from "@loopback/security";
import {AuthorizationService, RabbitMqService} from "../../services";
import {genSalt, hash} from "bcryptjs";

@authenticate('jwt')
export class UserController {
    constructor(
        @repository(UserRepository) public userRepository: UserRepository,
        @service(AuthorizationService) public authorizationService: AuthorizationService,
        @service(RabbitMqService) public rabbitMqService: RabbitMqService,
    ) {

    }

    @post('/users', {
        responses: {
            '200': {
                description: 'User model instance',
                content: {'application/json': {schema: getModelSchemaRef(User)}},
            },
        },
    })
    async create(
        @requestBody({
            content: {
                'application/json': {
                    schema: getModelSchemaRef(User, {
                        title: 'NewUser',
                        exclude: ['id'],
                    }),
                },
            },
        })
            user: Omit<User, 'id'>,
        @inject(SecurityBindings.USER) currentUserProfile: UserProfile,
    ): Promise<User> {
        await this.authorizationService.guardAdmin(currentUserProfile[securityId]);
        return this.userRepository.create(user);
    }


    @get('/users/count', {
        responses: {
            '200': {
                description: 'User model count',
                content: {'application/json': {schema: CountSchema}},
            },
        },
    })
    async count(
        @param.where(User) where?: Where<User>,
    ): Promise<Count> {

        return this.userRepository.count(where);
    }

    @get('/users', {
        responses: {
            '200': {
                description: 'Array of User model instances',
                content: {
                    'application/json': {
                        schema: {
                            type: 'array',
                            items: getModelSchemaRef(User, {includeRelations: true}),
                        },
                    },
                },
            },
        },
    })
    async find(
        @inject(SecurityBindings.USER) currentUserProfile: UserProfile,
        @param.filter(User) filter?: Filter<User>,
    ): Promise<User[]> {
        await this.authorizationService.guardAdmin(currentUserProfile[securityId]);
        return this.userRepository.find(filter);
    }

    @patch('/users', {
        responses: {
            '200': {
                description: 'User PATCH success count',
                content: {'application/json': {schema: CountSchema}},
            },
        },
    })
    async updateAll(
        @requestBody({
            content: {
                'application/json': {
                    schema: getModelSchemaRef(User, {partial: true}),
                },
            },
        })
            user: User,
        @inject(SecurityBindings.USER) currentUserProfile: UserProfile,
        @param.where(User) where?: Where<User>,
    ): Promise<Count> {
        await this.authorizationService.guardAdmin(currentUserProfile[securityId]);
        return this.userRepository.updateAll(user, where);
    }

    @get('/users/{id}', {
        responses: {
            '200': {
                description: 'User model instance',
                content: {
                    'application/json': {
                        schema: getModelSchemaRef(User, {includeRelations: true}),
                    },
                },
            },
        },
    })
    async findById(
        @param.path.string('id') id: string,
        @inject(SecurityBindings.USER) currentUserProfile: UserProfile,
        @param.filter(User, {exclude: 'where'}) filter?: FilterExcludingWhere<User>
    ): Promise<User> {
        await this.authorizationService.guardAdmin(currentUserProfile[securityId]);
        return this.userRepository.findById(id, filter);
    }

    @patch('/users/{id}', {
        responses: {
            '204': {
                description: 'User PATCH success',
            },
        },
    })
    async updateById(
        @param.path.string('id') id: string,
        @requestBody({
            content: {
                'application/json': {
                    schema: getModelSchemaRef(User, {partial: true}),
                },
            },
        })
            user: NewMevolveUserModel,
        @inject(SecurityBindings.USER) currentUserProfile: UserProfile,
    ): Promise<number> {

        await this.authorizationService.guardAdmin(currentUserProfile[securityId]);
        const {email, password} = user;
        if (password) {
            if (!this.authorizationService.passwordValidation(password)) {
                throw new HttpErrors.Unauthorized("Password requires at least one upper case letter and min of 8 digits");

            }

        }
        if (email) {

            const doesEmailExists = await this.userRepository.find({where: {email: email}});
            if (!doesEmailExists || doesEmailExists.length > 0) {
                throw new HttpErrors.Conflict('Email entered already exists')

            }
        }
        try {
            await this.userRepository.updateById(id, user);

            if (user.password) {
                const saltedPassword = await hash(user.password, await genSalt());
                await this.userRepository.userCredentials(id).patch({password: saltedPassword});
            }
            return 1;
        } catch (e) {
           console.error(e)
            return -1;
        }
    }

    @put('/users/{id}', {
        responses: {
            '204': {
                description: 'User PUT success',
            },
        },
    })
    async replaceById(
        @param.path.string('id') id: string,
        @requestBody() user: User,
        @inject(SecurityBindings.USER) currentUserProfile: UserProfile,
    ): Promise<void> {
        await this.authorizationService.guardAdmin(currentUserProfile[securityId]);
        await this.userRepository.replaceById(id, user);
    }

    @del('/users/{id}', {
        responses: {
            '204': {
                description: 'User DELETE success',
            },
        },
    })
    async deleteById(
        @inject(SecurityBindings.USER) currentUserProfile: UserProfile,
        @param.path.string('id') id: string
    ): Promise<void> {
        await this.authorizationService.guardAdmin(currentUserProfile[securityId]);
        await this.userRepository.deleteById(id);
    }

    @del('/users', {
        responses: {
            '204': {
                description: 'User DELETE success',
            },
        },
    })
    async delete(
        @inject(SecurityBindings.USER) currentUserProfile: UserProfile,
        @param.where(User) where?: Where<User>,
    ): Promise<void> {
        await this.authorizationService.guardAdmin(currentUserProfile[securityId]);
        await this.userRepository.deleteAll(where);
    }
}
