import {bind, /* inject, */ BindingScope, service} from '@loopback/core';
import {Channel, Connection} from "amqplib/callback_api";
import * as amqp from "amqplib/callback_api";
import {QMessage, QMessageJobStart, QMessegeType} from "../models";

@bind({scope: BindingScope.SINGLETON})
export class RabbitMqService {

  queueName: string;
  connection: Connection;
  channel: Channel;


  constructor(
  ) {
    if (!process.env.SERVICE_ID) {
      console.log("Error: undefined process.env.SERVICE_ID");
      return;
    }
    this.queueName = process.env.SERVICE_ID;
    this.connect(8);
  }

  connect(retries: number) {
    amqp.connect(process.env.RABBITMQ, (error0, connection) => {
      if (error0) {
        console.log("Error connecting to Rabbit MQ. retries : ", retries, error0);
        if (retries > 0) {
          setTimeout(() => this.connect(retries - 1), 8000);
        }
        return;
      }
      this.connection = connection;
      connection.createChannel((error1, channel) => {
        if (error1) {
          throw error1;
        }
        this.channel = channel;
        channel.assertQueue(this.queueName, {durable: true});
        channel.assertExchange("service-exchange", 'fanout', {durable: true})
        channel.bindQueue(this.queueName, 'service-exchange', '');

        this.receive();
      });
    });
  }

  receive() {
    console.log("subsribing from service", this.queueName);
    this.channel.consume(this.queueName, (msg) => {
      console.log(" [x] Received %s", msg?.content.toString());
      if (msg) {
        const message: QMessage = JSON.parse(msg.content.toString());
      }
    }, {
      noAck: true
    });
  }

  send(msg: QMessage) {
    this.channel.publish('service-exchange', '', Buffer.from(JSON.stringify(msg)));
    console.log(" [x] Sent ", msg);
  }
}
