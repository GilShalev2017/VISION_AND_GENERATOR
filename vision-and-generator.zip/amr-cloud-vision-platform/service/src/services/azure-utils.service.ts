import * as msRestNodeAuth from "@azure/ms-rest-nodeauth";
import * as msRest from "@azure/ms-rest-js";
import {IotHubClient} from "@azure/arm-iothub";
import {Client, Device, Registry} from "azure-iothub";
import DeviceDescription = Registry.DeviceDescription;
import {Configuration} from "azure-iothub/src/configuration";
import {EventHubConsumerClient} from "@azure/event-hubs";
import {User} from "../micro-services/users/user.model";
import {HttpErrors} from "@loopback/rest";
import {ResourceManagementClient} from "@azure/arm-resources";
import {IotDpsClient, IotDpsResource} from '@azure/arm-deviceprovisioningservices';
import {ProvisioningServiceClient} from 'azure-iot-provisioning-service';
import {IndividualEnrollment} from "azure-iot-provisioning-service/dist/interfaces";
import {AwsIotService} from "../micro-services/iot/logic/aws-iot.service";
import {Deployment} from "../micro-services/iot/logic/abstract-iot.service";

const connectionString = 'HostName=moshe-iot-1.azure-devices.net;SharedAccessKeyName=iothubowner;SharedAccessKey=vsjkQSpAq0HnSEBy9OVzID02A3hlGzuZrKzDIqL8wv0=';
const eventsConnectionString = 'Endpoint=sb://ihsuprodblres073dednamespace.servicebus.windows.net/;SharedAccessKeyName=iothubowner;SharedAccessKey=vsjkQSpAq0HnSEBy9OVzID02A3hlGzuZrKzDIqL8wv0=;EntityPath=iothub-ehub-moshe-iot-9191116-60157c8342';
let allEvents: { [key: string]: string[] } = {};
const subscriber: { [key: string]: EventHubConsumerClient } = {};
const clientId = 'a68a5d2d-8ec4-4f51-916d-2f450a9066d5';
const secret = 'BVivxcvxAkp4U_Od6T~D5Kxk~8HSJYDfQe';
const tenantId = '8843a2cc-b1d7-4508-b28a-9ed607d78985';
const subscriptionId = '36abe371-e683-4a1d-8e4a-c9dd634b1865';

interface DeviceRequest {
    deviceId: string;
    authType?: string;
    autoGenKeys?: boolean;
    primaryKey?: string;
    secondaryKey?: string;
    edgeEnabled?: boolean;
    hubEnabled?: boolean;
}

export class AzureUtilsService {

    static getHubList() {
        msRestNodeAuth.loginWithServicePrincipalSecret(clientId, secret, tenantId).then(async (creds) => {
            const client = new IotHubClient(creds, subscriptionId);
            const hubs = await client.iotHubResource.listBySubscription();
            // const hubs = await client.iotHubResource.listKeys("iot-group", "iot-1617697589456");
            console.log(hubs[0].name, hubs[0].properties?.eventHubEndpoints?.events);
        }).catch((err) => {
            console.log(err);
        });
    }

    static getConnectionString(user: User): string {
        return user?.cloudProvider?.connectionString ?? connectionString;
    }

    static async createDeviceEnrollment(user: User, deviceId: string, certificate: string) {

        console.log('==> Create Individual Device Enrollment')
        console.log('- deviceId: ' + deviceId)
        console.log('- DPS serviceOperationsHostName: ' + user.cloudProvider?.dpsServiceOperationsHostName);
        console.log('- DPS key: ' + user.cloudProvider?.dpsKey);

        const serviceOperationsHostName = user.cloudProvider?.dpsServiceOperationsHostName;
        const key = user.cloudProvider?.dpsKey;

        const dpsConnectionString = `HostName=${serviceOperationsHostName};SharedAccessKeyName=provisioningserviceowner;SharedAccessKey=${key}`;
        const serviceClient = ProvisioningServiceClient.fromConnectionString(dpsConnectionString);

        // @ts-ignore
        const enrollment: IndividualEnrollment = {
            registrationId: deviceId,
            deviceId,
            iotHubHostName: user.cloudProvider?.iotDomainName ?? '',
            provisioningStatus: 'enabled',
            capabilities: {
                iotEdge: true
            },
            attestation: {
                type: 'x509',
                x509: {
                    clientCertificates: {
                        primary: {
                            certificate: certificate
                        }
                    }
                }
            },
            reprovisionPolicy: {
                updateHubAssignment: true,
                migrateDeviceData: true
            }
        }
        try {
            const enrollmentResponse = (await serviceClient.createOrUpdateIndividualEnrollment(enrollment)).responseBody;
            console.log(enrollmentResponse);
            console.log("Enrollment record returned: " + JSON.stringify(enrollmentResponse, null, 2));
            return {azure: enrollmentResponse};
        } catch (e) {
            console.log('Failed to create individual enrollment' + e);
            return e;
        }
    }

    static async deleteDeviceEnrollment(user: User, deviceId: string) {

        console.log('==> Delete Individual Device Enrollment')
        console.log('- deviceId: ' + deviceId)
        console.log('- DPS serviceOperationsHostName: ' + user.cloudProvider?.dpsServiceOperationsHostName);
        console.log('- DPS key: ' + user.cloudProvider?.dpsKey);

        const serviceOperationsHostName = user.cloudProvider?.dpsServiceOperationsHostName;
        const key = user.cloudProvider?.dpsKey;

        const dpsConnectionString = `HostName=${serviceOperationsHostName};SharedAccessKeyName=provisioningserviceowner;SharedAccessKey=${key}`;
        const serviceClient = ProvisioningServiceClient.fromConnectionString(dpsConnectionString);

        // @ts-ignore
        const enrollment: IndividualEnrollment = (await serviceClient.getIndividualEnrollment(deviceId)).responseBody;
        console.log(enrollment);
        console.log('- DPS Enrollment Etag: ' + enrollment.etag);

        try {
            const enrollmentResponse = await serviceClient.deleteIndividualEnrollment(enrollment);
            console.log(enrollmentResponse);
            console.log("Enrollment for " + deviceId + "deleted successfully");

            await this.deleteById(user, deviceId);

            // return `Device ${deviceId} deleted from IoT Hub and DPS`;
        } catch (e) {
            console.log('Failed to delete individual enrollment' + e);
            return Promise.reject(e);
        }
    }

    static async createDevice(user: User, deviceRequest: DeviceRequest, update = false) {
        const registry = Registry.fromConnectionString(this.getConnectionString(user));
        let deviceDescription: DeviceDescription;
        console.log(deviceRequest);
        if (update) {
            const deviceInfo = await registry.get(deviceRequest.deviceId);
            deviceDescription = deviceInfo.responseBody;
        } else {
            deviceDescription = {
                deviceId: deviceRequest.deviceId,
                capabilities: {
                    iotEdge: true
                },
            };
        }

        if (!deviceRequest.autoGenKeys && deviceRequest.primaryKey && deviceRequest.secondaryKey) {
            deviceDescription['authentication'] = {
                symmetricKey: {
                    primaryKey: deviceRequest.primaryKey,
                    secondaryKey: deviceRequest.secondaryKey
                }
            }
        }


        deviceDescription['status'] = deviceRequest.hubEnabled ? "enabled" : "disabled";

        console.log('====>' + update ? 'Updating...' : 'Creating...');
        console.log(deviceDescription);
        const deviceInfo = update ? await registry.update(deviceDescription) : await registry.create(deviceDescription);

        const device: Device = deviceInfo.responseBody;

        console.log(device);

        // const configurationId = 'device_config_' + deviceRequest.deviceId;
        // let configuration: Configuration;
        // try {
        //     configuration = (await registry.getConfiguration(configurationId)).responseBody;
        //     await registry.removeConfiguration(configurationId);
        // } catch (e) {
        //     console.log("no config found for", deviceId);
        //     configuration = {
        //         id: configurationId,
        //         schemaVersion: '1',
        //         targetCondition: `deviceId='${deviceId}'`,
        //         content: {
        //             "deviceContent": {
        //                 "authentication": {
        //                     "symmetricKey": {
        //                         "primaryKey": 'test1',
        //                         "secondaryKey": 'test2'
        //                     }
        //                 }
        //             }
        //         }
        //     }
        //
        // }

        return device;
    }

    static async getDevice(user: User, deviceId: string) {
        const registry = Registry.fromConnectionString(this.getConnectionString(user));
        const deviceInfo = (await registry.get(deviceId));
        const device: Device = deviceInfo.responseBody;
        return device;
    }

    static async deleteById(user: User, id: string) {
        const registry = Registry.fromConnectionString(this.getConnectionString(user));
        const res = await registry.delete(id);
        return res.responseBody;
    }

    static async listDevices(user: User) {
        const registry = Registry.fromConnectionString(this.getConnectionString(user));
        const devices = await registry.list();
        return devices.responseBody;
    }

    static async getModules(user: User, deviceId: string) {
        const registry = Registry.fromConnectionString(this.getConnectionString(user));
        const configurationId = 'device_config_' + deviceId;
        let configuration: Configuration;
        try {
            configuration = (await registry.getConfiguration(configurationId)).responseBody;
            // @ts-ignore
            return configuration.content?.modulesContent['$edgeAgent']['properties.desired']['modules'];
        } catch (e) {
            return null;
        }
        // const devices = await registry.getModulesOnDevice(deviceId);
        // return devices.responseBody;
    }

    static async prepareConfiguration(registry: Registry, deviceId: string) {
        const configurationId = 'device_config_' + deviceId;
        let configuration: Configuration;
        try {
            configuration = (await registry.getConfiguration(configurationId)).responseBody;
            await registry.removeConfiguration(configurationId);
        } catch (e) {
            console.log("no config found for", deviceId);
            configuration = {
                id: configurationId,
                schemaVersion: '1',
                targetCondition: `deviceId='${deviceId}'`,
                content: {
                    "modulesContent": {
                        "$edgeAgent": {
                            "properties.desired": {
                                "modules": {},
                                "runtime": {
                                    "settings": {
                                        "minDockerVersion": "v1.25"
                                    },
                                    "type": "docker"
                                },
                                "schemaVersion": "1.1",
                                "systemModules": {
                                    "edgeAgent": {
                                        "settings": {
                                            "image": "mcr.microsoft.com/azureiotedge-agent:1.1",
                                            "createOptions": ""
                                        },
                                        "type": "docker"
                                    },
                                    "edgeHub": {
                                        "settings": {
                                            "image": "mcr.microsoft.com/azureiotedge-hub:1.1",
                                            "createOptions": "{\"HostConfig\":{\"PortBindings\":{\"443/tcp\":[{\"HostPort\":\"443\"}],\"5671/tcp\":[{\"HostPort\":\"5671\"}],\"8883/tcp\":[{\"HostPort\":\"8883\"}]}}}"
                                        },
                                        "type": "docker",
                                        "status": "running",
                                        "restartPolicy": "always"
                                    }
                                }
                            }
                        },
                        "$edgeHub": {
                            "properties.desired": {
                                "routes": {
                                    "route": "FROM /messages/* INTO $upstream"
                                },
                                "schemaVersion": "1.1",
                                "storeAndForwardConfiguration": {
                                    "timeToLiveSecs": 7200
                                }
                            }
                        }
                    }
                }
            }
        }
        return configuration;
    }

    static async deployModules(user: User, deviceId: string, moduleName: string, moduleURI: string, deviceConnectionString: string) {
        const registry = Registry.fromConnectionString(this.getConnectionString(user));
        const configuration = await this.prepareConfiguration(registry, deviceId);
        // @ts-ignore
        configuration.content.modulesContent['$edgeAgent']['properties.desired'].modules[moduleName] = {
            "settings": {
                "image": moduleURI,
                "createOptions": {
                    "HostConfig": {
                        "Binds": [
                            "/dev:/dev"
                        ],
                        "DeviceCgroupRules": [
                            "c *:* rmw"
                        ]
                    }
                }
            },
            "type": "docker",
            "version": "1.0",
            "status": "running",
            "restartPolicy": "always",
            "env": {
                "IOT_EDGE_CONNECTION_STRING": {
                    "value": deviceConnectionString
                }
            }
        }
        // @ts-ignore
        configuration.content.modulesContent[moduleName] = {
            "properties.desired": {}
        }
        await registry.addConfiguration(configuration);
    }

    static async deleteModule(user: User, deviceId: string, moduleName: string): Promise<Deployment> {
        const registry = Registry.fromConnectionString(this.getConnectionString(user));
        const configuration = await this.prepareConfiguration(registry, deviceId);
        // @ts-ignore
        delete configuration.content.modulesContent['$edgeAgent']['properties.desired'].modules[moduleName];
        // @ts-ignore
        delete configuration.content.modulesContent[moduleName];
        await registry.addConfiguration(configuration);
        return {deploymentId: ''}
    }

    static async subscribeToEventsHub(user: User) {
        await this.unSubscribeToEventsHub(user);
        const eventsConnStr = user.cloudProvider?.eventsHubConnectionString ?? eventsConnectionString;

        allEvents = {};
        subscriber[user.email] = new EventHubConsumerClient("$Default", eventsConnStr, {});

        console.log("subscribing to events");
        subscriber[user.email].subscribe({
            processEvents: async (messages) => {
                console.log("received messages", messages);
                for (const message of messages) {
                    if (message.systemProperties) {
                        const deviceId = message.systemProperties['iothub-connection-device-id'];
                        allEvents[deviceId] = [...allEvents[deviceId], ...messages.map(event => event.body)];
                        await AwsIotService.sendToDeviceStatic('', '', message.body);
                    }
                }
                return;
            },
            processError: async error => {
                console.log("received error", error);
            },
        });
    }

    static async unSubscribeToEventsHub(user: User) {
        if (subscriber[user.email]) {
            console.log("unsubscribing to events");
            await subscriber[user.email].close();
        }
    }

    static async getEvents(deviceId: string) {
        const events = allEvents[deviceId];
        allEvents[deviceId] = [];
        return events;
    }

    static async createUserSpace(user: User) {
        let creds, subscription;
        try {
            if (user.cloudProvider?.clientId) {
                console.log("using user credentials...");
                creds = await msRestNodeAuth.loginWithServicePrincipalSecret(user.cloudProvider?.clientId, user.cloudProvider?.secret, user.cloudProvider?.tenantId);
                subscription = user.cloudProvider.subscriptionId;
            } else {
                creds = await msRestNodeAuth.loginWithServicePrincipalSecret(clientId, secret, tenantId);
                subscription = subscriptionId;
            }
            const client = new IotHubClient(creds, subscription);

            console.log("Creating hub...", new Date());
            const iotHubName = "iot-" + new Date().getTime();
            const iotResourceGroup = "iot-group-" + new Date().getTime();

            const resourceManagementClient = new ResourceManagementClient(creds, subscription);
            await resourceManagementClient.resourceGroups.createOrUpdate(iotResourceGroup, {
                location: "East US",
            });
            console.log("Created resource group", new Date());

            const hub = await client.iotHubResource.createOrUpdate(iotResourceGroup, iotHubName, {
                location: "East US",
                sku: {
                    name: "S1",
                    tier: "Standard",
                    capacity: 1
                }
            })
            console.log("Successfully created hub", new Date());

            const keys = await client.iotHubResource.listKeys(iotResourceGroup, iotHubName);
            const primaryKey = keys.find(item => item.keyName === 'iothubowner');

            if (user.cloudProvider && hub.properties?.hostName && primaryKey) {
                user.cloudProvider.iotDomainName = hub.properties.hostName;
                user.cloudProvider.connectionString = `HostName=${hub.properties.hostName};SharedAccessKeyName=iothubowner;SharedAccessKey=${primaryKey.primaryKey}`;
                user.cloudProvider.eventsHubConnectionString = `Endpoint=${hub.properties.eventHubEndpoints?.events?.endpoint};SharedAccessKeyName=iothubowner;SharedAccessKey=${primaryKey.primaryKey};EntityPath=` + hub.properties.eventHubEndpoints?.events?.path;
            }
            console.log("Successfully retrieved hub keys", new Date());

            // @ts-ignore
            const dpsClient = new IotDpsClient(creds, subscription);
            const dpsResource = new IotDpsResource(dpsClient);
            const dpsName = "dps-" + new Date().getTime();

            console.log("Creating DPS...", new Date());


            const dpsRes = await dpsResource.createOrUpdate(iotResourceGroup, dpsName, {
                location: 'East US',
                properties: {
                    // @ts-ignore
                    iotHubs: [{
                        connectionString: user.cloudProvider?.connectionString ?? '',
                        location: 'East US'
                    }]
                },
                sku: {
                    name: 'S1'
                }
            });
            console.log('dpsResource.createOrUpdate response: ', dpsRes);

            if (user.cloudProvider) {
                user.cloudProvider.dpsIdScope = dpsRes.properties.idScope;
                user.cloudProvider.dpsServiceOperationsHostName = dpsRes.properties.serviceOperationsHostName;
            }
            console.log("Created DPS...", new Date());

            const dpsKeys = await dpsResource.listKeys(dpsName, iotResourceGroup);
            if (user.cloudProvider) {
                user.cloudProvider.dpsKey = dpsKeys[0].primaryKey;
            }
            console.log("Successfully retrieved DPS keys", new Date());

        } catch (e) {
            console.log("error", e);
            throw new HttpErrors.BadRequest(e.message);
        }
    }

    static async getLogs(user: User, deviceId: string, moduleName: string) {
        const client = Client.fromConnectionString(this.getConnectionString(user));
        const logs = await client.invokeDeviceMethod(deviceId, '$edgeAgent', {
            methodName: 'GetModuleLogs',
            payload: {
                "schemaVersion": "1.0",
                "items": [
                    {
                        "id": moduleName,
                        "filter": {
                            "tail": 100
                        }
                    }
                ],
                "encoding": "none",
                "contentType": "text"
            }
        });
        return logs.result.payload[0];
    }

    static async sendToModule(conn: string, deviceId: string, moduleName: string, payload: any) {
        const client = Client.fromConnectionString(conn);
        await client.invokeDeviceMethod(deviceId, moduleName, {
            methodName: 'getDeviceLog',
            payload
        });
    }
}

