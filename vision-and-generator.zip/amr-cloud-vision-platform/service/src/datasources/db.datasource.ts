import {inject, lifeCycleObserver, LifeCycleObserver} from '@loopback/core';
import {juggler} from '@loopback/repository';

let config = {};
if (process?.env?.testMode ) {
    // @ts-ignore
    config = {
        name: 'db',
        connector: 'memory'
    }
} else if (process.env.LOCAL) {
    config = {
        name: 'db',
        connector: 'postgresql',
        url: '',
        host: 'localhost',
        port: 5432,
        user: 'postgres',
        password: 'hamorim52',
        database: 'scoe-services',
        useNewUrlParser: true
    };
} else if (process.env.POSTGRESS) {
    config = {
        name: 'db',
        connector: 'postgresql',
        url: '',
        // host: process.env.SCOE_APP_NAME + '-postgresql.default.svc.cluster.local',
        host: process.env.POSTGRES_ENDPOINT_ADDRESS,
        port: 5432,
        user: 'scoeuser',
        password: '1234abcd',
        database: 'vision_platform_new_postgres',
        useNewUrlParser: true
    };
} else { // mongo
    config = {
        name: 'db',
        connector: 'mongodb',
        url: process.env.MONGODB,
        host: process.env.SCOE_APP_NAME + '-mongodb.default.svc.cluster.local',
        port: 27017,
        user: 'root',
        password: 'mevolveMelonim2020',
        database: process.env.SCOE_APP_NAME,
        useNewUrlParser: true
    }
}

// Observe application's life cycle to disconnect the datasource when
// application is stopped. This allows the application to be shut down
// gracefully. The `stop()` method is inherited from `juggler.DataSource`.
// Learn more at https://loopback.io/doc/en/lb4/Life-cycle.html
@lifeCycleObserver('datasource')
export class DbDataSource extends juggler.DataSource
    implements LifeCycleObserver {
    static dataSourceName = 'db';
    static readonly defaultConfig = config;

    constructor(
        @inject('datasources.config.db', {optional: true})
            dsConfig: object = config,
    ) {
        super(dsConfig);
    }
}
