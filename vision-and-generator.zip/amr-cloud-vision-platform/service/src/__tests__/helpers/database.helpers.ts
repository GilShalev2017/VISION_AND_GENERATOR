import {
    ConfirmationRepository,
    RequestsRateRepository
} from "../../repositories";
import {RefreshTokenRepository} from "../../micro-services/users/refresh-token.repository";
import {UserRepository} from "../../micro-services/users/user.repository";
import {UserCredentialsRepository} from "../../micro-services/users/user-credentials.repository";

import {ItemRepository} from "../../micro-services/files/item.repository"


import {testdb} from '../fixtures/datasources/testdb.datasource';

export async function givenEmptyDatabase() {
    let userCredentialsRepo: UserCredentialsRepository;
    await new UserCredentialsRepository(testdb).deleteAll();
    await new UserRepository(testdb, async () => userCredentialsRepo).deleteAll();
    await new RefreshTokenRepository(testdb).deleteAll();
    await new ConfirmationRepository(testdb).deleteAll();
    await new RequestsRateRepository(testdb).deleteAll();
    await new ItemRepository(testdb).deleteAll();
}
