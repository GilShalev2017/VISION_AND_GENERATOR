import {Client, expect} from '@loopback/testlab';
import {UserServiceApplication} from '../../';
import {givenEmptyDatabase} from '../helpers/database.helpers';
import {setupApplication} from "../acceptance/test-helper";
import {CognitoAuthService} from "../../micro-services/users/logic/cognito-auth.service";
import {UserRepository} from "../../micro-services/users/user.repository";
import {sinon} from "@loopback/testlab/dist/sinon";
import {testdb} from "../fixtures/datasources/testdb.datasource";
import {UserCredentialsRepository} from "../../micro-services/users/user-credentials.repository";

// ///////////////////////////////////////////////   <-  Login Flow->  ///////////////////////////////////////////////
describe("Users unit testing", () => {
    let app: UserServiceApplication;
    let client: Client;
    let userCredentialsRepo: UserCredentialsRepository;
    let userRepostiroy: UserRepository;
    let cognito: CognitoAuthService;

    beforeEach(givenStubbedRepository);
    beforeEach(givenMockCognitoService);

    before(givenEmptyDatabase);
    before('setupApplication', async () => {
        ({app, client} = await setupApplication());
    });


    after(async () => {
        await app.stop();
    });

    // expected -> WRONG_USERNAME_PASSWORD
    it('Test Hash', async () => {
        console.log('ENV AWS_COGNITO_CLIENT_SECRET', process.env.AWS_COGNITO_CLIENT_SECRET);
        const hash = cognito.getHash('roy');
        console.log(hash);
        expect(hash).equal('gB+5PKp3aiRN8oV1r2/bKv6dBMk6hab3WLyWBs4PF58=');
    });

    function givenStubbedRepository() {
        // userRepostiroy = sinon.createStubInstance(UserRepository);
        userRepostiroy = new UserRepository(testdb, async () => userCredentialsRepo);
    }

    function givenMockCognitoService() {
        // this creates a stub with GeocoderService API
        // in a way that allows the compiler to verify type correctness
        cognito = new CognitoAuthService(userRepostiroy);
    }

});
