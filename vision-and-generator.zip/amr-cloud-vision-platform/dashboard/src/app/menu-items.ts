import {NavbarItem} from './framework/navbar/navbar-config';
import {environment} from '../environments/environment';

export const menuItems: NavbarItem[] = [{
  displayName: 'Users',
  icon: 'account_circle',
  path: 'users',
  onlyAdmin: true,
}, {
  displayName: 'IoT Components',
  icon: 'account_circle',
  path: 'features',
}, {
  displayName: 'Devices',
  icon: 'camera_rear',
  path: 'devices',
}, {
  displayName: 'My Device Groups',
  icon: 'devices_other',
  path: 'groups',
}, {
  displayName: 'Developer tools',
  icon: 'devices',
  path: 'developer',
}, {
  displayName: 'Settings',
  icon: 'settings_outline',
  path: 'account',
},  {
  displayName: 'Editor',
  icon: 'edit',
  path: 'editor',
  onlyAdmin: true,
}, {
  displayName: 'Metrics',
  icon: 'poll',
  path: environment.serverUrl + 'grafana/',
  onlyAdmin: true,
  target: '_blank',
}, {
  displayName: 'Logs',
  icon: 'receipt',
  path: 'http://localhost',
  onlyAdmin: true,
  target: '_blank',
}, {
  displayName: 'API Explorer',
  icon: 'api',
  path: environment.serverUrl,
  onlyAdmin: true,
  target: '_blank'
}, {
  displayName: 'Logout',
  icon: 'logout',
  path: '#',
}];
