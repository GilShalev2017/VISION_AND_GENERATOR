import {Injectable} from '@angular/core';
import {BehaviorSubject} from 'rxjs';

export interface Header {
  title: string;
  back: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class PageTitleService {
  title = new BehaviorSubject<Header>({title: '', back: false});

  constructor() { }

  setTitle(title: string, back = false) {
    this.title.next({title, back});
  }

}
