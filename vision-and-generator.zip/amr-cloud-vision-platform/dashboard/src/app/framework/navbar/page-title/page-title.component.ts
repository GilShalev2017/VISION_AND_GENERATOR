import {ChangeDetectorRef, Component, OnInit} from '@angular/core';
import {PageTitleService} from './page-title.service';
import {Location} from '@angular/common';

@Component({
  selector: 'app-page-title',
  templateUrl: './page-title.component.html',
  styleUrls: ['./page-title.component.css']
})
export class PageTitleComponent implements OnInit {
  title: string;
  backButton = false;

  constructor(private pageTitleService: PageTitleService,
              private cd: ChangeDetectorRef,
              private location: Location) { }

  ngOnInit(): void {
    this.pageTitleService.title.subscribe(header => {
      this.title = header.title;
      this.backButton = header.back;
    });
  }

  back() {
    this.location.back();
  }
}
