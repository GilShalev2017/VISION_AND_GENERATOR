import {Injectable} from '@angular/core';
import {BehaviorSubject} from 'rxjs';

export interface ProfileLabels {
  name: string;
  email: string;
}

@Injectable({
  providedIn: 'root'
})
export class ProfileWidgetService {
  profileLabel = new BehaviorSubject<ProfileLabels>({name: '', email: ''});

  constructor() { }

  setProfileLabels(name: string, email: string) {
    this.profileLabel.next({name, email});
  }

}
