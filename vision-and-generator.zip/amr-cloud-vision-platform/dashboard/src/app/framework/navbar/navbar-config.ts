export interface NavbarConfig {
  openOnStart?: boolean;
  showIconsOnCollapse: boolean;
  toggleShowIconsOnCollapse?: boolean;
  toggleCollapse: 'ALLOW' | 'ONLY_COLLAPSED' | 'ONLY_EXPANDED';
  items: NavbarItem[];
}

export interface NavbarItem {
  icon: string;
  displayName: string;
  weight?: number;
  path: string;
  target?: string;
  onlyAdmin?: boolean;
}
