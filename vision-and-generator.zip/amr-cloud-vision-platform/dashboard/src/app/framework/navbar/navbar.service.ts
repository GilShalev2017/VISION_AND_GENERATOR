import {Injectable} from '@angular/core';
import {NavbarConfig} from './navbar-config';

@Injectable({
  providedIn: 'root'
})
export class NavbarService {

  config: NavbarConfig = null;

  constructor() { }

  setConfig(cfg: NavbarConfig) {
    this.config = cfg;
  }

  getConfig() {
    return this.config;
  }

}
