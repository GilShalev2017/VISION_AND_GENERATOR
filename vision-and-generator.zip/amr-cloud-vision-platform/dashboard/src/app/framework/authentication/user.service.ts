import {Injectable} from '@angular/core';
import {AuthenticationConfig} from './authentication-config';
import {environment} from '../../../environments/environment';
import {HttpClient} from '@angular/common/http';
import {catchError, switchMap, tap} from 'rxjs/operators';
import {Router} from '@angular/router';
import {Observable} from "rxjs";
import {ProfileWidgetService} from "../navbar/profile-widget/profile-widget.service";
import {User} from "../../demo/users/users.service";

interface Token {
  accessToken?: string,
  refreshToken?: string
}

interface TokenResponse {
  token: Token;
  admin: boolean;
}
interface ConfirmationCodeResponse{
  token: string;
  identifier: string;
  admin?: boolean;
}
@Injectable({
  providedIn: 'root'
})
export class UserService {
  config: AuthenticationConfig;
  user = false;
  token: string;
  admin: boolean;

  constructor(private httpClient: HttpClient, private router: Router, private profileWidgetService: ProfileWidgetService) {
    const token = localStorage.getItem('mevolve_token');
    if (token && token.toString().length > 10) {
      this.user = true;
      this.token = token;
    }
    const admin = localStorage.getItem('scoe_admin');
    if (admin && admin === '1') {
      this.admin = true;
    }
  }

  setOptions(options: AuthenticationConfig): void {
    this.config = options;
  }

  getConfig() {
    return this.config;
  }

  isAdmin(): boolean {
    return this.admin;
  }

  isAuthenticated(): boolean {
    return this.user;
  }

  isSuperuser(): boolean {
    const email = this.getUserEmail();
    return email === 'info@mevolve-cloud.com';
  }


  login(data) {

    return this.httpClient.post<TokenResponse>(environment.serverUrl + `users/login`, data)
      .pipe(tap(response => {
          this.user = true;
          const {accessToken, refreshToken} = response.token;
          if (accessToken.toString().length > 5 && refreshToken.toString().length > 5) {
            this.setTokens(accessToken, refreshToken);
            localStorage.setItem('scoe_admin', response.admin ? '1' : '0');
            this.token = accessToken;
            this.admin = response.admin;
          }
        }
      ));
  }

  signup(data) {

    return this.httpClient.post<TokenResponse>(environment.serverUrl + `users/signup`, data).pipe(tap((response) => {
      this.user = true;
      const {accessToken, refreshToken} = response.token;
      this.setTokens(accessToken, refreshToken);

      localStorage.setItem('scoe_admin', response.admin ? '1' : '0');
      this.token = accessToken;
      return response;
    }));
  }

  updateUser(data) {
    return this.httpClient.put(environment.serverUrl + `users/me`, data);
  }

  logout() {
    this.user = false;
    localStorage.removeItem('mevolve_token');
    localStorage.removeItem('mevolve_r_token');
    localStorage.removeItem('scoe_admin');
    this.router.navigateByUrl('/login');
    this.token = null;
  }


  getUserEmail() {
    try {
      const decodedToken = JSON.parse(atob(this.token.split('.')[1]));
      return decodedToken.email;
    } catch (e) {
      return null;
    }
  }

  getUserDetails(): Observable<User> {
    return this.httpClient.get<User>(environment.serverUrl + 'users/me');
  }

  getToken(token_name: string): string {
    return localStorage.getItem(token_name);
  }

  setTokens(accessToken: string, refreshToken: string): void {
    if (accessToken) {
      localStorage.setItem('mevolve_token', accessToken);
    }
    if (refreshToken) {
      localStorage.setItem('mevolve_r_token', refreshToken);
    }
  }


  tokenRefresh(): Observable<any> {
    const refreshToken = this.getToken('mevolve_r_token');
    return this.httpClient.post<any>(
      `${environment.serverUrl + 'users/refreshToken'}`,
      {refreshToken, oldAccessToken: this.token}).pipe(tap((response: Token) => {

        const {accessToken} = response;
        if (!accessToken) {
          this.logout();
        }
        this.token = accessToken;
        this.setTokens(accessToken, undefined);
        return response;

      }), catchError((err) => {
        this.logout();
        throw 'Something went wrong with refresh token process';
      })
    )

  }

  passwordReset(data) {
    return this.httpClient.post(environment.serverUrl + `users/passwordReset`, data).pipe(tap((response: { identifier: string }) => {
      return response;

    }));
  }

  passwordUpdate(data) {
    return this.httpClient.post(environment.serverUrl + `users/passwordUpdate`, data).pipe(tap((response: { identifier: string}) => {
      if (response?.identifier === 'passwordUpdate' ) {
        this.user = true;

      }
      return response;


    }));
  }

}
