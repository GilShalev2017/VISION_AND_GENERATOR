import {AbstractControl, FormGroup, ValidationErrors, ValidatorFn, Validators} from '@angular/forms';

export class FormValiations {

  private static validations = {
    password: [Validators.required, Validators.minLength(8)],
    password2: [Validators.required, Validators.minLength(8)],
    confirmationCode: [Validators.minLength(0)],
    email: [Validators.required, Validators.email]
  };
  private static fields = {
    LOGIN: ['email', 'password'],
    REGISTER: ['firstName', 'lastName', 'email', 'password', 'password2'],
    PASSWORD_RESET: ['email'],
    PASSWORD_UPDATE: ['confirmationCode', 'password', 'password2'],
    ADMIN_CONFIRMATION : ['confirmationCode']
  };
  private static options = {
    REGISTER: {validators: [FormValiations.passwordValidator]},
    PASSWORD_UPDATE: {validators: [FormValiations.passwordValidator]}
  };

  static getErrors(form: FormGroup): string[] {
    return Object.keys(form);

  }

  static getValidation(validationName: string): ValidatorFn[] {
    if (this.validations[validationName]) {
      return this.validations[validationName];
    }
    return [Validators.required];


  }

  static getOptions(mode: string): { [key: string]: [ValidationErrors | null] } {
    if (this.options[mode]) {
      return this.options[mode];
    }
    return {};
  }

  static getFields(mode: string): string[] {
    if (this.fields[mode]) {
      return this.fields[mode];
    }
    return [];
  }

  private static passwordValidator(form: FormGroup): boolean | { [key: string]: string } {
    if (!form.value.password || !form.value.password2) {
      return {notSame: 'Passwords are not identical'};
    }
    if (form.value.password !== form.value.password2) {
      return {notSame: 'Passwords are not identical'};
    }
    return false;
  }


}
