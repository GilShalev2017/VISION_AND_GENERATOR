import { Component } from '@angular/core';
import {NavbarConfig} from './framework/navbar/navbar-config';
import {menuItems} from './menu-items';
import {UserService} from './framework/authentication/user.service';
import {NavbarService} from './framework/navbar/navbar.service';
import {MatIconRegistry} from '@angular/material/icon';
import {DomSanitizer} from '@angular/platform-browser';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'client-framework';

  constructor(private userService: UserService, private navbarService: NavbarService, iconRegistry: MatIconRegistry, sanitizer: DomSanitizer) {

    iconRegistry.addSvgIcon('female', sanitizer.bypassSecurityTrustResourceUrl('assets/gender-female.svg'));
    iconRegistry.addSvgIcon('male', sanitizer.bypassSecurityTrustResourceUrl('assets/gender-male.svg'));
    iconRegistry.addSvgIcon('excel', sanitizer.bypassSecurityTrustResourceUrl('assets/microsoft-excel.svg'));
    iconRegistry.addSvgIcon('aws', sanitizer.bypassSecurityTrustResourceUrl('assets/svg/aws.svg'));
    iconRegistry.addSvgIcon('azure', sanitizer.bypassSecurityTrustResourceUrl('assets/svg/azure.svg'));
    iconRegistry.addSvgIcon('google', sanitizer.bypassSecurityTrustResourceUrl('assets/svg/google.svg'));
    iconRegistry.addSvgIcon('settings_outline', sanitizer.bypassSecurityTrustResourceUrl('assets/svg/settings.svg'));

    this.userService.setOptions({
      appHome: 'devices'
    });

    this.navbarService.setConfig({
      openOnStart: true,
      showIconsOnCollapse: false,
      toggleCollapse: 'ALLOW',
      items: menuItems
    });
  }



}
