import {Component, OnInit} from '@angular/core';
import {GroupsService} from './groups.service';
import {PageTitleService} from '../../framework/navbar/page-title/page-title.service';

@Component({
  selector: 'app-groups',
  template: '<app-entity-table [resource]="groupResource"></app-entity-table>',
  styleUrls: []
})
export class GroupsComponent implements OnInit {
  groupResource: any;

  constructor(private groupsService: GroupsService, private pageTitleService: PageTitleService) {
    this.groupResource = groupsService;
  }

  ngOnInit(): void {
    this.pageTitleService.setTitle('My Device Groups');
  }

}
