import {
  ChangeDetectorRef,
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import {ChartDataSets, ChartOptions} from 'chart.js';
import {CdkDragEnd} from '@angular/cdk/drag-drop';
import {Chart, chartColors, chartPallets, LoadingProgress} from '../../models/interfaces';
import {FormControl, Validators} from '@angular/forms';
import {ChartsService} from './charts.service';

@Component({
  selector: 'app-chart',
  templateUrl: './chart.component.html',
  styleUrls: ['./chart.component.css']
})
export class ChartComponent implements OnInit, OnChanges {
  LoadingProgress: typeof LoadingProgress = LoadingProgress;
  @Output()
  customFeatureHandler = new EventEmitter<string>();
  @Output()
  closeDialog = new EventEmitter();
  @Output()
  chartDialog = new EventEmitter<{ actionType: string, chartId?: string }>();
  @Output()
  removeChartDialog = new EventEmitter<string>();
  @Output()
  saveChart = new EventEmitter<Chart>();
  @Input()
  data: { [key: string]: number }[];
  @Input()
  savedChart: Chart;
  @Input()
  action: string;
  @Input()
  isInteractiveChart: boolean;
  @Input()
  withHeader: boolean;
  @Input()
  withFooter: boolean;
  @Input()
  isCustomFeature: boolean;
  @Input()
  loading: LoadingProgress;
  @Input()
  canvasWidth: number;

  currChartLables: string[];
  chartType: string;
  currChartData: ChartDataSets[];
  pieChartOptions: (ChartOptions & { annotation?: any }) = {
    legend: {
      display: false,
      position: 'left'
    },
    responsive: true,
    maintainAspectRatio: false,
    // tooltips: {
    //   callbacks: {
    //     label(tooltipItem: Chart.ChartTooltipItem, data: Chart.ChartData): any {
    //       console.log(tooltipItem);
    //       console.log(data);
    //     }
    //   }
    // }
  };
  chartOptions: (ChartOptions & { annotation?: any }) = {

    legend: {
      display: false,
      position: 'left'
    },
    responsive: true,
    maintainAspectRatio: false,
    tooltips: {
      // callbacks: {
      //   label(tooltipItem: Chart.ChartTooltipItem, data: Chart.ChartData): any{
      //     console.log(tooltipItem);
      //     console.log(data);
      //   }
      // },
      position: 'nearest',
      backgroundColor: 'rgba(255,255,255,0.9)',
      bodyFontColor: '#999',
      borderColor: '#999',
      borderWidth: 1,
      caretPadding: 15,
      displayColors: false,
      enabled: true,
      intersect: true,
      mode: 'x',
      titleFontColor: '#999',
      titleMarginBottom: 10,
      xPadding: 15,
      yPadding: 15,
    },
    scales: {
      xAxes: [{
        gridLines: {
          display: false
        },
        ticks: {
          beginAtZero: true
        }
      }],
    }
  };

  selectedColorPallete: string[];
  colorsDic = {};
  colorPallets: string[][];

  isFooter: boolean;
  isPaletteMode: boolean;

  dataFields: string[];
  xAxis: string;

  chartDescriptionFormControl = new FormControl('', [Validators.required]);
  okString: string;
  chartTypes: { type: string, icon: string, toolTip: string }[];
  currChartOptions: (ChartOptions & { annotation?: any });

  @ViewChild('chart_footer') element: ElementRef;


  constructor() {
    this.colorPallets = chartPallets;
    this.selectedColorPallete = chartPallets[0];
    this.isPaletteMode = false;
    this.currChartData = [];
    this.currChartLables = [];
    this.chartType = 'line';
    this.xAxis = undefined;
    this.okString = 'Save';
    this.currChartOptions = this.chartOptions;


    this.chartTypes = [
      {type: 'pie', icon: 'pie_chart', toolTip: 'pie chart'},
      {type: 'line', icon: 'show_chart', toolTip: 'line chart'},
      {type: 'bar', icon: 'bar_chart', toolTip: 'bar chart'}
    ];
  }


  ngOnInit(): void {
    this.toLineChart();
  }

  ngOnChanges(changes: SimpleChanges): void {

    const newChartData = [];
    if ((changes.data?.currentValue && changes?.data?.previousValue?.length && changes?.data?.currentValue?.length > 0 &&
      changes.data.currentValue.length !== changes.data.previousValue.length) || changes.savedChart) {
      if (this.chartType === 'pie') {
        // @ts-ignore
        newChartData.push({...this.currChartData[0], data: this.currChartData[0].data.map(cD => cD + 1)});
      } else {
        for (const item of this.currChartData) {
          newChartData.push({
            ...item,
            data: changes.data.currentValue.map(c => c[item.label ?? item[this.xAxis]])
          });

        }

      }
    }
    this.currChartData = newChartData;
    if (this.chartType !== 'pie' && changes?.data?.currentValue) {
      this.currChartLables = changes.data.currentValue.map(cD => cD[this.xAxis ? this.xAxis : 'timestamp']);
    }

  }


  labelDragEnded(event: CdkDragEnd, field, index?: number) {

    const footerPosition = this.element?.nativeElement?.getBoundingClientRect();
    const parentElement = event.source.element.nativeElement.getBoundingClientRect().top;
    const currEventYpos = parentElement + event.distance.y;
    if (!this.customFeatureHandler) {
      const {top, left, right, bottom} = footerPosition;
      if (currEventYpos > (top - 50) && currEventYpos < (bottom + 50) && event.distance.x > left && event.distance.x < right) {

        this.colorsDic[field] = {backgroundColor: this.selectedColorPallete[index]};
        this.addAxis('h', field, index);
      }
    }
    if (event.distance.x > 50 && event.distance.y < 181) {
      this.colorsDic[field] = {backgroundColor: this.selectedColorPallete[index]};
      this.addAxis('v', field, index);

    }
    if (this.customFeatureHandler) {
      this.customFeatureHandler.emit(field);
    }
  }


  handleVerticalButtonClick(field: string) {
    if (this.currChartData.length === 1 && !this.xAxis) {
      return;
    }
    if (this.colorsDic[field]) {
      delete this.colorsDic[field];
      this.removeAxis(field);
      this.currChartLables = this.data.map(cD => cD.timestamp.toString());
    }
  }

  removeAxis(field: string) {
    if (this.customFeatureHandler) {
      this.customFeatureHandler.emit(field);
    }
    if (this.xAxis === 'timestamp' && field === this.xAxis) {
      return;
    } else if (this.xAxis === field) {
      this.xAxis = 'timestamp';
    }
    this.currChartData = this.currChartData.filter(c => c.label !== field);
    delete this.colorsDic[field];
  }

  handleColorChange(event: CdkDragEnd, index: number) {
    if (event.distance.x > 50) {
      Object.keys(this.colorsDic).forEach((currTag, colorIndex) =>
        this.colorsDic[currTag].backgroundColor = this.colorPallets[index][colorIndex]);
      this.currChartData = this.currChartData.filter(cD => cD.label).map(cD => ({
        backgroundColor: this.colorsDic[cD.label].backgroundColor,
        borderColor: this.colorsDic[cD.label].backgroundColor,
        data: cD.data,
        label: cD.label,
        pointBackgroundColor: this.colorsDic[cD.label].backgroundColor,
        pointBorderColor: 'black',
        pointHoverBackgroundColor: this.colorsDic[cD.label].backgroundColor,
        pointHoverBorderColor: this.colorsDic[cD.label].backgroundColor
      }));
      this.selectedColorPallete = this.colorPallets[index];

    }
  }


  setChartType(chartTypePrm: string) {
    if (this.isPaletteMode) {
      this.isPaletteMode = !this.isPaletteMode;
    }
    if (this.chartType === 'pie' && chartTypePrm !== 'pie') {
      this.currChartOptions = this.chartOptions;
      this.toLineChart();
    } else if (chartTypePrm === 'pie') {
      this.toPieChart();
    }
    this.chartType = chartTypePrm;


  }


  addAxis(currAxis: string, field: string, index?: number) {
    if (!field || this.currChartData.find(cD => cD.label === field)) {
      return;
    }
    const fieldData = this.data.map(cD => cD[field]);
    const color = this.selectedColorPallete[index ?? Object.keys(this.colorsDic).length + 1];
    this.colorsDic[field] = {backgroundColor: color};


    if (currAxis === 'v') {

      this.currChartData = [...this.currChartData, {
        backgroundColor: color,
        borderColor: color,
        data: fieldData,
        label: field,
        pointBackgroundColor: color,
        pointBorderColor: 'black',
        pointHoverBackgroundColor: color,
        pointHoverBorderColor: color
      }];
    } else if (currAxis === 'h') {
      this.currChartLables = this.data.map(cD => cD[field].toString());
      if (this.xAxis) {
        delete this.colorsDic[this.xAxis];
        this.currChartData = this.currChartData.filter(cLd => cLd.label !== this.xAxis);
      }
      this.xAxis = field;
      this.colorsDic[field] = {backgroundColor: color};
    }

  }

  toLineChart() {
    this.currChartData = [];
    if (this.savedChart && this.savedChart.colorPallete !== undefined && this.savedChart?.dataFields.length > 0) {
      const {colorPallete, dataFields, chartDescription, xAxis} = this.savedChart;
      if (xAxis !== undefined && xAxis !== null && xAxis.toString().length > 3) {
        this.xAxis = xAxis;
        this.addAxis('h', xAxis);

      }

      this.chartDescriptionFormControl.setValue(chartDescription);
      this.selectedColorPallete = this.colorPallets[colorPallete];

      dataFields.forEach((cDf, index) => this.colorsDic[cDf] = this.selectedColorPallete[index]);

      dataFields.forEach((cDf, index) => this.addAxis('v', cDf, index));

    } else if (this.data.length > 0) {
      this.selectedColorPallete = this.colorPallets[0];
    }
    this.dataFields = Object.keys(this.data[0]).filter(cK => cK !== 'timestamp');
  }

  toPieChart() {
    const pieChartData = [];
    this.currChartData.forEach(cLd => pieChartData.push(cLd.data.length));
    this.currChartLables = this.currChartData.map(cLd => cLd.label);
    this.currChartData = [{
      backgroundColor: [...Object.keys(this.colorsDic).map(cC => this.colorsDic[cC].backgroundColor)],
      data: pieChartData
    }];
    this.currChartOptions = this.pieChartOptions;

  }


  handleSubmit() {
    if (this.chartDescriptionFormControl.value === '' || !this.selectedColorPallete || this.dataFields.length === 0) {
      return;
    }
    const newChart = {
      chartDescription: this.chartDescriptionFormControl.value ?? '',
      colorPallete: this.colorPallets.findIndex(cP => cP === this.selectedColorPallete),
      dataFields: this.currChartData.filter(cLd => cLd.label !== undefined && cLd.label !== '').map(cLd => cLd.label),
      chartId: this.savedChart.chartId ?? undefined,
      xAxis: this.xAxis ?? undefined
    };
    if (!this.savedChart.chartId) {
      delete newChart.chartId;
    }

    this.saveChart.emit(newChart);
  }


  removeChartHandler() {
    this.removeChartDialog.emit(this?.savedChart?.chartId);
  }


  copyChartHandler() {
    const newChart = {
      chartDescription: this.chartDescriptionFormControl.value ?? '',
      colorPallete: this.colorPallets.findIndex(cP => cP === this.selectedColorPallete),
      dataFields: this.currChartData.filter(cLd => cLd.label !== '').map(cLd => cLd.label),
      chartId: undefined
    };
    this.saveChart.emit(newChart);
  }

  configureChartHandler() {
    if (this.chartDialog) {
      this.chartDialog.emit({actionType: 'update', chartId: this?.savedChart?.chartId});

    }
  }

  handleModalClose() {
    this.closeDialog.emit();
  }
}




