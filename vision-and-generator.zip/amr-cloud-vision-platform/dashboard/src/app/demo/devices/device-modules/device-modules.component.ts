import {Component, Input, OnChanges, OnDestroy, OnInit, SimpleChanges} from '@angular/core';
import {awsStatusSymbols, DeploymentType, LoadingProgress} from 'src/app/models/interfaces';
import {Device, DevicesService, Modules} from '../devices.service';
import {MatDialog} from '@angular/material/dialog';
import {DeployDialogComponent} from '../deploy-dialog/deploy-dialog.component';
import {StreamEventsComponent} from '../../stream-events/stream-events.component';
import {ConfirmComponent} from '../../../dialogs/confirm/confirm.component';
import {tap} from 'rxjs/operators';
import {MatSnackBar} from '@angular/material/snack-bar';
import {FeaturesService} from '../../features/features.service';


@Component({
  selector: 'app-device-modules',
  templateUrl: './device-modules.component.html',
  styleUrls: ['./device-modules.component.css']
})
export class DeviceModulesComponent implements OnInit, OnChanges, OnDestroy {
  LoadingProgress = LoadingProgress;
  state: LoadingProgress = LoadingProgress.LOADING;
  awsSymbols: typeof awsStatusSymbols;
  disableDeployment = false;

  @Input()
  device: Device;

  modules: Modules[];
  moduleKeys: string[] = [];
  deploymentType: DeploymentType;
  isPolling = false;
  deploymentId: string;
  deploymentStatus: string;
  private deploymentInterval: ReturnType<typeof setTimeout>;

  constructor(private snackBar: MatSnackBar, public dialog: MatDialog, public resource: DevicesService, public featuresService: FeaturesService) {
    this.deploymentStatus = '';
    this.awsSymbols = awsStatusSymbols;
  }

  ngOnInit(): void {
  }

  ngOnDestroy() {
    clearInterval(this.deploymentInterval);
  }

  ngOnChanges(changes: SimpleChanges) {
    if (!this.modules && this.device) {
      this.get(true);
      this.getDeviceDeployment();

    }
  }

  getDeviceDeployment() {
    this.resource.getDeviceDeployment(this.device.deviceId).subscribe(data => {
      if (data.deploymentId && data.deploymentId.toString().length > 5) {
        this.deploymentId = data.deploymentId;
        this.deploymentStatus = data.deploymentStatus === 'ACTIVE' ? 'IN_PROGRESS' : data.deploymentStatus;
        this.pollDeploymentStatus();

      }
    });
  }

  pollDeploymentStatus() {
    if (!this.isPolling) {
      this.isPolling = true;
    }
    if (!this.deploymentId || this.deploymentId.toString().length < 5) {
      console.log('deploymentId is invalid!');
      return;
    }
    this.deploymentInterval = setInterval(() => this.getDeploymentsStatus(), 10000);
  }

  getDeploymentsStatus() {
    this.resource.getDeploymentsStatus(this.deploymentId).subscribe(data => {
      if (data?.deploymentStatus) {
        this.deploymentStatus = data.deploymentStatus === 'ACTIVE' ? 'IN_PROGRESS' : data.deploymentStatus;
      }
      if (data.deploymentStatus !== 'ACTIVE') {
        const text = this.deploymentType === 'DELETION' ? ' deleted ' : ' deployed';
        if (data.deploymentStatus === 'COMPLETED') {
          this.snackBar.open(this.deploymentId + ` was  ${text} successfully!`, null, {
            duration: 6000,
          });
        } else {
          this.snackBar.open(this.deploymentId + ` was not ${text} successfully with status: ${data.deploymentStatus}`, null, {
            duration: 6000,
          });
        }
        clearInterval(this.deploymentInterval);
        this.deploymentStatus = undefined;
        this.deploymentId = undefined;
        this.isPolling = false;
        this.get(true);
      }
    });
  }

  get(refresh: boolean) {
    if (!this.isPolling) {
      this.state = LoadingProgress.LOADING;
    }
    this.resource.getDeviceById(this.device.deviceId, refresh).subscribe(modules => {
      this.modules = Object.keys(modules).map(cK => ({key: cK, ...modules[cK]}));
      this.state = LoadingProgress.DONE;
      this.moduleKeys = modules ? Object.keys(modules) : [];

      if (!this.moduleKeys.includes('aws.greengrass.Nucleus')) {
        this.disableDeployment = true;
      }
      else {
        this.disableDeployment = false;
      }
    });
  }

  deploy() {
    this.featuresService.getCount().subscribe( response => {
      this.dialog.open(DeployDialogComponent, {
        width: '1100px',
        data: {
          device: this.device,
          totalLength: response,
          moduleKeys: this.moduleKeys
        }
      }).afterClosed().subscribe((data) => {
        if (data?.deploymentId) {
          this.deploymentType = DeploymentType.DEPLOYMENT;
          this.deploymentId = data.deploymentId;
          this.deploymentStatus = 'IN_PROGRESS';
        }
        if (this.deploymentId && !this.isPolling && this.deploymentStatus !== 'FINISHED' && this.deploymentStatus !== 'COMPLETED') {
          this.pollDeploymentStatus();
        }
        console.log('closed', data);
      });
    });
  }

  refresh() {
    this.get(true);
  }

  monitor() {
    this.dialog.open(StreamEventsComponent, {
      height: '700px',
      width: '700px',
      data: {
        device: this.device
      }
    });
  }

  deleteModule(moduleKey: string) {
    this.dialog.open(ConfirmComponent, {
      width: '600px',
      data: {
        action: 'Confirm Delete',
        name: `Are you sure you would like to delete this module?`,
        doAction: () => {
          return this.resource.deleteModule(this.device.deviceId, moduleKey).pipe(tap((data) => {
            console.log(data);
            this.deploymentType = DeploymentType.DELETION;
            this.deploymentId = data.deploymentId;
            this.deploymentStatus = 'IN_PROGRESS';
          }));
        }
      }
    }).afterClosed().subscribe(data => {
      console.log(data);
      this.snackBar.open(`Delete process started...`, null, {
        duration: 6000,
      });
      if (this.deploymentId && !this.isPolling && this.deploymentStatus !== 'FINISHED' && this.deploymentStatus !== 'COMPLETED') {
        this.pollDeploymentStatus();
      }
    });
  }
}
