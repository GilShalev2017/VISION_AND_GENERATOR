import {Injectable} from '@angular/core';
import {AuthLevel, Entity, EntityService, UserCloudProvider} from '../../models/interfaces';
import {environment} from '../../../environments/environment';
import {HttpClient} from '@angular/common/http';
import {Observable, of, Subject} from 'rxjs';
import {FormControl, FormGroup} from '@angular/forms';
import {CacheService} from '../cache.service';
import {Registry} from 'azure-iothub';
import DeviceDescription = Registry.DeviceDescription;
import {map, mergeMap, tap} from 'rxjs/operators';
import {IotEvent} from '../stream-events/stream-events.component';
import {Feature} from "../features/features.service";

export interface Device extends Entity {
  deviceId: string;
  edgeEnabled: boolean;
  hubEnabled: boolean;
  authType?: string;
  autoGenKeys?: boolean;
  primaryKey?: string;
  secondaryKey?: string;
  authentication?: {
    symmetricKey: {
      primaryKey?: string;
      secondaryKey?: string;
    }
  };
} // entity

export interface Module {
  settings: {
    image: string;
    createOptions: string;
  };
  type: string;
  version: string;
  status: string;
  restartPolicy: string;
}

export interface Modules {
  settings?: { image: string; createOptions: string };
  type?: string;
  version?: string;
  restartPolicy?: string;
  key?: string;
  status?: string;
}

export interface Deployment {
  deploymentId: string;
  deploymentStatus?: string;
}

@Injectable({
  providedIn: 'root'
})
export class DevicesService implements EntityService {

  displayName = 'device';
  updated$: Subject<null> = new Subject<null>();
  // @ts-ignore
  fields = {
    deviceId: {displayName: 'Device ID '},
    connectionState: {displayName: 'Connection State', editable: false},
    // edgeEnabled: {displayName: 'Edge Enabled', defaultValue: true, editable: false},
    hubEnabled: {displayName: 'Greengrass Status', defaultValue: true, editable: true},
    authType: {displayName: 'Authentication Type'},
    autoGenKeys: {displayName: 'Auto Generate keys', defaultValue: true, type: 'boolean'},
    primaryKey: {displayName: 'Primary Key'},
    secondaryKey: {displayName: 'Secondary Key'}
  }; // fields

  cloudProvider: UserCloudProvider = null;
  iotHubHostName = '';

  constructor(private httpClient: HttpClient, private cache: CacheService) {
  }

  getSingleForm(device: Device): FormGroup {
    const controls = Object.keys(this.fields).reduce((controlMap, field) => {
      if (this.fields[field].editable !== false) {
        controlMap[field] = new FormControl(device ? device[field] : this.fields[field].defaultValue);
      }
      return controlMap;
    }, {});
    return new FormGroup(controls);
  }

  getUpdatedSubject() {
    return this.updated$;
  }

  get(page: number, pageSize: number, refresh?: boolean): Observable<Entity[]> {
    const cacheKey = 'devices_' + page + '_' + pageSize;
    const cached = this.cache.get(cacheKey);
    if (!refresh && cached !== undefined) {
      return of(cached);
    }
    const filter = {
      offset: 0,
      limit: pageSize,
      skip: page * pageSize,
      order: [
        'name ASC'
      ]
    };
    return this.httpClient.get<Device[]>(environment.serverUrl + 'devices/?filter=' + encodeURI(JSON.stringify(filter)))
      .pipe(tap(deviceModules => {
        this.cache.set(cacheKey, deviceModules);
        return deviceModules;
      }));
  }

  getDeviceMetadata(id: string): Observable<DeviceDescription> {
    return this.get(0, 50).pipe(map((devices: Device[]) => {
      return devices.find(device => device.deviceId === id);
    }));
  }

  getDeviceById(id: string, refresh?: boolean): Observable<Modules> {
    const cacheKey = 'device_modules_' + id;
    const cached = this.cache.get(cacheKey);
    if (!refresh && cached !== undefined) {
      return of(cached);
    }
    return this.httpClient.get<Modules>(environment.serverUrl + 'devices/' + id + '/modules')
      .pipe(tap(deviceModules => {
        this.cache.set(cacheKey, deviceModules);
        return deviceModules;
      }));
  }

  delete(deviceId: string): Observable<void> {
    return this.httpClient.delete<void>(environment.serverUrl + `devices/${deviceId}`, {});
  }

  save(id: string, entity: Device): Observable<Device> {
    console.log(entity);
    // Remove null fields
    for (const key in entity) {
      if (entity[key] === null) {
        delete entity[key];
      }
    }
    if (id) {
      return this.httpClient.put<Device>(environment.serverUrl + 'devices/' + id, entity);
    } else {
      console.log('creating device', entity);
      return this.httpClient.post<Device>(environment.serverUrl + 'devices', entity);
    }
  }

  deploy(id: string, moduleName: string, moduleUri: string, componentVersion: string, primaryKey: string): Observable<void> {
    return this.buildConString(id, primaryKey).pipe(mergeMap(connectionString => {
      return this.httpClient.post<void>(environment.serverUrl + `devices/${id}/deploy`, {
        moduleName,
        moduleUri,
        connectionString,
        componentVersion
      });
    }));
  }

  deployMultiple(id: string, selectedModules: Feature[], primaryKey: string): Observable<void> {
    return this.buildConString(id, primaryKey).pipe(mergeMap(connectionString => {
      return this.httpClient.patch<void>(environment.serverUrl + 'devices/multiple/' + id, {
        selectedModules,
        connectionString
      });
    }));
  }

  getDeploymentsStatus(deploymentstId: string): Observable<Deployment> {
    return this.httpClient.get<Deployment>(`${environment.serverUrl}/devices/deploymentStatus/${deploymentstId}`);

  }

  getDeviceDeployment(deviceId: string): Observable<Deployment> {
    return this.httpClient.get<Deployment>(`${environment.serverUrl}devices/deviceDeployments/${deviceId}`);

  }

  deleteModule(id: string, moduleName: string): Observable<Deployment> {
    return this.httpClient.delete<Deployment>(`${environment.serverUrl}devices/${id}/deleteModule/${moduleName}`);
  }

  subscribe(module: string): Observable<void> {
    return this.httpClient.post<void>(environment.serverUrl + 'subscribeToEvents', {module});
  }

  unSubscribe(): Observable<void> {
    return this.httpClient.post<void>(environment.serverUrl + 'unsubscribeToEvents', {});
  }

  getEvents(deviceId: string, module: string, time: string): Observable<any[]> {
    return this.httpClient.get<IotEvent[]>(environment.serverUrl + 'devices/' + deviceId
      + '/events?module=' + module + '&time=' + time, {});
  }

  getLogs(deviceId: string, moduleName: string): Observable<{ payload: string }> {
    return this.httpClient.get<{ payload: string }>(environment.serverUrl + 'logs/' + deviceId + '/' + moduleName, {});
  }

  getIotHubHostName(): Observable<string> {
    if (this.iotHubHostName) {
      return of(this.iotHubHostName);
    }
    return this.httpClient.get<{ cloudProvider: UserCloudProvider }>(environment.serverUrl + 'users/me').pipe(
      tap(data => {
        this.cloudProvider = data.cloudProvider;
      }),
      map(response => {
        this.iotHubHostName = response?.cloudProvider?.iotDomainName ?? 'moshe-iot-1.azure-devices.net';
        return this.iotHubHostName;
      }));
  }

  getCloudProvider(): Observable<UserCloudProvider> {
    return this.httpClient.get<{ cloudProvider: UserCloudProvider }>(environment.serverUrl + 'users/me').pipe(
      map(response => {
        return response.cloudProvider;
      }));
  }

  buildConString(deviceId, key) {
    return this.getIotHubHostName()
      .pipe(map(iotHubName => `HostName=${iotHubName};DeviceId=${deviceId};SharedAccessKey=${key}`));
  }

  sendMessageToDevice(deviceId: string, message: string, module: string): Observable<void> {
    return this.httpClient.post<void>(environment.serverUrl + 'sendToDevice', {deviceId, message, module});
  }
}
