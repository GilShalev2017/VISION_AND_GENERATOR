import {
  ChangeDetectorRef,
  Component,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  SimpleChanges,
  ViewChild, ViewChildren
} from '@angular/core';
import {Chart, LoadingProgress} from 'src/app/models/interfaces';
import {Device, DevicesService} from '../devices/devices.service';
import {ReplaySubject, timer} from 'rxjs';
import {takeUntil, timestamp} from 'rxjs/operators';
import {MatSnackBar} from '@angular/material/snack-bar';
import {SocketService} from '../devices/socket.service';
import {MatTable, MatTableDataSource} from '@angular/material/table';
import * as FileSaver from 'file-saver';
import {formatDate} from '@angular/common';
import {MatDialog} from '@angular/material/dialog';
import {ConfirmComponent} from '../../dialogs/confirm/confirm.component';
import {ChartsDialogComponent} from '../../dialogs/charts/chartsDialog.component';
import {ChartsService} from '../chart/charts.service';
import {NoopScrollStrategy} from '@angular/cdk/overlay';
import {MatPaginator} from '@angular/material/paginator';
import {MatSelectChange} from '@angular/material/select';
import {Sort} from '@angular/material/sort';

export interface IotEvent {
  device_id: string;
  sample_time: number;
  payload: any;
}


@Component({
  selector: 'app-stream-events',
  templateUrl: './stream-events.component.html',
  styleUrls: ['./stream-events.component.css'],
})
export class StreamEventsComponent implements OnInit, OnDestroy, OnChanges {
  LoadingProgress: typeof LoadingProgress = LoadingProgress;
  state: LoadingProgress = LoadingProgress.LOADING;
  displayedColumns: string[] = ['sample_time', 'payload'];
  dataSource: MatTableDataSource<any>;
  selectedPreview = 'events_raw_data';
  eventsAttributes: string[];

  @ViewChild(MatTable) table: MatTable<IotEvent>;


  @Input()
  device: Device;
  dialogRef;
  listening = false;

  moduleKeys: string[] = [];
  events: IotEvent[] = [];
  newMessage: string;
  selectedModule: string;
  canvasWidth: number;
  @ViewChild(MatPaginator, {static: false}) paginator: MatPaginator;

  charts: Chart[];
  selectedInsightsChart: {
    dataFields: string[], means: number[], trends: number[],
    covariance: { source: string, target: string, value: number }
  };
  insights: { Covariance: number, Mean: number, Trend: number };
  eventsFilter: string;
  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);

  constructor(
    private chartService: ChartsService,
    private devicesService: DevicesService,
    private chartsService: ChartsService,
    private socketService: SocketService,
    private cd: ChangeDetectorRef,
    public dialog: MatDialog,
    private snackBar: MatSnackBar,
    private cdr: ChangeDetectorRef
  ) {
    this.charts = [];
    this.canvasWidth = screen.width > 1600 ? 700 : 400;
    this.dataSource = new MatTableDataSource<any>([]);
    this.insights = {Covariance: -1, Trend: -1, Mean: -1};
    this.selectedInsightsChart = {
      dataFields: [],
      means: [],
      trends: [],
      covariance: {source: undefined, target: undefined, value: undefined},
    };
    this.eventsFilter = 'text';

  }


  ngOnInit(): void {

    this.devicesService.getDeviceById(this.device.deviceId).subscribe(modules => {
      this.moduleKeys = modules ? Object.keys(modules) : [];
      this.state = LoadingProgress.DONE;
    });
  }

  ngOnChanges(changes: SimpleChanges) {
    console.log(changes);
  }

  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }


  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;

    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  listen(start: boolean) {

    this.listening = true;
    this.chartService.getUserCharts({module: this.selectedModule}).subscribe(charts => {
      this.charts = charts;
    });
    const time = (Math.floor(Date.now() / 1000)).toString();
    if (start) {
      this.destroyed$ = new ReplaySubject(1);
      let lastEventTime = (Math.floor(Date.now() / 1000));
      timer(0, 6000).pipe(takeUntil(this.destroyed$)).subscribe(() => {

        this.devicesService.getEvents(this.device.deviceId, this.selectedModule, lastEventTime.toString()).subscribe(events => {
            events = events.sort((a, b) => a.sample_time - b.sample_time);

            if (this.selectedPreview === 'insights') {
              this.calculateInsights();
            }
            const lastTimestamp = this.events.length === 0 ? 0 : this.events[this.events.length - 1].sample_time;
            lastEventTime = lastTimestamp;
            for (const event of events) {
              if (event.sample_time > lastTimestamp) {

                this.events.push(event);
                const isFilter = this.dataSource.filter;
                console.log('PAYLOAD=' + event.payload);
                console.log('TYPEOF=' + typeof event.payload);
                const jsonObj = JSON.parse(event.payload);
                console.log('jsonObj=' + JSON.stringify(jsonObj));

                try {
                  const eventsArr = this.events.map(cE => ({timestamp: new Date(cE.sample_time * 1000).toISOString().substr(11, 8), ...JSON.parse(cE.payload)}));
                  this.dataSource = new MatTableDataSource(eventsArr);
                }
                catch (e) {
                  console.log('ERROR IS = ' + e + e.Message);
                }


                if (isFilter) {
                  this.dataSource.filter = isFilter;
                }


                if (!this.dataSource.paginator) {
                  this.dataSource.paginator = this.paginator;
                }

                if (this.selectedInsightsChart.means.length > 0) {
                  this.selectedInsightsChart.means = this.calculateDataSetMeans(this.selectedInsightsChart.dataFields);
                  this.selectedInsightsChart.trends = this.calculateDataSetTrends(this.selectedInsightsChart.dataFields);
                  this.selectedInsightsChart.covariance.value = this.calculateCovaraince(this.selectedInsightsChart.dataFields);

                }
                this.cdr.detectChanges();


                this.displayedColumns = Object.keys(this.dataSource.data[0]);
                this.eventsAttributes = Object.keys(this?.events[0]?.payload) ?? undefined;


              }
              if (this.dialogRef?.componentInstance) {
                this.dialogRef.componentInstance.data.dataSource = this.dataSource.data;
              }
              if (this.listening) {
                this.listening = false;
              }


            }

          }
        );
      });
    } else {
      this.destroyed$.next(true);
    }

  }

  send() {
    this.state = LoadingProgress.LOADING;
    this.devicesService.sendMessageToDevice(this.device.deviceId, this.newMessage, this.selectedModule).subscribe(() => {
      this.snackBar.open('Successfully sent a message!', null, {
        duration: 3000,
      });
      this.state = LoadingProgress.DONE;
    });
    this.newMessage = '';
  }

  toDate(date: string) {
    return new Date(date);
  }

  saveToFile() {
    const eventStrings = this.events.map(event => {
      return '  ' + JSON.stringify(event) + ',\n';
    });
    eventStrings.unshift('{\n');
    eventStrings.push('}');
    const date = formatDate(Date.now(), 'MM-dd-yyyy_hh-mm', 'en-US');
    const fileName = this.device.deviceId + '-' + this.selectedModule + '-raw' + date + '.json';
    const file = new File(eventStrings, fileName, {type: 'text/plain;charset=utf-8'});
    FileSaver.saveAs(file);
  }

  chartDialog(args: { actionType: string, chartId?: string }) {
    const {actionType, chartId} = args;

    let actionTxt = '';
    switch (actionType) {
      case 'add':
        actionTxt = 'Add new chart';
        break;
      case 'update':
        actionTxt = 'Configure a chart';
        break;
    }


    this.dialogRef = this.dialog.open(ChartsDialogComponent, {
      height: window.innerHeight < 900 ? '80%' : '70%',
      width: '70%',
      autoFocus: false,
      scrollStrategy: new NoopScrollStrategy(),
      data: {
        savedChart: chartId ? this.charts.find(cC => cC.chartId === chartId) : {},
        removeChart: (chartID) => this.removeChart(chartID),
        saveChart: (chartObject) => this.saveChart(chartObject),
        events: this.eventsAttributes,
        dataSource: this.dataSource.data,
        action: actionTxt
      }
    });

  }


  removeChartDialog(chartId: string) {
    if (!chartId || chartId.length < 6) {
      this.snackBar.open('Error occurred. unable to remove selected chart', null, {
        duration: 3000,
      });
      return;
    }

    this.dialog.open(ConfirmComponent, {
      width: '500px',
      autoFocus: false,
      scrollStrategy: new NoopScrollStrategy(),
      data: {
        isLoading: this.state,
        action: 'Remove chart',
        name: 'Are you sure you want to remove selected chart?',
        doAction: () => {
          this.removeChart(chartId);
        }
      },
    });

  }

  removeChart(chartId: string) {
    this.chartService.removeChart(chartId).subscribe(response => {
      if (response.success === true) {
        this.charts = this.charts.filter(cC => cC.chartId !== chartId);
        this.snackBar.open(response?.success === true ? 'Successfully removed chart!' : 'Error occurred', null, {
          duration: 3000,
        });

      }

    });
  }

  saveChart(newChart: Chart) {
    if (!this.selectedModule) {
      console.log('this.selected modules is missing');
      return;
    }
    if (!newChart.chartId) {
      delete newChart.chartId;
      const doesExist = this.charts.filter(cC => cC.chartDescription.indexOf(newChart.chartDescription) > -1);
      if (doesExist.length > 0) {
        newChart.chartDescription += '_copy' + doesExist.length;
      }
    }

    newChart.module = this.selectedModule;
    const currService = newChart.chartId !== undefined ? this.chartService.updateChart : this.chartService.createNewChart;
    const currServiceArgs = newChart.chartId !== undefined ? {chartId: newChart.chartId, chart: newChart} : {newChart};
    currService.call(this.chartService, currServiceArgs).subscribe(response => {
      let msg = '';
      if (response.hasOwnProperty('success')) {
        msg = `Chart ${response.success === true ? 'was updated successfully!' : 'failed to update!'}`;
        const currChartIndex = this.charts.findIndex(cC => cC.chartId === newChart.chartId);
        this.charts[currChartIndex] = newChart;

      } else if (response?.chartId !== '') {
        msg = response?.chartId !== '' ? 'Successfully added a chart!' : 'Error occurred';
        this.charts = [...this.charts, {...newChart, chartId: response.chartId}];
      }

      this.snackBar.open(msg, null, {
        duration: 3000,
      });
      this.state = LoadingProgress.DONE;
      this.dialogRef.close();
    });


  }

  setPreview(previewMode: string) {
    if (this.selectedPreview === 'insights') {
      this.selectedInsightsChart = {
        dataFields: [],
        means: [],
        trends: [],
        covariance: {source: undefined, target: undefined, value: undefined}
      };
    }
    this.selectedPreview = previewMode;
  }


  calculateInsights() {
    console.log('calculating');
  }


  sortData(sort: Sort) {
    const data = [...this.dataSource.data];
    if (sort.direction === '') {
      sort.direction = 'desc';
    }

    const sortedData = data.sort((a, b) => {
      const isAsc = sort.direction === 'asc';
      return this.compare(a[sort.active], b[sort.active], isAsc);
    });
    this.dataSource = new MatTableDataSource<any>(sortedData);
    this.dataSource.paginator = this.paginator;

  }

  customFeatureHandler(newField: string) {
    if (!newField || newField.toString().length < 2) {
      return;
    }
    const newInsightChart = {
      ...this.selectedInsightsChart,
      dataFields: [...this.selectedInsightsChart.dataFields.filter(cIf => cIf !== 'timestamp')]
    };
    const doesFieldExistIndex = this.selectedInsightsChart.dataFields.findIndex(cDf => cDf === newField);

    if (doesFieldExistIndex && doesFieldExistIndex > -1) {
      newInsightChart.trends.splice(doesFieldExistIndex, 1);
      newInsightChart.means.splice(doesFieldExistIndex, 1);
      newInsightChart.dataFields.splice(doesFieldExistIndex, 1);
    } else {
      newInsightChart.dataFields = [...newInsightChart.dataFields, newField];
    }

    newInsightChart.means = this.calculateDataSetMeans(newInsightChart.dataFields);
    newInsightChart.trends = this.calculateDataSetTrends(newInsightChart.dataFields);
    if (newInsightChart.dataFields.length > 1) {
      newInsightChart.covariance.value = this.calculateCovaraince(newInsightChart.dataFields);
    }
    this.selectedInsightsChart = newInsightChart;
  }

  calculateDataSetTrends(dataFields: string[]): number[] {
    try {
      if (this.events.length === 0) {
        return;
      }
      const trendsDic = {};
      dataFields.forEach(cDf => trendsDic[cDf] = 0);

      const xAverage = this.events.reduce((accumulator, item) => accumulator + item.sample_time || 0, 0) / this.events.length;

      for (const item of this.events) {

        dataFields.forEach((dataField, index) => {
          const enumerator = (item.sample_time || 0 - xAverage) * (item.payload[dataField] || 0 - this.selectedInsightsChart.means[index]) ?? -1;
          const denominator = Math.pow(item.sample_time - xAverage, item.sample_time - xAverage) ?? -1;

          trendsDic[dataField] += enumerator / denominator;

        });
      }

      return dataFields.map(cTk => trendsDic[cTk]);
    } catch (e) {
      return dataFields.map(c => 0);
    }
  }

  calculateDataSetMeans(dataFields: string[]) {
    if (this.dataSource.data.length === 0) {
      return;
    }
    const meansDic = {};
    for (const item of this.dataSource.data) {
      dataFields.forEach(cDf => meansDic[cDf] = meansDic[cDf] ? meansDic[cDf] + item[cDf] : item[cDf]);
    }
    return dataFields.map(cMk => (meansDic[cMk] || 0) / this.dataSource.data.length);
  }

  calculateCovaraince(dataFields?: string[]) {
    try {
      if (!this.selectedInsightsChart.covariance.source || !this.selectedInsightsChart.covariance.target) {
        return;
      }
      let numerator = 0;
      const sourceField = this.selectedInsightsChart.covariance.source;
      const targetField = this.selectedInsightsChart.covariance.target;
      const sourceFieldAverage = this.events.reduce((accumulator, item) => accumulator + item.payload[sourceField] || 0, 0) / this.events.length;
      const targetFieldAverage = this.events.reduce((accumulator, item) => accumulator + item.payload[targetField] || 0, 0) / this.events.length;

      for (const item of this.events) {
        numerator += (item.payload[sourceField] - sourceFieldAverage) * (item.payload[targetField] - targetFieldAverage);
      }
      return numerator / (this.events.length - 1);
    } catch (e) {
      return 0;
    }

  }

  compare(a: number | string, b: number | string, isAsc: boolean) {
    return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
  }

  handleCovarianceTargetChange($event: MatSelectChange) {
    this.selectedInsightsChart.covariance.value = this.calculateCovaraince();
  }


}






