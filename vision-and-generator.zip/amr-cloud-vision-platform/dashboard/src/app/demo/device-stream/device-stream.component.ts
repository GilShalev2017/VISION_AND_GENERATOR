import {Component, ElementRef, OnDestroy, OnInit, ViewChild} from '@angular/core';
import videojs from 'video.js';

@Component({
  selector: 'app-device-stream',
  templateUrl: './device-stream.component.html',
  styleUrls: ['./device-stream.component.css']
})
export class DeviceStreamComponent implements OnInit, OnDestroy {
  @ViewChild('target', {static: true}) target: ElementRef;
  player: videojs.Player;

  constructor(private elementRef: ElementRef) { }

  ngOnInit(): void {
    console.log('init player');
    this.player = videojs(this.target.nativeElement, {
      sources: [{ src: 'https://bitdash-a.akamaihd.net/content/MI201109210084_1/m3u8s/f08e80da-bf1d-4e3d-8899-f0f6155f6efa.m3u8', type: 'application/x-mpegURL' }]
    }, function onPlayerReady() {
      console.log('onPlayerReady', this);
    });
  }

  ngOnDestroy() {
    // destroy player
    if (this.player) {
      this.player.dispose();
    }
  }
}
