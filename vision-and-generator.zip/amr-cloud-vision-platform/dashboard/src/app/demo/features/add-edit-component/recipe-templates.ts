// Code File Templates
export const pythonRecipeTemplate = {
  "RecipeFormatVersion": "2020-01-25",
  "ComponentName": "com.intel.HelloWorld",
  "ComponentVersion": "1.0.0",
  "ComponentDescription": "My first AWS IoT Greengrass component.",
  "ComponentPublisher": "Intel Corp",
  "ComponentConfiguration": {
    "DefaultConfiguration": {
      "Message": "world"
    }
  },
  "Manifests": [
    {
      "Platform": {
        "os": "linux"
      },
      "Lifecycle": {
        "Run": "python3 -u {artifacts:path}/hello_world.py \"{configuration:/Message}\""
      }
    },
    {
      "Platform": {
        "os": "windows"
      },
      "Lifecycle": {
        "Run": "py -3 -u {artifacts:path}/hello_world.py \"{configuration:/Message}\""
      }
    }
  ]
};
export const ourPythonRecipeTemplate = {
  "RecipeFormatVersion": "2020-01-25",
  "ComponentName": "com.intel.HelloWorld",
  "ComponentVersion": "1.0.0",
  "ComponentDescription": "My first Greengrass component.",
  "ComponentPublisher": "Intel Corporation",
  "ComponentConfiguration": {
    "DefaultConfiguration": {
      "Message": "world"
    }
  },
  "Manifests": [
    {
      "Name": "Linux",
      "Platform": {
        "os": "linux"
      },
      "Lifecycle": {
        "Run": "python3 {artifacts:path}/hello_world.py '{configuration:/Message}'"
      },
      "Artifacts": [
        {
          "Uri": "s3://vp-components/artifacts/com.example.HelloWorld/1.0.0/hello_world.py"
        }
      ]
    }
  ]
};
export const nodeJsRecipeTemplate = {
  "RecipeFormatVersion": "2020-01-25",
  "ComponentName": "com.example.HelloWorld",
  "ComponentVersion": "1.0.0",
  "ComponentDescription": "My first AWS IoT Greengrass component.",
  "ComponentPublisher": "Amazon",
  "ComponentConfiguration": {
    "DefaultConfiguration": {
      "Message": "world"
    }
  },
  "Manifests": [
    {
      "Platform": {
        "os": "linux"
      },
      "Lifecycle": {
        "Run": "python3 -u {artifacts:path}/hello_world.py \"{configuration:/Message}\""
      }
    },
    {
      "Platform": {
        "os": "windows"
      },
      "Lifecycle": {
        "Run": "py -3 -u {artifacts:path}/hello_world.py \"{configuration:/Message}\""
      }
    }
  ]
};
export const severalFieldsRecipeTemplate = {
  "RecipeFormatVersion": "2020-01-25",
  "ComponentName": "com.intel.FooService",
  "ComponentDescription": "Complete recipe for AWS IoT Greengrass components",
  "ComponentPublisher": "Intel Corp",
  "ComponentVersion": "1.0.0",
  "ComponentConfiguration": {
    "DefaultConfiguration": {
      "TestParam": "TestValue"
    }
  },
  "ComponentDependencies": {
    "BarService": {
      "VersionRequirement": "^1.1.0",
      "DependencyType": "SOFT"
    },
    "BazService": {
      "VersionRequirement": "^2.0.0"
    }
  },
  "Manifests": [
    {
      "Platform": {
        "os": "linux",
        "architecture": "amd64"
      },
      "Lifecycle": {
        "Install": {
          "Skipif": "onpath git",
          "Script": "sudo apt-get install git"
        }
      },
      "Artifacts": [
        {
          "URI": "s3://vp-components/artifacts/com.intel.FooService/1.0.0/hello_world.zip",
          "Unarchive": "ZIP"
        },
        {
          "URI": "s3://vp-components/artifacts/com.intel.FooService/1.0.0/hello-world2.py"
        }
      ]
    },
    {
      "Lifecycle": {
        "Start": {
          "Skipif": "onpath git",
          "Script": "sudo apt-get install git"
        }
      },
      "Artifacts": [
        {
          "URI": "s3://vp-components/artifacts/com.intel.FooService/1.0.0/hello_world.py"
        }
      ]
    }
  ]
};
// Runtime Templates
export const pythonRuntimeTemplate = {
  "RecipeFormatVersion": "2020-01-25",
  "ComponentName": "com.intel.PythonRuntime",
  "ComponentDescription": "Installs Python 3.7",
  "ComponentPublisher": "Intel Corp",
  "ComponentVersion": "1.1.0",
  "Manifests": [
    {
      "Platform": {
        "os": "linux",
        "architecture": "amd64"
      },
      "Lifecycle": {
        "Install": "apt-get install python3.7"
      }
    }
  ]
};
// Docker Templates
export const dockerComposeAmazonEcrAndHubTemplate = {
  "RecipeFormatVersion": "2020-01-25",
  "ComponentName": "com.intel.MyDockerComposeComponent",
  "ComponentVersion": "1.0.0",
  "ComponentDescription": "A component that uses Docker Compose to run images from public Amazon ECR and Docker Hub.",
  "ComponentPublisher": "Intel Corp",
  "ComponentDependencies": {
    "aws.greengrass.DockerApplicationManager": {
      "VersionRequirement": "~2.0.0"
    }
  },
  "Manifests": [
    {
      "Platform": {
        "os": "all"
      },
      "Lifecycle": {
        "Run": "docker-compose -f {artifacts:path}/docker-compose.yaml up"
      },
      "Artifacts": [
        {
          "URI": "docker:public.ecr.aws/cloudwatch-agent/cloudwatch-agent:latest"
        },
        {
          "URI": "docker:mysql:8.0"
        },
        {
          "URI": "s3://DOC-EXAMPLE-BUCKET/folder/docker-compose.yaml"
        }
      ]
    }
  ]
};
export const privateAmazonECRTemplate = {
  "RecipeFormatVersion": "2020-01-25",
  "ComponentName": "com.example.MyPrivateDockerComponent",
  "ComponentVersion": "1.0.0",
  "ComponentDescription": "A component that runs a Docker container from a private Amazon ECR image.",
  "ComponentPublisher": "Amazon",
  "ComponentDependencies": {
    "aws.greengrass.DockerApplicationManager": {
      "VersionRequirement": "~2.0.0"
    },
    "aws.greengrass.TokenExchangeService": {
      "VersionRequirement": "~2.0.0"
    }
  },
  "Manifests": [
    {
      "Platform": {
        "os": "all"
      },
      "Lifecycle": {
        "Run": "docker run account-id.dkr.ecr.region.amazonaws.com/repository[:tag|@digest]"
      },
      "Artifacts": [
        {
          "URI": "docker:account-id.dkr.ecr.region.amazonaws.com/repository[:tag|@digest]"
        }
      ]
    }
  ]
};
export const s3BucketDockerTemplate = {
  "RecipeFormatVersion": "2020-01-25",
  "ComponentName": "com.example.MyS3DockerComponent",
  "ComponentVersion": "1.0.0",
  "ComponentDescription": "A component that runs a Docker container from an image in an S3 bucket.",
  "ComponentPublisher": "Amazon",
  "Manifests": [
    {
      "Platform": {
        "os": "linux"
      },
      "Lifecycle": {
        "Install": {
          "Script": "docker load -i {artifacts:path}/hello-world.tar"
        },
        "Run": {
          "Script": "docker run --rm hello-world"
        }
      }
    }
  ]
};
