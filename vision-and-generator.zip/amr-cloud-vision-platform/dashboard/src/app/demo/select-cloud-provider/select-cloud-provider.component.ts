import {Component, OnInit} from '@angular/core';
import {FormControl, FormGroup} from '@angular/forms';
import {UserService} from '../../framework/authentication/user.service';
import {LoadingProgress, UserCloudProvider} from '../../models/interfaces';
import {Router} from '@angular/router';

@Component({
  selector: 'app-select-cloud-provider',
  templateUrl: './select-cloud-provider.component.html',
  styleUrls: ['./select-cloud-provider.component.css']
})
export class SelectCloudProviderComponent implements OnInit {
  LoadingProgress: typeof LoadingProgress = LoadingProgress;
  state: LoadingProgress = LoadingProgress.DONE;

  cloudProviders = ['azure', 'aws'];
  selectedProvider = 'azure';
  form: FormGroup;
  error: string;

  constructor(private router: Router, private userService: UserService) {
    this.form = new FormGroup({
      notManaged: new FormControl(),
      existingIoTHub: new FormControl(''),
      connectionString: new FormControl(''),
      eventsHubEndpoint: new FormControl(''),
      clientId: new FormControl(''),
      secret: new FormControl(''),
      tenantId: new FormControl(''),
      subscriptionId: new FormControl(''),
    });
  }

  ngOnInit(): void {
  }

  selectProvider(provider: string) {
    this.selectedProvider = provider;
  }

  submit() {
    this.state = LoadingProgress.LOADING;
    const userCloudProvider: UserCloudProvider = {
      intelManaged: !this.form.value.notManaged,
      provider: this.selectedProvider === 'aws' ? 'AWS' : 'AZURE'
    };
    if (this.form.value.notManaged) {
      if (this.form.value.existingIoTHub) {
        userCloudProvider.connectionString = this.form.value.connectionString;
        userCloudProvider.eventsHubConnectionString = this.form.value.eventsHubEndpoint;
      } else {
        userCloudProvider.clientId = this.form.value.clientId;
        userCloudProvider.secret = this.form.value.secret;
        userCloudProvider.tenantId = this.form.value.tenantId;
        userCloudProvider.subscriptionId = this.form.value.subscriptionId;
      }
    }
    this.userService.updateUser({cloudProvider: userCloudProvider}).subscribe(() => {
      this.state = LoadingProgress.DONE;
      this.router.navigateByUrl('/devices');
    }, err => {
      this.state = LoadingProgress.ERROR;
      console.log('err', err.error?.error);
      this.error = err?.error?.error?.message || err?.statusText;
    });
  }
}
