import { Injectable } from '@angular/core';
import {FileNode} from "../../models/interfaces";

const TREE_DATA: FileNode[] = [
  {
    name: 'Intel D345i',
    children: [
      {
        name: 'src',
        children: [
          {name: 'app'},
          {name: 'assets'},
          {name: 'environments'},
        ]
      }, {
        name: 'node_modules',
        children: [
          {name: 'testPack'},
          {name: 'testPack2'},
        ]
      },
      {name: 'angular.json'},
      {name: 'Dockerfile'},
      {name: 'main.ts'},
      {name: 'package.json'},
      {name: 'README.md'},
      {name: 'tsconfig.json'},
    ],

  }
];


@Injectable({
  providedIn: 'root'
})
export class FileEditorService {

  constructor() { }

  getFileList(): FileNode[] {
    return TREE_DATA;
  }
}
