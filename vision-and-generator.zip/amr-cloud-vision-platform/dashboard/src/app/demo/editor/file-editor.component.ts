import {AfterViewInit, ChangeDetectorRef, Component, OnInit, ViewChild, ViewEncapsulation} from '@angular/core';
import {NgTerminal} from 'ng-terminal';
import {FileNode} from '../../models/interfaces';
import {FileEditorService} from './file-editor.service';
import {Terminal} from 'xterm';

@Component({
  selector: 'app-editor',
  templateUrl: './file-editor.component.html',
  styleUrls: ['./file-editor.component.scss']
})
export class FileEditorComponent implements OnInit, AfterViewInit  {

  @ViewChild('term', { static: true }) terminal: NgTerminal;
  term: Terminal;

  editorOptions = {theme: 'vs-dark', language: 'javascript', baseUrl: 'assets/monaco/vs'};
  code = 'function x() {\n' +
    '\tconsole.log("Hello world!");\n' +
    '}';
  currentFileList: FileNode[];

  constructor(private cd: ChangeDetectorRef, private fileEditorService: FileEditorService) { }

  ngAfterViewInit(): void {
    const emulateLine = '\r\n\x1b[32mroot@D354i\x1b[33m ~/src/app\x1b[36m (master)\x1B[0m';
    this.terminal.keyEventInput.subscribe(e => {
      console.log('keyboard event:' + e.domEvent.keyCode + ', ' + e.key);

      const ev = e.domEvent;
      const printable = !ev.altKey && !ev.ctrlKey && !ev.metaKey;

      if (ev.keyCode === 13) {
        this.terminal.write(emulateLine + '\r\n$ ');
      } else if (ev.keyCode === 8) {
        // Do not delete the prompt
        if (this.terminal.underlying.buffer.active.cursorX > 2) {
          this.terminal.write(emulateLine + '\b \b');
        }
      } else if (printable) {
        this.terminal.write(e.key);
      }
    });

    this.term = this.terminal.underlying;
    this.term.setOption('theme', {
      background: '#1e1e1e'
    });
    this.terminal.write('\x1b[32mroot@D354i\x1b[33m ~/src/app\x1b[36m (master)\x1B[0m' + '\r\n$ ');
  }

  ngOnInit(): void {
    this.currentFileList = this.fileEditorService.getFileList();
  }

  changeLang(language: string) {
    console.log('change lang to ' + language);
    const options = {...this.editorOptions};
    options.language = language;
    this.editorOptions = options;
  }

}
