export const environment = {
  version: '0.0.<<version>>',
  production: true,
  serverUrl: 'http://a8251ef9a54614c578798aea7f0f9971-cba484b4118e0b1d.elb.us-east-1.amazonaws.com/' // local
};
