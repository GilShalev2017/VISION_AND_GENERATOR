export const environment = {
  version: '0.0.local',
  production: true,
  serverUrl: 'http://127.0.0.1/' // local
};
