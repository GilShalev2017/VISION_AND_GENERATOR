// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  version: '0.0.local',
  production: false,
  serverUrl: 'http://localhost:3070/' // local
  // serverUrl: 'http://ec2-3-239-75-169.compute-1.amazonaws.com/' // aws
  // serverUrl: 'http://127.0.0.1/' // local
  // serverUrl: 'http://a614f914d89db4350b0e8fdd09327e69-0550fe15a1651deb.elb.us-west-2.amazonaws.com/'  // prod
  // serverUrl: 'http://a60bef7aff0a144e5a557bcef46d2992-1168452b97545ef0.elb.us-east-1.amazonaws.com/'  // dev
  // serverUrl: 'http://a3e25ae371754479eae8255868ce0b05-7d5adcec3f2cd793.elb.us-east-1.amazonaws.com/' // new
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
