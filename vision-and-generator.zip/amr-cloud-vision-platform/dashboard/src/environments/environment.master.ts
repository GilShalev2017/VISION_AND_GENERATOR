export const environment = {
  version: '0.0.<<version>>',
  production: true,
  serverUrl: 'http://a888f36d092dc4ff58e25509269caf40-f0b8c301afd4d32d.elb.us-east-1.amazonaws.com/' // local
};
