let request = require('request');

// Remote BE credentials
// const url = 'http://a60bef7aff0a144e5a557bcef46d2992-1168452b97545ef0.elb.us-east-1.amazonaws.com/';
// const email = 'roy.michael@intel.com';


// Local BE credentials
const url = 'http://localhost:3070';
const email = 'roy.gilmilel@gmail.com';

// Options
const password = 'A123456789';
const regDeviceId = 'roy-test-3'; // change every time for testing, or delete the device on hub

process.env.HTTP_PROXY = ''

async function login(email, password) {
  console.log('===> Logging in...');
  let requestUrl = url + '/users/login';
  return new Promise((resolve, reject) => {
    var options = {
      method: 'POST',
      body: {
        email: email,
        password: password
      },
      json: true,
      url: requestUrl
    };
    request(options,
      function (error, response, body) {
        if (error) {
          console.log(error);
          reject('===> Login failed:', error);
        }
        resolve(body);
      })
  });
}

async function regDevice(deviceId, token) {
  console.log(`===> Registering device ${deviceId}...`);
  let requestUrl = url + '/devices';
  return new Promise((resolve, reject) => {
    var options = {
      method: 'POST',
      body: {
        deviceId: deviceId,
        autoGenKeys: true,
        hubEnabled: true
      },
      json: true,
      url: requestUrl,
      headers: {
        'Authorization':'Bearer ' + token
      }
    };
    request(options,
      function (error, response, body) {
        if (error) {
          reject('===> Create device failed: ', error);
        }
        resolve(body);
      })
  });
}

async function getDevice(deviceId, token) {
  let requestUrl = url + '/devices/' + deviceId;
  return new Promise((resolve, reject) => {
    var options = {
      method: 'GET',
      body: {
        deviceId: deviceId,
        autoGenKeys: true,
        hubEnabled: true
      },
      json: true,
      url: requestUrl,
      headers: {
        'Authorization':'Bearer ' + token
      }
    };
    request(options,
      function (error, response, body) {
        if (error) {
          reject('===> Get device failed: ', error);
        }
        resolve(body);
      })
  });
}


login(email, password).then((res) => {
  console.log(res);
  const token = res.token.accessToken;
  regDevice(regDeviceId, token).then((res) => {
    console.log(res);
    console.log("===> Primary Connection String for device is: ", `HostName=${res.iotDomainName};DeviceId=${res.id};SharedAccessKey=${res.authentication.symmetricKey.primaryKey}`);
    console.log("===> Secondary Connection String for device is: ", `HostName=${res.iotDomainName};DeviceId=${res.id};SharedAccessKey=${res.authentication.symmetricKey.secondaryKey}`);
  }).catch((e) => {
    console.log('===> Register device failed, check if deviceId already exists...')
    getDevice(regDeviceId, token).then((res) => {
      console.log(res);
      console.log(`===> Primary Connection String for ${res.id} is: `, `HostName=${res.iotDomainName};DeviceId=${res.id};SharedAccessKey=${res.authentication.symmetricKey.primaryKey}`);
      console.log(`===> Secondary Connection String for ${res.id} is: `, `HostName=${res.iotDomainName};DeviceId=${res.id};SharedAccessKey=${res.authentication.symmetricKey.secondaryKey}`);
    }).catch((e) => {
      console.log('Get device failed:', e);
    })
  });
}).catch((e) => {
  console.log(e);
});
