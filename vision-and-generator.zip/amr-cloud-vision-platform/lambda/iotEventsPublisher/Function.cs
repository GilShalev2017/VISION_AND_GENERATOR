using System;
using System.IO;
using System.Text;

using Amazon.Lambda.Core;
using Amazon.Lambda.DynamoDBEvents;
using Amazon.DynamoDBv2.Model;
using Amazon.DynamoDBv2;
using Amazon;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;

// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.SystemTextJson.DefaultLambdaJsonSerializer))]
namespace VTGDbInserter
{
    public class Function
    {
        public void FunctionHandler(GeneralSensorEvent payloadObject, ILambdaContext context)
        {
            if (context != null && context.Logger != null)
            {
                context.Logger.LogLine("arriveEvent=" + payloadObject);
                context.Logger.LogLine($"Beginning to process {payloadObject} ...");
            }

            var region = Environment.GetEnvironmentVariable("REGION");
            var table = Environment.GetEnvironmentVariable("EVENTS_TABLE");
        
            var dynamoDbClient = new AmazonDynamoDBClient(RegionEndpoint.GetBySystemName(region));

            //For UT Use the following client :
            //var dynamoDbClient = new AmazonDynamoDBClient("AKIAWKTEUXFJNXU2RZ6L", "Y7+pPvXfJG7Ft2gtbix9a7sepN9N1fICVOC94oWj", RegionEndpoint.GetBySystemName(region));
            
            //JObject payload = JObject.Parse(payloadObject);
            var module_name = payloadObject.module_name;
            var device_id = payloadObject.device_id;

            var dateTimeOffset = DateTimeOffset.Now;
            var originalTime = dateTimeOffset.ToUnixTimeMilliseconds();
            var alignedTime = originalTime / 1000;
            var sample_time = alignedTime.ToString();
           
            var payloadString = payloadObject.payload.ToString();

            Dictionary<string, AttributeValue> dic = new Dictionary<string, AttributeValue>
            {
                { "device_id", new AttributeValue(device_id) },
                { "sample_time", new AttributeValue { N = sample_time } },
                { "module_name", new AttributeValue(module_name) },
                { "payload", new AttributeValue(payloadString) }
            };

            try
            {
                PutItemResponse response = dynamoDbClient.PutItemAsync(table, dic).Result;
                if (context != null && context.Logger != null)
                {
                    context.Logger.LogLine("Result = " + response.HttpStatusCode);
                }
            }
            catch(Exception xcp)
            {
                Console.WriteLine(xcp);
            }
        }
    }
}